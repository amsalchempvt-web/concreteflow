export function exportToCSV(filename: string, headers: string[], rows: (string | number)[][]) {
  const csvContent = [
    headers.join(','),
    ...rows.map((row) =>
      row
        .map((cell) => {
          const str = String(cell ?? '');
          if (str.includes(',') || str.includes('"') || str.includes('\n')) {
            return `"${str.replace(/"/g, '""')}"`;
          }
          return str;
        })
        .join(',')
    ),
  ].join('\n');

  const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function exportToExcel(filename: string, headers: string[], rows: (string | number)[][]) {
  let html = '<table>';
  html += '<thead><tr>' + headers.map((h) => `<th style="background:#1e40af;color:white;padding:8px;border:1px solid #ccc;">${h}</th>`).join('') + '</tr></thead>';
  html += '<tbody>';
  for (const row of rows) {
    html += '<tr>' + row.map((c) => `<td style="padding:6px;border:1px solid #ddd;">${c}</td>`).join('') + '</tr>';
  }
  html += '</tbody></table>';

  const blob = new Blob(['\ufeff' + html], { type: 'application/vnd.ms-excel' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename.endsWith('.xls') ? filename : `${filename}.xls`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export function printDocument(title: string, htmlContent: string) {
  const fullHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${title}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #1a1a1a; }
    h1 { font-size: 24px; margin-bottom: 8px; }
    h2 { font-size: 18px; margin-bottom: 16px; color: #555; }
    table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    th { background: #1e40af; color: white; padding: 10px 12px; text-align: left; font-size: 13px; }
    td { padding: 8px 12px; border-bottom: 1px solid #e5e7eb; font-size: 13px; }
    tr:nth-child(even) { background: #f9fafb; }
    .header { display: flex; justify-content: space-between; align-items: start; margin-bottom: 32px; border-bottom: 2px solid #1e40af; padding-bottom: 16px; }
    .company-name { font-size: 22px; font-weight: bold; color: #1e40af; }
    .meta { text-align: right; font-size: 13px; color: #666; }
    .totals { margin-left: auto; width: 300px; margin-top: 16px; }
    .totals td { border: none; padding: 4px 12px; }
    .totals .grand { font-weight: bold; border-top: 2px solid #1e40af; font-size: 16px; }
    .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e5e7eb; font-size: 12px; color: #999; text-align: center; }
    .badge { display: inline-block; padding: 4px 12px; border-radius: 4px; font-size: 12px; font-weight: 600; }
    @media print { body { padding: 20px; } }
  </style>
</head>
<body>
  ${htmlContent}
  <div class="footer">This is a computer-generated document from ConcreteFlow ERP</div>
</body>
</html>`;

  // Use a hidden iframe to avoid popup blocker issues
  const existing = document.getElementById('print-iframe');
  if (existing) existing.remove();

  const iframe = document.createElement('iframe');
  iframe.id = 'print-iframe';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) {
    // Fallback: open in new window
    const printWindow = window.open('', '_blank', 'width=900,height=700');
    if (printWindow) {
      printWindow.document.write(fullHtml);
      printWindow.document.close();
      printWindow.onload = () => { printWindow.print(); };
    }
    return;
  }

  doc.open();
  doc.write(fullHtml);
  doc.close();

  // Wait for content to render, then print
  const contentWindow = iframe.contentWindow;
  if (contentWindow) {
    contentWindow.onload = () => {
      contentWindow.focus();
      contentWindow.print();
      // Clean up after print dialog closes
      setTimeout(() => {
        iframe.remove();
      }, 1000);
    };
    // Fallback if onload doesn't fire (some browsers)
    setTimeout(() => {
      try {
        contentWindow.focus();
        contentWindow.print();
      } catch {
        // already printing
      }
      setTimeout(() => iframe.remove(), 1000);
    }, 500);
  }
}
