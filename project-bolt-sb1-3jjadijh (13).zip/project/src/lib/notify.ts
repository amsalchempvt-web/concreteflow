import { supabase } from '@/lib/supabase';

export async function triggerNotification(
  alertType: string,
  subject: string,
  message: string,
): Promise<void> {
  try {
    const { data: settings } = await supabase
      .from('notification_settings')
      .select('email_enabled, whatsapp_enabled')
      .limit(1)
      .maybeSingle();

    if (!settings || (!settings.email_enabled && !settings.whatsapp_enabled)) {
      return;
    }

    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-notification`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    const session = await supabase.auth.getSession();
    if (session.data.session?.access_token) {
      headers['Authorization'] = `Bearer ${session.data.session.access_token}`;
    }
    headers['apikey'] = import.meta.env.VITE_SUPABASE_ANON_KEY;

    await fetch(apiUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({ alert_type: alertType, subject, message }),
    });
  } catch {
    // Silently fail — notifications are non-blocking
  }
}
