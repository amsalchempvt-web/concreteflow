import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  detectSessionInUrl: true,
  flowType: 'implicit',
  // Suppress the auth debug logging in console
    debug: false,
  },
});

export type UserRole = 'super_admin' | 'admin' | 'manager' | 'accountant' | 'plant_operator' | 'sales_executive';

export interface Company {
  id: string;
  name: string;
  gst_number: string;
  address: string;
  contact: string;
  email: string;
  logo_url: string;
  pan_number: string;
  state_code: string;
  tagline: string;
  created_at: string;
}

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  company_id: string | null;
  created_at: string;
  company?: Company | null;
}

export interface UserPermission {
  id: string;
  user_id: string;
  module: string;
  allowed: boolean;
  created_at: string;
}

export interface Purchase {
  id: string;
  purchase_number: string;
  supplier_id: string;
  bill_number: string;
  bill_date: string;
  material_id: string;
  quantity: number;
  unit_cost: number;
  bill_amount: number;
  amount_paid: number;
  payment_status: string;
  notes: string;
  created_at: string;
  supplier?: Supplier;
  material?: RawMaterial;
}

export interface RawMaterial {
  id: string;
  name: string;
  code: string;
  unit: string;
  current_stock: number;
  minimum_stock: number;
  unit_cost: number;
  supplier_id: string | null;
  created_at: string;
  updated_at: string;
  supplier?: Supplier | null;
}

export interface RawMaterialMovement {
  id: string;
  material_id: string;
  movement_type: string;
  quantity_change: number;
  balance_after: number;
  reference: string;
  notes: string;
  created_at: string;
  material?: RawMaterial;
}

export interface FinishedProduct {
  id: string;
  code: string;
  name: string;
  unit: string;
  current_stock: number;
  minimum_stock: number;
  selling_price: number;
  production_cost: number;
  created_at: string;
  updated_at: string;
}

export interface BOMItem {
  id: string;
  product_id: string;
  material_id: string;
  quantity_per_unit: number;
  material?: RawMaterial;
}

export interface FinishedProductMovement {
  id: string;
  product_id: string;
  movement_type: string;
  quantity_change: number;
  balance_after: number;
  reference: string;
  notes: string;
  created_at: string;
  product?: FinishedProduct;
}

export interface Production {
  id: string;
  batch_number: string;
  product_id: string;
  quantity: number;
  production_date: string;
  operator_name: string;
  total_cost: number;
  status: string;
  notes: string;
  created_at: string;
  product?: FinishedProduct;
}

export interface Customer {
  id: string;
  name: string;
  company: string;
  mobile: string;
  email: string;
  address: string;
  gst_number: string;
  outstanding_balance: number;
  created_at: string;
}

export interface Supplier {
  id: string;
  name: string;
  company: string;
  contact: string;
  email: string;
  gst_number: string;
  material_supplied: string;
  outstanding_payment: number;
  created_at: string;
}

export interface DeliveryChallan {
  id: string;
  invoice_id: string | null;
  challan_number: string;
  challan_date: string;
  customer_id: string;
  client_name: string;
  site: string;
  po_number: string;
  so_number: string;
  batch_number: string;
  serial_number: string;
  grade: string;
  pump_type: string;
  quantity: number;
  tm_number: string;
  driver_name: string;
  opening_cmt: number;
  current_cmt: number;
  total_cmt: number;
  time_out: string;
  time_in: string;
  gst_number: string;
  pan_number: string;
  state_code: string;
  site_time: string;
  kms: string;
  gross_weight: string;
  tare_weight: string;
  net_weight: string;
  notes: string;
  created_at: string;
  customer?: Customer;
  invoice?: SalesInvoice;
}

export interface SalesInvoice {
  id: string;
  invoice_number: string;
  customer_id: string;
  invoice_date: string;
  product_id: string;
  quantity: number;
  rate: number;
  tax_rate: number;
  subtotal: number;
  tax_amount: number;
  total_amount: number;
  amount_paid: number;
  payment_status: string;
  notes: string;
  created_at: string;
  customer?: Customer;
  product?: FinishedProduct;
}

export interface Quotation {
  id: string;
  quotation_number: string;
  customer_id: string | null;
  customer_name: string;
  quotation_date: string;
  valid_until: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  tax_rate: number;
  subtotal: number;
  tax_amount: number;
  total_amount: number;
  terms: string;
  status: string;
  created_at: string;
  customer?: Customer | null;
  product?: FinishedProduct;
}

export interface Expense {
  id: string;
  expense_date: string;
  category: string;
  vendor: string;
  amount: number;
  notes: string;
  receipt_url: string;
  created_at: string;
}

export interface ActivityLog {
  id: string;
  user_email: string;
  action: string;
  entity: string;
  entity_id: string | null;
  details: string;
  created_at: string;
}

export const MODULE_KEYS = [
  'dashboard',
  'raw_materials',
  'finished_products',
  'production',
  'sales',
  'quotations',
  'expenses',
  'profit_loss',
  'customers',
  'suppliers',
  'purchases',
  'reports',
  'notifications',
  'notification_settings',
  'activity_logs',
  'user_management',
  'backup_restore',
] as const;

export type ModuleKey = typeof MODULE_KEYS[number];
