import {
  LayoutDashboard,
  Package,
  Layers,
  Factory,
  ReceiptText,
  FileText,
  Wallet,
  Users,
  Truck,
  TrendingUp,
  FileBarChart,
  Bell,
  History,
  UserCog,
  BellRing,
  ShoppingCart,
  DatabaseBackup,
  ShieldCheck,
  type LucideIcon,
} from 'lucide-react';
import type { UserRole, ModuleKey } from '@/lib/supabase';

export interface NavItem {
  label: string;
  path: string;
  icon: LucideIcon;
  roles: UserRole[];
  group: string;
  moduleKey: ModuleKey;
}

export const NAV_ITEMS: NavItem[] = [
  { label: 'Dashboard', path: '/', icon: LayoutDashboard, moduleKey: 'dashboard', roles: ['super_admin', 'admin', 'manager', 'accountant', 'plant_operator', 'sales_executive'], group: 'Overview' },
  { label: 'Raw Materials', path: '/raw-materials', icon: Package, moduleKey: 'raw_materials', roles: ['admin', 'manager', 'plant_operator'], group: 'Inventory' },
  { label: 'Finished Products', path: '/finished-products', icon: Layers, moduleKey: 'finished_products', roles: ['admin', 'manager', 'plant_operator', 'sales_executive'], group: 'Inventory' },
  { label: 'Production', path: '/production', icon: Factory, moduleKey: 'production', roles: ['admin', 'manager', 'plant_operator'], group: 'Operations' },
  { label: 'Purchases', path: '/purchases', icon: ShoppingCart, moduleKey: 'purchases', roles: ['admin', 'manager', 'plant_operator'], group: 'Inventory' },
  { label: 'Sales & Invoices', path: '/sales', icon: ReceiptText, moduleKey: 'sales', roles: ['admin', 'manager', 'accountant', 'sales_executive'], group: 'Finance' },
  { label: 'Delivery Challans', path: '/delivery-challans', icon: Truck, moduleKey: 'sales', roles: ['admin', 'manager', 'accountant', 'sales_executive'], group: 'Finance' },
  { label: 'Quotations', path: '/quotations', icon: FileText, moduleKey: 'quotations', roles: ['admin', 'manager', 'sales_executive'], group: 'Finance' },
  { label: 'Expenses', path: '/expenses', icon: Wallet, moduleKey: 'expenses', roles: ['admin', 'manager', 'accountant'], group: 'Finance' },
  { label: 'Profit & Loss', path: '/profit-loss', icon: TrendingUp, moduleKey: 'profit_loss', roles: ['admin', 'manager', 'accountant'], group: 'Finance' },
  { label: 'Customers', path: '/customers', icon: Users, moduleKey: 'customers', roles: ['admin', 'manager', 'sales_executive', 'accountant'], group: 'Contacts' },
  { label: 'Suppliers', path: '/suppliers', icon: Truck, moduleKey: 'suppliers', roles: ['admin', 'manager', 'plant_operator'], group: 'Contacts' },
  { label: 'Reports', path: '/reports', icon: FileBarChart, moduleKey: 'reports', roles: ['admin', 'manager', 'accountant'], group: 'Insights' },
  { label: 'Notifications', path: '/notifications', icon: Bell, moduleKey: 'notifications', roles: ['admin', 'manager', 'plant_operator', 'sales_executive', 'accountant'], group: 'Insights' },
  { label: 'Notification Settings', path: '/notification-settings', icon: BellRing, moduleKey: 'notification_settings', roles: ['admin'], group: 'System' },
  { label: 'User Management', path: '/user-management', icon: UserCog, moduleKey: 'user_management', roles: ['admin'], group: 'System' },
  { label: 'Backup & Restore', path: '/backup-restore', icon: DatabaseBackup, moduleKey: 'backup_restore', roles: ['admin'], group: 'System' },
  { label: 'Activity Logs', path: '/activity-logs', icon: History, moduleKey: 'activity_logs', roles: ['admin'], group: 'System' },
  { label: 'Platform Administration', path: '/super-admin', icon: ShieldCheck, moduleKey: 'dashboard', roles: ['super_admin'], group: 'System' },
];

export const ROLE_LABELS: Record<UserRole, string> = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  manager: 'Manager',
  accountant: 'Accountant',
  plant_operator: 'Plant Operator',
  sales_executive: 'Sales Executive',
};

export const MODULE_LABELS: Record<ModuleKey, string> = {
  dashboard: 'Dashboard',
  raw_materials: 'Raw Materials',
  finished_products: 'Finished Products',
  production: 'Production',
  purchases: 'Purchases',
  sales: 'Sales & Invoices',
  quotations: 'Quotations',
  expenses: 'Expenses',
  profit_loss: 'Profit & Loss',
  customers: 'Customers',
  suppliers: 'Suppliers',
  reports: 'Reports',
  notifications: 'Notifications',
  notification_settings: 'Notification Settings',
  activity_logs: 'Activity Logs',
  user_management: 'User Management',
  backup_restore: 'Backup & Restore',
};
