import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/hooks/use-auth';
import { ThemeProvider } from '@/hooks/use-theme';
import Sidebar from '@/components/layout/Sidebar';
import Topbar from '@/components/layout/Topbar';
import AuthPage from '@/pages/AuthPage';
import PendingApproval from '@/pages/PendingApproval';
import Dashboard from '@/pages/Dashboard';
import RawMaterials from '@/pages/RawMaterials';
import FinishedProducts from '@/pages/FinishedProducts';
import Production from '@/pages/Production';
import Sales from '@/pages/Sales';
import Quotations from '@/pages/Quotations';
import Expenses from '@/pages/Expenses';
import ProfitLoss from '@/pages/ProfitLoss';
import Customers from '@/pages/Customers';
import Suppliers from '@/pages/Suppliers';
import Reports from '@/pages/Reports';
import Notifications from '@/pages/Notifications';
import ActivityLogs from '@/pages/ActivityLogs';
import UserManagement from '@/pages/UserManagement';
import NotificationSettings from '@/pages/NotificationSettings';
import BackupRestore from '@/pages/BackupRestore';
import Purchases from '@/pages/Purchases';
import DeliveryChallans from '@/pages/DeliveryChallans';
import SuperAdmin from '@/pages/SuperAdmin';
import { Loader2 } from 'lucide-react';

function AppShell() {
  const { session, loading, profile } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!session) {
    return <AuthPage />;
  }

  // Users without a company_id are pending admin approval
  if (profile && !profile.company_id && profile.role !== 'super_admin') {
    return <PendingApproval />;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar onMenuClick={() => setSidebarOpen(true)} />
        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/raw-materials" element={<RawMaterials />} />
            <Route path="/finished-products" element={<FinishedProducts />} />
            <Route path="/production" element={<Production />} />
            <Route path="/sales" element={<Sales />} />
            <Route path="/delivery-challans" element={<DeliveryChallans />} />
            <Route path="/super-admin" element={<SuperAdmin />} />
            <Route path="/quotations" element={<Quotations />} />
            <Route path="/expenses" element={<Expenses />} />
            <Route path="/profit-loss" element={<ProfitLoss />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/suppliers" element={<Suppliers />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/notification-settings" element={<NotificationSettings />} />
            <Route path="/user-management" element={<UserManagement />} />
            <Route path="/backup-restore" element={<BackupRestore />} />
            <Route path="/purchases" element={<Purchases />} />
            <Route path="/activity-logs" element={<ActivityLogs />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <AppShell />
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
