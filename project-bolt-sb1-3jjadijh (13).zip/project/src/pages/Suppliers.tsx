import { useEffect, useState, useCallback } from 'react';
import { Plus, Truck, Download, Search, Pencil, Trash2, Phone, Mail, Package } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Supplier, RawMaterialMovement } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatDateTime } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { exportToCSV, exportToExcel } from '@/lib/export';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

export default function Suppliers() {
  const { profile } = useAuth();
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [movements, setMovements] = useState<RawMaterialMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: '', company: '', contact: '', email: '', gst_number: '', material_supplied: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [sups, movs] = await Promise.all([
      supabase.from('suppliers').select('*').order('name').then((r) => r),
      supabase.from('raw_material_movements').select('*, material:raw_materials(*)').order('created_at', { ascending: false }).limit(100).then((r) => r),
    ]);
    setSuppliers((sups.data as Supplier[]) || []);
    setMovements((movs.data as RawMaterialMovement[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', company: '', contact: '', email: '', gst_number: '', material_supplied: '' });
    setDialogOpen(true);
  };

  const openEdit = (s: Supplier) => {
    setEditing(s);
    setForm({
      name: s.name, company: s.company, contact: s.contact, email: s.email,
      gst_number: s.gst_number, material_supplied: s.material_supplied,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name) { toast.error('Name is required'); return; }
    const payload = { ...form };
    if (editing) {
      const { error } = await supabase.from('suppliers').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success('Supplier updated');
    } else {
      const { error } = await supabase.from('suppliers').insert(payload);
      if (error) { toast.error(error.message); return; }
      await supabase.from('activity_logs').insert({
        user_email: profile?.email || '',
        action: 'supplier_added',
        entity: 'supplier',
        details: form.name,
      });
      toast.success('Supplier added');
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('suppliers').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Supplier deleted');
    setDeleteId(null);
    fetchData();
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Name', 'Company', 'Contact', 'Email', 'GST', 'Material', 'Outstanding'];
    const rows = filtered.map((s) => [s.name, s.company, s.contact, s.email, s.gst_number, s.material_supplied, s.outstanding_payment]);
    if (format === 'csv') exportToCSV('suppliers', headers, rows);
    else exportToExcel('suppliers', headers, rows);
    toast.success('Exported successfully');
  };

  const filtered = suppliers.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.company.toLowerCase().includes(search.toLowerCase()) ||
    s.material_supplied.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Supplier Management" description="Manage supplier details and outstanding payments">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4 mr-2" /> Add Supplier
        </Button>
      </PageHeader>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search suppliers..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<Truck className="h-6 w-6" />}
              title="No suppliers found"
              description="Add your first supplier to track material purchases and payments."
              action={<Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> Add Supplier</Button>}
            />
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((s) => (
            <Card key={s.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0">
                    <h3 className="font-display font-bold truncate">{s.name}</h3>
                    <p className="text-sm text-muted-foreground truncate">{s.company || '-'}</p>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(s)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(s.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
                <div className="space-y-1.5 text-sm">
                  {s.contact && <div className="flex items-center gap-2 text-muted-foreground"><Phone className="h-3.5 w-3.5" /> {s.contact}</div>}
                  {s.email && <div className="flex items-center gap-2 text-muted-foreground"><Mail className="h-3.5 w-3.5" /> <span className="truncate">{s.email}</span></div>}
                  {s.material_supplied && <div className="flex items-center gap-2 text-muted-foreground"><Package className="h-3.5 w-3.5" /> {s.material_supplied}</div>}
                </div>
                <div className="mt-4 pt-3 border-t border-border grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">GST Number</p>
                    <p className="font-medium">{s.gst_number || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Outstanding</p>
                    <p className={`font-semibold ${Number(s.outstanding_payment) > 0 ? 'text-destructive' : 'text-success'}`}>
                      {formatCurrency(Number(s.outstanding_payment))}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Supplier' : 'Add Supplier'}</DialogTitle>
            <DialogDescription>{editing ? 'Update supplier details.' : 'Enter supplier information.'}</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Supplier Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Company</Label>
              <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Contact</Label>
              <Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>GST Number</Label>
              <Input value={form.gst_number} onChange={(e) => setForm({ ...form, gst_number: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Material Supplied</Label>
              <Input value={form.material_supplied} onChange={(e) => setForm({ ...form, material_supplied: e.target.value })} placeholder="e.g. Cement, Sand" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Add'} Supplier</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Supplier?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the supplier. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
