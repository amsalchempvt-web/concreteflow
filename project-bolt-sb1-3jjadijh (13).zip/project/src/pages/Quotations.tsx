import { useEffect, useState, useCallback } from 'react';
import { Plus, FileText, Download, Search, Printer, ArrowRight, Pencil, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Quotation, Customer, FinishedProduct } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatNumber, formatDate } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { exportToCSV, exportToExcel, printDocument } from '@/lib/export';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

const DEFAULT_TERMS = `1. Payment Terms: 50% advance, 50% on delivery.
2. Validity: 30 days from quotation date.
3. Prices are inclusive of applicable taxes unless stated otherwise.
4. Delivery charges extra as applicable.
5. Goods once sold will not be taken back.
6. Quality of concrete will be as per IS standard specifications.`;

export default function Quotations() {
  const { profile } = useAuth();
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<FinishedProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Quotation | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [viewQuotation, setViewQuotation] = useState<Quotation | null>(null);

  const [form, setForm] = useState({
    customer_id: '',
    product_id: '',
    quantity: 0,
    unit_price: 0,
    tax_rate: 18,
    valid_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    quotation_date: new Date().toISOString().split('T')[0],
    terms: DEFAULT_TERMS,
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [quos, custs, prods] = await Promise.all([
      supabase.from('quotations').select('*, customer:customers(*), product:finished_products(*)').order('created_at', { ascending: false }).then((r) => r),
      supabase.from('customers').select('*').order('name').then((r) => r),
      supabase.from('finished_products').select('*').order('code').then((r) => r),
    ]);
    setQuotations((quos.data as Quotation[]) || []);
    setCustomers((custs.data as Customer[]) || []);
    setProducts((prods.data as FinishedProduct[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({
      customer_id: '', product_id: '', quantity: 0, unit_price: 0, tax_rate: 18,
      valid_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      quotation_date: new Date().toISOString().split('T')[0], terms: DEFAULT_TERMS,
    });
    setDialogOpen(true);
  };

  const openEdit = (q: Quotation) => {
    setEditing(q);
    setForm({
      customer_id: q.customer_id || '', product_id: q.product_id,
      quantity: q.quantity, unit_price: Number(q.unit_price), tax_rate: Number(q.tax_rate),
      valid_until: q.valid_until, quotation_date: q.quotation_date, terms: q.terms,
    });
    setDialogOpen(true);
  };

  const subtotal = form.quantity * form.unit_price;
  const taxAmount = (subtotal * form.tax_rate) / 100;
  const totalAmount = subtotal + taxAmount;

  const handleSave = async () => {
    if (!form.product_id || form.quantity <= 0) {
      toast.error('Product and quantity are required');
      return;
    }
    const customer = customers.find((c) => c.id === form.customer_id);
    const payload = {
      customer_id: form.customer_id || null,
      customer_name: customer?.name || '',
      product_id: form.product_id,
      quantity: Number(form.quantity),
      unit_price: Number(form.unit_price),
      tax_rate: Number(form.tax_rate),
      subtotal: Number(subtotal.toFixed(2)),
      tax_amount: Number(taxAmount.toFixed(2)),
      total_amount: Number(totalAmount.toFixed(2)),
      valid_until: form.valid_until,
      quotation_date: form.quotation_date,
      terms: form.terms,
    };

    if (editing) {
      const { error } = await supabase.from('quotations').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success('Quotation updated');
    } else {
      const { data: numData } = await supabase.rpc('next_quotation_number');
      const quoNumber = numData as string;
      const { error } = await supabase.from('quotations').insert({ ...payload, quotation_number: quoNumber });
      if (error) { toast.error(error.message); return; }
      await supabase.from('activity_logs').insert({
        user_email: profile?.email || '',
        action: 'quotation_created',
        entity: 'quotation',
        details: `Quotation ${quoNumber} - ${formatCurrency(totalAmount)}`,
      });
      toast.success(`Quotation ${quoNumber} created`);
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('quotations').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Quotation deleted');
    setDeleteId(null);
    fetchData();
  };

  const convertToInvoice = async (q: Quotation) => {
    if (!q.customer_id) {
      toast.error('Quotation must have a customer to convert');
      return;
    }
    const { data: numData } = await supabase.rpc('next_invoice_number');
    const invNumber = numData as string;

    const { error } = await supabase.from('sales_invoices').insert({
      invoice_number: invNumber,
      customer_id: q.customer_id,
      product_id: q.product_id,
      quantity: q.quantity,
      rate: Number(q.unit_price),
      tax_rate: Number(q.tax_rate),
      subtotal: Number(q.subtotal),
      tax_amount: Number(q.tax_amount),
      total_amount: Number(q.total_amount),
      amount_paid: 0,
      payment_status: 'unpaid',
      invoice_date: new Date().toISOString().split('T')[0],
    });

    if (error) { toast.error(error.message); return; }

    await supabase.from('quotations').update({ status: 'converted' }).eq('id', q.id);
    toast.success(`Converted to invoice ${invNumber}`);
    fetchData();
  };

  const printQuotation = (q: Quotation) => {
    const html = `
      <div class="header">
        <div>
          <div class="company-name">ConcreteFlow ERP</div>
          <p style="font-size:13px;color:#666;">Concrete Mixing Plant Manufacturer</p>
          <p style="font-size:13px;color:#666;">GST: 27AABCC1234D1Z9</p>
        </div>
        <div class="meta">
          <h1>QUOTATION</h1>
          <p><strong>${q.quotation_number}</strong></p>
          <p>Date: ${formatDate(q.quotation_date)}</p>
          <p>Valid Until: ${formatDate(q.valid_until)}</p>
        </div>
      </div>
      <div style="margin-bottom:24px;">
        <h2 style="font-size:14px;color:#999;margin-bottom:4px;">Quote To:</h2>
        <p style="font-size:15px;font-weight:bold;">${q.customer_name}</p>
        ${q.customer ? `<p style="font-size:13px;color:#555;">${q.customer.company || ''}</p><p style="font-size:13px;color:#555;">${q.customer.address || ''}</p><p style="font-size:13px;color:#555;">GST: ${q.customer.gst_number || 'N/A'}</p>` : ''}
      </div>
      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th style="text-align:right;">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${q.product?.name || ''}</td>
            <td>${formatNumber(q.quantity, 1)} ${q.product?.unit || ''}</td>
            <td>${formatCurrency(Number(q.unit_price))}</td>
            <td style="text-align:right;">${formatCurrency(Number(q.subtotal))}</td>
          </tr>
        </tbody>
      </table>
      <table class="totals">
        <tr><td>Subtotal:</td><td style="text-align:right;">${formatCurrency(Number(q.subtotal))}</td></tr>
        <tr><td>GST (${q.tax_rate}%):</td><td style="text-align:right;">${formatCurrency(Number(q.tax_amount))}</td></tr>
        <tr class="grand"><td>Total:</td><td style="text-align:right;">${formatCurrency(Number(q.total_amount))}</td></tr>
      </table>
      <div style="margin-top:32px;">
        <h2 style="font-size:14px;color:#999;margin-bottom:8px;">Terms & Conditions:</h2>
        <div style="font-size:12px;color:#555;white-space:pre-line;">${q.terms}</div>
      </div>
    `;
    printDocument(`Quotation ${q.quotation_number}`, html);
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Quotation #', 'Customer', 'Date', 'Valid Until', 'Product', 'Qty', 'Total', 'Status'];
    const rows = filtered.map((q) => [
      q.quotation_number, q.customer_name, q.quotation_date, q.valid_until,
      q.product?.name || '', q.quantity, q.total_amount, q.status,
    ]);
    if (format === 'csv') exportToCSV('quotations', headers, rows);
    else exportToExcel('quotations', headers, rows);
    toast.success('Exported successfully');
  };

  const filtered = quotations.filter((q) =>
    q.quotation_number.toLowerCase().includes(search.toLowerCase()) ||
    q.customer_name.toLowerCase().includes(search.toLowerCase()) ||
    q.status.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Quotations" description="Generate quotations and convert them to invoices">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openAdd} disabled={products.length === 0}>
          <Plus className="h-4 w-4 mr-2" /> New Quotation
        </Button>
      </PageHeader>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search quotations..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<FileText className="h-6 w-6" />}
              title="No quotations found"
              description="Create your first quotation to share with customers."
              action={<Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> New Quotation</Button>}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Quotation #</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Valid Until</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((q) => (
                    <TableRow key={q.id}>
                      <TableCell className="font-mono text-sm">{q.quotation_number}</TableCell>
                      <TableCell className="font-medium">{q.customer_name}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(q.quotation_date)}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(q.valid_until)}</TableCell>
                      <TableCell>{q.product?.name || '-'}</TableCell>
                      <TableCell className="text-right">{formatNumber(q.quantity, 1)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(Number(q.total_amount))}</TableCell>
                      <TableCell>
                        <Badge variant={q.status === 'converted' ? 'default' : q.status === 'sent' ? 'secondary' : 'outline'}>
                          {q.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          {q.status !== 'converted' && (
                            <Button variant="ghost" size="icon" title="Convert to Invoice" onClick={() => convertToInvoice(q)}>
                              <ArrowRight className="h-4 w-4 text-success" />
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" title="Print" onClick={() => printQuotation(q)}>
                            <Printer className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(q)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(q.id)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Quotation' : 'New Quotation'}</DialogTitle>
            <DialogDescription>Create a quotation with GST and terms. Can be converted to invoice later.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Customer (optional)</Label>
              <Select value={form.customer_id} onValueChange={(v) => setForm({ ...form, customer_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select customer (or leave blank)" /></SelectTrigger>
                <SelectContent>
                  {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.name} - {c.company}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Product</Label>
              <Select
                value={form.product_id}
                onValueChange={(v) => {
                  const p = products.find((p) => p.id === v);
                  setForm({ ...form, product_id: v, unit_price: p ? Number(p.selling_price) : form.unit_price });
                }}
              >
                <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
                <SelectContent>
                  {products.map((p) => (
                    <SelectItem key={p.id} value={p.id}>{p.code} - {p.name} - {formatCurrency(p.selling_price)}/{p.unit}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Quantity</Label>
              <Input type="number" step="0.001" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Unit Price (₹)</Label>
              <Input type="number" step="0.01" value={form.unit_price} onChange={(e) => setForm({ ...form, unit_price: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>GST Rate (%)</Label>
              <Input type="number" step="0.01" value={form.tax_rate} onChange={(e) => setForm({ ...form, tax_rate: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Valid Until</Label>
              <Input type="date" value={form.valid_until} onChange={(e) => setForm({ ...form, valid_until: e.target.value })} />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Terms & Conditions</Label>
              <Textarea value={form.terms} onChange={(e) => setForm({ ...form, terms: e.target.value })} rows={5} />
            </div>
          </div>

          <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
            <div className="flex justify-between"><span>Subtotal:</span><span className="font-medium">{formatCurrency(subtotal)}</span></div>
            <div className="flex justify-between"><span>GST ({form.tax_rate}%):</span><span className="font-medium">{formatCurrency(taxAmount)}</span></div>
            <div className="flex justify-between font-bold text-base border-t border-border pt-2"><span>Total:</span><span>{formatCurrency(totalAmount)}</span></div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Create'} Quotation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Quotation?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the quotation. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
