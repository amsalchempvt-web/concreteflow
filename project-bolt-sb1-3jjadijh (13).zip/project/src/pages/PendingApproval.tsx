import { Clock, Building2, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';

export default function PendingApproval() {
  const { profile, signOut } = useAuth();

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-6">
      <div className="max-w-md w-full space-y-6 text-center">
        <div className="mx-auto h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
          <Clock className="h-10 w-10 text-primary" />
        </div>
        <div className="space-y-2">
          <h1 className="text-2xl font-bold">Awaiting Admin Approval</h1>
          <p className="text-muted-foreground">
            Hi {profile?.full_name || profile?.email}, your account has been created successfully.
          </p>
          <p className="text-muted-foreground">
            You don't have access to any company workspace yet. Please contact your company admin to be assigned to a company and granted module permissions.
          </p>
        </div>
        <div className="rounded-lg border bg-card p-4 space-y-2 text-left">
          <div className="flex items-center gap-2 text-sm">
            <Building2 className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">Your email:</span>
            <span className="font-medium">{profile?.email}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">Status:</span>
            <span className="font-medium text-amber-600">Pending assignment</span>
          </div>
        </div>
        <Button variant="outline" onClick={() => signOut()} className="w-full">
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}
