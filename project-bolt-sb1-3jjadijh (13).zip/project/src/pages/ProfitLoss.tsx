import { useEffect, useState, useMemo } from 'react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Wallet, Percent, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { SalesInvoice, Expense, Production, FinishedProduct } from '@/lib/supabase';
import { PageHeader, StatCard, formatCurrency } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const PIE_COLORS = ['hsl(200, 85%, 42%)', 'hsl(142, 71%, 38%)', 'hsl(38, 92%, 50%)', 'hsl(0, 72%, 51%)', 'hsl(270, 65%, 55%)', 'hsl(200, 85%, 60%)', 'hsl(142, 71%, 55%)'];

export default function ProfitLoss() {
  const [invoices, setInvoices] = useState<SalesInvoice[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [productions, setProductions] = useState<Production[]>([]);
  const [products, setProducts] = useState<FinishedProduct[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [invs, exps, prods, fps] = await Promise.all([
        supabase.from('sales_invoices').select('*, product:finished_products(*)').then((r) => r),
        supabase.from('expenses').select('*').then((r) => r),
        supabase.from('productions').select('*, product:finished_products(*)').then((r) => r),
        supabase.from('finished_products').select('*').then((r) => r),
      ]);
      setInvoices((invs.data as SalesInvoice[]) || []);
      setExpenses((exps.data as Expense[]) || []);
      setProductions((prods.data as Production[]) || []);
      setProducts((fps.data as FinishedProduct[]) || []);
      setLoading(false);
    })();
  }, []);

  const metrics = useMemo(() => {
    const totalSales = invoices.reduce((s, inv) => s + Number(inv.total_amount), 0);
    const totalProductionCost = productions.reduce((s, p) => s + Number(p.total_cost), 0);
    const totalExpenses = expenses.reduce((s, e) => s + Number(e.amount), 0);
    const grossProfit = totalSales - totalProductionCost;
    const netProfit = grossProfit - totalExpenses;

    return { totalSales, totalProductionCost, totalExpenses, grossProfit, netProfit };
  }, [invoices, expenses, productions]);

  // Monthly P&L chart
  const monthlyData = useMemo(() => {
    const months: { month: string; sales: number; costs: number; profit: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const m = d.getMonth();
      const y = d.getFullYear();
      const monthName = d.toLocaleString('en-US', { month: 'short' });

      const sales = invoices.filter((inv) => {
        const id = new Date(inv.invoice_date);
        return id.getMonth() === m && id.getFullYear() === y;
      }).reduce((s, inv) => s + Number(inv.total_amount), 0);

      const prodCost = productions.filter((p) => {
        const pd = new Date(p.production_date);
        return pd.getMonth() === m && pd.getFullYear() === y;
      }).reduce((s, p) => s + Number(p.total_cost), 0);

      const expCost = expenses.filter((e) => {
        const ed = new Date(e.expense_date);
        return ed.getMonth() === m && ed.getFullYear() === y;
      }).reduce((s, e) => s + Number(e.amount), 0);

      months.push({ month: monthName, sales, costs: prodCost + expCost, profit: sales - prodCost - expCost });
    }
    return months;
  }, [invoices, expenses, productions]);

  // Daily profit (last 30 days)
  const dailyData = useMemo(() => {
    const days: { day: string; profit: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayLabel = d.toLocaleDateString('en-US', { day: '2-digit', month: 'short' });

      const sales = invoices.filter((inv) => inv.invoice_date === dateStr).reduce((s, inv) => s + Number(inv.total_amount), 0);
      const prodCost = productions.filter((p) => p.production_date === dateStr).reduce((s, p) => s + Number(p.total_cost), 0);
      const expCost = expenses.filter((e) => e.expense_date === dateStr).reduce((s, e) => s + Number(e.amount), 0);

      days.push({ day: dayLabel, profit: sales - prodCost - expCost });
    }
    return days;
  }, [invoices, expenses, productions]);

  // Product-wise profit
  const productProfitData = useMemo(() => {
    const map: Record<string, { name: string; sales: number; cost: number; profit: number }> = {};
    invoices.forEach((inv) => {
      const name = inv.product?.name || 'Unknown';
      if (!map[name]) map[name] = { name, sales: 0, cost: 0, profit: 0 };
      map[name].sales += Number(inv.total_amount);
    });
    productions.forEach((p) => {
      const name = p.product?.name || 'Unknown';
      if (!map[name]) map[name] = { name, sales: 0, cost: 0, profit: 0 };
      map[name].cost += Number(p.total_cost);
    });
    Object.values(map).forEach((v) => { v.profit = v.sales - v.cost; });
    return Object.values(map).filter((v) => v.sales > 0 || v.cost > 0);
  }, [invoices, productions]);

  // Customer-wise sales
  const customerSalesData = useMemo(() => {
    const map: Record<string, number> = {};
    invoices.forEach((inv) => {
      const name = inv.customer?.name || 'Unknown';
      map[name] = (map[name] || 0) + Number(inv.total_amount);
    });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 8);
  }, [invoices]);

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Profit & Loss Dashboard" description="Automated financial analysis and profit tracking" />

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Sales" value={formatCurrency(metrics.totalSales)} icon={<DollarSign className="h-5 w-5" />} variant="success" />
        <StatCard title="Production Cost" value={formatCurrency(metrics.totalProductionCost)} icon={<TrendingDown className="h-5 w-5" />} variant="error" />
        <StatCard title="Operating Expenses" value={formatCurrency(metrics.totalExpenses)} icon={<Wallet className="h-5 w-5" />} variant="warning" />
        <StatCard
          title="Net Profit"
          value={formatCurrency(metrics.netProfit)}
          icon={<TrendingUp className="h-5 w-5" />}
          variant={metrics.netProfit >= 0 ? 'success' : 'error'}
        />
      </div>

      {/* P&L Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Profit & Loss Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between py-2 border-b">
              <span className="text-muted-foreground">Total Sales Revenue</span>
              <span className="font-semibold text-success">{formatCurrency(metrics.totalSales)}</span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="text-muted-foreground">Less: Production Cost</span>
              <span className="font-semibold text-destructive">- {formatCurrency(metrics.totalProductionCost)}</span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="font-medium">Gross Profit</span>
              <span className={`font-bold ${metrics.grossProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                {formatCurrency(metrics.grossProfit)}
              </span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="text-muted-foreground">Less: Operating Expenses</span>
              <span className="font-semibold text-destructive">- {formatCurrency(metrics.totalExpenses)}</span>
            </div>
            <div className="flex justify-between py-3 bg-muted/50 rounded-lg px-3">
              <span className="font-bold">Net Profit / Loss</span>
              <span className={`font-display text-xl font-bold ${metrics.netProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                {formatCurrency(metrics.netProfit)}
              </span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-muted-foreground">Profit Margin</span>
              <Badge variant={metrics.netProfit >= 0 ? 'default' : 'destructive'}>
                {metrics.totalSales > 0 ? ((metrics.netProfit / metrics.totalSales) * 100).toFixed(1) : '0'}%
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Monthly P&L Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Monthly Profit / Loss (6 Months)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(142, 71%, 38%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(142, 71%, 38%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '13px' }}
                formatter={(value: number) => formatCurrency(value)}
              />
              <Legend />
              <Area type="monotone" dataKey="sales" name="Sales" stroke="hsl(200, 85%, 42%)" strokeWidth={2} fillOpacity={0} />
              <Area type="monotone" dataKey="costs" name="Costs" stroke="hsl(0, 72%, 51%)" strokeWidth={2} fillOpacity={0} />
              <Area type="monotone" dataKey="profit" name="Profit" stroke="hsl(142, 71%, 38%)" fillOpacity={1} fill="url(#colorProfit)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Daily Profit Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Daily Profit (Last 30 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={dailyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={10} interval={3} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '13px' }}
                formatter={(value: number) => formatCurrency(value)}
              />
              <Bar dataKey="profit" name="Profit" radius={[2, 2, 0, 0]}>
                {dailyData.map((entry, i) => (
                  <Cell key={i} fill={entry.profit >= 0 ? 'hsl(142, 71%, 38%)' : 'hsl(0, 72%, 51%)'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Product-wise Profit */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Product-wise Profit</CardTitle>
          </CardHeader>
          <CardContent>
            {productProfitData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No data available.</p>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={productProfitData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '13px' }}
                    formatter={(value: number) => formatCurrency(value)}
                  />
                  <Bar dataKey="sales" name="Sales" fill="hsl(200, 85%, 42%)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="cost" name="Cost" fill="hsl(0, 72%, 51%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Customer-wise Sales */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Customer-wise Sales</CardTitle>
          </CardHeader>
          <CardContent>
            {customerSalesData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No sales data available.</p>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={customerSalesData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} innerRadius={50} paddingAngle={2}>
                    {customerSalesData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '13px' }}
                    formatter={(value: number) => formatCurrency(value)}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
