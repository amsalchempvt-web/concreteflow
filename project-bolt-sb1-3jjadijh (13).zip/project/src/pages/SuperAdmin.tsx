import { useCallback, useEffect, useState } from 'react';
import { Building2, Plus, RefreshCw, ShieldCheck, UserPlus } from 'lucide-react';
import { supabase, type Company, type Profile, type UserRole } from '@/lib/supabase';
import { useAuth } from '@/hooks/use-auth';
import { PageHeader } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';

const emptyCompany = { name: '', gst_number: '', address: '', contact: '', email: '', logo_url: '', pan_number: '', state_code: '', tagline: '' };
const emptyUser = { email: '', password: '', full_name: '', role: 'admin' as UserRole, company_id: '' };

export default function SuperAdmin() {
  const { profile } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [companyOpen, setCompanyOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const [company, setCompany] = useState(emptyCompany);
  const [user, setUser] = useState(emptyUser);

  const load = useCallback(async () => {
    const [companyResult, userResult] = await Promise.all([
      supabase.from('companies').select('*').order('name'),
      supabase.from('profiles').select('*, company:companies(*)').order('created_at', { ascending: false }),
    ]);
    setCompanies((companyResult.data as Company[]) || []);
    setUsers((userResult.data as Profile[]) || []);
  }, []);
  useEffect(() => { load(); }, [load]);

  const createCompany = async () => {
    if (!company.name.trim()) { toast.error('Company name is required'); return; }
    const { error } = await supabase.from('companies').insert(company);
    if (error) { toast.error('Could not create company'); return; }
    toast.success('Company created'); setCompany(emptyCompany); setCompanyOpen(false); load();
  };

  const createUser = async () => {
    if (!user.email || !user.password || !user.full_name || !user.company_id) { toast.error('Name, email, password, and company are required'); return; }
    const { data: sessionData } = await supabase.auth.getSession();
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${sessionData.session?.access_token}`, apikey: import.meta.env.VITE_SUPABASE_ANON_KEY },
      body: JSON.stringify(user),
    });
    if (!response.ok) { toast.error('Could not create user'); return; }
    toast.success('User created'); setUser(emptyUser); setUserOpen(false); load();
  };

  if (profile?.role !== 'super_admin') return <Card><CardContent className="p-8 text-center">You do not have access to platform administration.</CardContent></Card>;

  return (
    <div className="space-y-6">
      <PageHeader title="Platform Administration" description="Only the super admin can create companies and their first users">
        <Button variant="outline" onClick={load}><RefreshCw className="h-4 w-4 mr-2" /> Refresh</Button>
        <Button variant="outline" onClick={() => setCompanyOpen(true)}><Plus className="h-4 w-4 mr-2" /> New Company</Button>
        <Button onClick={() => setUserOpen(true)}><UserPlus className="h-4 w-4 mr-2" /> New User</Button>
      </PageHeader>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Building2 className="h-5 w-5 text-primary" /> Companies</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Contact</TableHead></TableRow></TableHeader>
              <TableBody>
                {companies.map((item) => <TableRow key={item.id}><TableCell className="font-medium">{item.name}</TableCell><TableCell>{item.contact || item.email || '—'}</TableCell></TableRow>)}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-primary" /> Users</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Role</TableHead></TableRow></TableHeader>
              <TableBody>
                {users.map((item) => <TableRow key={item.id}><TableCell><div className="font-medium">{item.full_name || 'Unnamed'}</div><div className="text-xs text-muted-foreground">{item.email}</div></TableCell><TableCell>{item.role}</TableCell></TableRow>)}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <Dialog open={companyOpen} onOpenChange={setCompanyOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Company</DialogTitle>
            <DialogDescription>Create a workspace before adding its company administrator.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {(['name', 'tagline', 'gst_number', 'pan_number', 'state_code', 'contact', 'email', 'address', 'logo_url'] as (keyof typeof company)[]).map((key) => (
              <div className="space-y-2" key={key}><Label>{key.replace(/_/g, ' ')}</Label><Input value={company[key]} onChange={(e) => setCompany({ ...company, [key]: e.target.value })} /></div>
            ))}
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setCompanyOpen(false)}>Cancel</Button><Button onClick={createCompany}>Create Company</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={userOpen} onOpenChange={setUserOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Company User</DialogTitle>
            <DialogDescription>Create the first administrator or another staff user for a company.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Full name</Label><Input value={user.full_name} onChange={(e) => setUser({ ...user, full_name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Email</Label><Input type="email" value={user.email} onChange={(e) => setUser({ ...user, email: e.target.value })} /></div>
            <div className="space-y-2"><Label>Temporary password</Label><Input type="password" value={user.password} onChange={(e) => setUser({ ...user, password: e.target.value })} /></div>
            <div className="space-y-2"><Label>Company</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={user.company_id} onChange={(e) => setUser({ ...user, company_id: e.target.value })}>
                <option value="">Select company</option>
                {companies.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
              </select>
            </div>
            <div className="space-y-2"><Label>Role</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={user.role} onChange={(e) => setUser({ ...user, role: e.target.value as UserRole })}>
                <option value="super_admin">Super Admin</option>
                <option value="admin">Admin</option>
                <option value="manager">Manager</option>
                <option value="accountant">Accountant</option>
                <option value="plant_operator">Plant Operator</option>
                <option value="sales_executive">Sales Executive</option>
              </select>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setUserOpen(false)}>Cancel</Button><Button onClick={createUser}>Create User</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
