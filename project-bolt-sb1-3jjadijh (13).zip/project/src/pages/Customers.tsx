import { useEffect, useState, useCallback } from 'react';
import { Plus, Users, Download, Search, Pencil, Trash2, Phone, Mail, MapPin } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Customer, SalesInvoice } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatDate } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { exportToCSV, exportToExcel } from '@/lib/export';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

export default function Customers() {
  const { profile } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [invoices, setInvoices] = useState<SalesInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [historyCustomer, setHistoryCustomer] = useState<Customer | null>(null);

  const [form, setForm] = useState({
    name: '', company: '', mobile: '', email: '', address: '', gst_number: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [custs, invs] = await Promise.all([
      supabase.from('customers').select('*').order('name').then((r) => r),
      supabase.from('sales_invoices').select('*').order('created_at', { ascending: false }).then((r) => r),
    ]);
    setCustomers((custs.data as Customer[]) || []);
    setInvoices((invs.data as SalesInvoice[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', company: '', mobile: '', email: '', address: '', gst_number: '' });
    setDialogOpen(true);
  };

  const openEdit = (c: Customer) => {
    setEditing(c);
    setForm({
      name: c.name, company: c.company, mobile: c.mobile, email: c.email,
      address: c.address, gst_number: c.gst_number,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name) { toast.error('Name is required'); return; }
    const payload = { ...form };
    if (editing) {
      const { error } = await supabase.from('customers').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success('Customer updated');
    } else {
      const { error } = await supabase.from('customers').insert(payload);
      if (error) { toast.error(error.message); return; }
      await supabase.from('activity_logs').insert({
        user_email: profile?.email || '',
        action: 'customer_added',
        entity: 'customer',
        details: form.name,
      });
      toast.success('Customer added');
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('customers').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Customer deleted');
    setDeleteId(null);
    fetchData();
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Name', 'Company', 'Mobile', 'Email', 'GST', 'Address', 'Outstanding'];
    const rows = filtered.map((c) => [c.name, c.company, c.mobile, c.email, c.gst_number, c.address, c.outstanding_balance]);
    if (format === 'csv') exportToCSV('customers', headers, rows);
    else exportToExcel('customers', headers, rows);
    toast.success('Exported successfully');
  };

  const filtered = customers.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.company.toLowerCase().includes(search.toLowerCase()) ||
    c.mobile.includes(search) ||
    c.gst_number.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Customer Management" description="Manage customer details, GST info, and outstanding balances">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4 mr-2" /> Add Customer
        </Button>
      </PageHeader>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search customers..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<Users className="h-6 w-6" />}
              title="No customers found"
              description="Add your first customer to start tracking sales and outstanding balances."
              action={<Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> Add Customer</Button>}
            />
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => {
            const customerInvoices = invoices.filter((inv) => inv.customer_id === c.id);
            const totalPurchased = customerInvoices.reduce((s, inv) => s + Number(inv.total_amount), 0);
            return (
              <Card key={c.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="min-w-0">
                      <h3 className="font-display font-bold truncate">{c.name}</h3>
                      <p className="text-sm text-muted-foreground truncate">{c.company || '-'}</p>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button variant="ghost" size="icon" title="Purchase History" onClick={() => setHistoryCustomer(c)}>
                        <Users className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(c)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(c.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1.5 text-sm">
                    {c.mobile && <div className="flex items-center gap-2 text-muted-foreground"><Phone className="h-3.5 w-3.5" /> {c.mobile}</div>}
                    {c.email && <div className="flex items-center gap-2 text-muted-foreground"><Mail className="h-3.5 w-3.5" /> <span className="truncate">{c.email}</span></div>}
                    {c.address && <div className="flex items-center gap-2 text-muted-foreground"><MapPin className="h-3.5 w-3.5" /> <span className="truncate">{c.address}</span></div>}
                  </div>
                  <div className="mt-4 pt-3 border-t border-border grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground">GST Number</p>
                      <p className="font-medium">{c.gst_number || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Outstanding</p>
                      <p className={`font-semibold ${Number(c.outstanding_balance) > 0 ? 'text-destructive' : 'text-success'}`}>
                        {formatCurrency(Number(c.outstanding_balance))}
                      </p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-xs text-muted-foreground">Total Purchased</p>
                      <p className="font-medium">{formatCurrency(totalPurchased)} ({customerInvoices.length} invoices)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Customer' : 'Add Customer'}</DialogTitle>
            <DialogDescription>{editing ? 'Update customer details.' : 'Enter customer information.'}</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Customer Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Company</Label>
              <Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Mobile</Label>
              <Input value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>GST Number</Label>
              <Input value={form.gst_number} onChange={(e) => setForm({ ...form, gst_number: e.target.value })} />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Address</Label>
              <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Add'} Customer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={!!historyCustomer} onOpenChange={(o) => !o && setHistoryCustomer(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Purchase History - {historyCustomer?.name}</DialogTitle>
            <DialogDescription>All invoices for this customer</DialogDescription>
          </DialogHeader>
          <div className="max-h-[400px] overflow-y-auto scrollbar-thin">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.filter((inv) => inv.customer_id === historyCustomer?.id).length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground py-8">No purchases yet.</TableCell>
                  </TableRow>
                ) : (
                  invoices.filter((inv) => inv.customer_id === historyCustomer?.id).map((inv) => (
                    <TableRow key={inv.id}>
                      <TableCell className="font-mono text-sm">{inv.invoice_number}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(inv.invoice_date)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(Number(inv.total_amount))}</TableCell>
                      <TableCell><Badge variant={inv.payment_status === 'paid' ? 'default' : 'destructive'}>{inv.payment_status}</Badge></TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Customer?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the customer. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
