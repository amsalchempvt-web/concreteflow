import { useEffect, useState, useCallback } from 'react';
import { UserCog, Plus, Shield, Building2, RefreshCw, Lock, Unlock, Save, X, UserCheck, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Profile, UserRole, UserPermission, Company, ModuleKey } from '@/lib/supabase';
import { NAV_ITEMS, ROLE_LABELS, MODULE_LABELS } from '@/lib/navigation';
import { PageHeader, EmptyState, formatDate } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

const ROLES: UserRole[] = ['admin', 'manager', 'accountant', 'plant_operator', 'sales_executive'];

export default function UserManagement() {
  const { profile: currentUser } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [permissions, setPermissions] = useState<Record<string, UserPermission[]>>({});
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);

  const [createOpen, setCreateOpen] = useState(false);
  const [permUser, setPermUser] = useState<Profile | null>(null);
  const [companyDialogOpen, setCompanyDialogOpen] = useState(false);

  const [createForm, setCreateForm] = useState({
    email: '', password: '', full_name: '', role: 'plant_operator' as UserRole, company_id: '',
  });
  const [creating, setCreating] = useState(false);

  const [approveUser, setApproveUser] = useState<Profile | null>(null);
  const [approveRole, setApproveRole] = useState<UserRole>('plant_operator');

  const [permDraft, setPermDraft] = useState<Record<string, boolean>>({});
  const [savingPerms, setSavingPerms] = useState(false);

  const [companyForm, setCompanyForm] = useState({
    name: '', gst_number: '', address: '', contact: '', email: '', logo_url: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [usersRes, permsRes, compsRes] = await Promise.all([
      supabase.from('profiles').select('*, company:companies(*)').order('created_at', { ascending: false }).then((r) => r),
      supabase.from('user_permissions').select('*').then((r) => r),
      supabase.from('companies').select('*').order('name').then((r) => r),
    ]);
    const userList = (usersRes.data as (Profile & { company: Company })[]) || [];
    setUsers(userList);

    const permList = (permsRes.data as UserPermission[]) || [];
    const permMap: Record<string, UserPermission[]> = {};
    permList.forEach((p) => {
      if (!permMap[p.user_id]) permMap[p.user_id] = [];
      permMap[p.user_id].push(p);
    });
    setPermissions(permMap);
    setCompanies((compsRes.data as Company[]) || []);

    // Pre-fill company form with first company
    if (compsRes.data && compsRes.data.length > 0) {
      const c = compsRes.data[0] as Company;
      setCompanyForm({
        name: c.name, gst_number: c.gst_number, address: c.address,
        contact: c.contact, email: c.email, logo_url: c.logo_url,
      });
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleCreateUser = async () => {
    if (!createForm.email || !createForm.password || !createForm.full_name) {
      toast.error('Email, password, and name are required');
      return;
    }
    if (createForm.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    setCreating(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-user`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            email: createForm.email,
            password: createForm.password,
            full_name: createForm.full_name,
            role: createForm.role,
            company_id: createForm.company_id || null,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        const errMsg = result.error || `Failed to create user (status ${response.status})`;
        toast.error(errMsg);
        setCreating(false);
        return;
      }

      toast.success(`User ${createForm.email} created successfully`);
      setCreating(false);
      setCreateOpen(false);
      setCreateForm({ email: '', password: '', full_name: '', role: 'plant_operator', company_id: '' });
      fetchData();
    } catch {
      toast.error('Failed to create user. Please try again.');
      setCreating(false);
    }
  };

  const openPermissions = (user: Profile) => {
    setPermUser(user);
    // Build draft from existing permissions or defaults from role
    const userPerms = permissions[user.id] || [];
    const draft: Record<string, boolean> = {};
    NAV_ITEMS.forEach((item) => {
      const existing = userPerms.find((p) => p.module === item.moduleKey);
      if (existing) {
        draft[item.moduleKey] = existing.allowed;
      } else {
        draft[item.moduleKey] = item.roles.includes(user.role);
      }
    });
    setPermDraft(draft);
  };

  const savePermissions = async () => {
    if (!permUser) return;
    setSavingPerms(true);

    // Delete all existing permissions for this user
    await supabase.from('user_permissions').delete().eq('user_id', permUser.id);

    // Insert new permissions (only save overrides that differ from role defaults)
    const inserts = NAV_ITEMS.map((item) => {
      const allowed = permDraft[item.moduleKey];
      const roleDefault = item.roles.includes(permUser.role);
      // Only save if it differs from the role default
      if (allowed !== roleDefault) {
        return {
          user_id: permUser.id,
          module: item.moduleKey,
          allowed,
        };
      }
      return null;
    }).filter(Boolean);

    if (inserts.length > 0) {
      const { error } = await supabase.from('user_permissions').insert(inserts);
      if (error) {
        toast.error(error.message);
        setSavingPerms(false);
        return;
      }
    }

    await supabase.from('activity_logs').insert({
      user_email: currentUser?.email || '',
      action: 'permissions_updated',
      entity: 'user_permissions',
      details: `Updated module access for ${permUser.email}`,
    });

    toast.success('Module access rights updated');
    setSavingPerms(false);
    setPermUser(null);
    fetchData();
  };

  const updateUserRole = async (userId: string, newRole: UserRole) => {
    const { error } = await supabase.from('profiles').update({ role: newRole }).eq('id', userId);
    if (error) { toast.error(error.message); return; }
    toast.success('Role updated');
    fetchData();
  };

  const updateUserCompany = async (userId: string, companyId: string) => {
    const { error } = await supabase.from('profiles').update({ company_id: companyId || null }).eq('id', userId);
    if (error) { toast.error(error.message); return; }
    toast.success('Company assigned');
    fetchData();
  };

  const approvePendingUser = async () => {
    if (!approveUser || !currentUser?.company_id) return;
    const { error } = await supabase
      .from('profiles')
      .update({ role: approveRole, company_id: currentUser.company_id })
      .eq('id', approveUser.id);
    if (error) { toast.error(error.message); return; }

    await supabase.from('activity_logs').insert({
      user_email: currentUser?.email || '',
      action: 'user_approved',
      entity: 'profiles',
      entity_id: approveUser.id,
      details: `Approved ${approveUser.email} as ${ROLE_LABELS[approveRole]}`,
    });

    toast.success(`${approveUser.full_name || approveUser.email} approved and assigned to your company`);
    setApproveUser(null);
    setApproveRole('plant_operator');
    fetchData();
  };

  const rejectPendingUser = async (userId: string, userEmail: string) => {
    const { error } = await supabase.from('profiles').delete().eq('id', userId);
    if (error) { toast.error(error.message); return; }

    await supabase.from('activity_logs').insert({
      user_email: currentUser?.email || '',
      action: 'user_rejected',
      entity: 'profiles',
      entity_id: userId,
      details: `Rejected signup request from ${userEmail}`,
    });

    toast.success('Signup request rejected');
    fetchData();
  };

  const saveCompany = async () => {
    if (!companyForm.name) { toast.error('Company name is required'); return; }
    if (companies.length > 0) {
      const { error } = await supabase.from('companies').update(companyForm).eq('id', companies[0].id);
      if (error) { toast.error(error.message); return; }
      toast.success('Company details updated');
    } else {
      toast.error('Company is created automatically on signup');
    }
    setCompanyDialogOpen(false);
    fetchData();
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="User Management" description="Create users, assign roles, and customize module access rights">
        <Button variant="outline" size="sm" onClick={() => setCompanyDialogOpen(true)}>
          <Building2 className="h-4 w-4 mr-2" /> Company Settings
        </Button>
        <Button variant="outline" size="sm" onClick={fetchData}>
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="h-4 w-4 mr-2" /> Create User
        </Button>
      </PageHeader>

      {/* Company info banner */}
      {companies.length > 0 && (
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Building2 className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="font-semibold">{companies[0].name}</p>
              <p className="text-sm text-muted-foreground">
                GST: {companies[0].gst_number || 'N/A'} | {companies[0].contact || 'No contact'} | {companies[0].email || 'No email'}
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setCompanyDialogOpen(true)}>
              Edit
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Pending users section */}
      {users.filter((u) => !u.company_id).length > 0 && (
        <Card className="border-amber-200 bg-amber-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-600" />
              Pending Approval
              <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-300">
                {users.filter((u) => !u.company_id).length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-amber-200">
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Signup Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.filter((u) => !u.company_id).map((u) => (
                    <TableRow key={u.id} className="border-amber-100">
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-semibold text-sm">
                            {u.full_name?.charAt(0)?.toUpperCase() || '?'}
                          </div>
                          {u.full_name || 'Unnamed'}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{u.email}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(u.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          size="sm"
                          onClick={() => { setApproveUser(u); setApproveRole('plant_operator'); }}
                        >
                          <UserCheck className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="ml-2"
                          onClick={() => rejectPendingUser(u.id, u.email)}
                        >
                          Reject
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Active users table */}
      <div>
        <h3 className="text-sm font-medium text-muted-foreground mb-3">Active Users</h3>
      </div>
      {users.filter((u) => u.company_id).length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<UserCog className="h-6 w-6" />}
              title="No users found"
              description="Create your first user to get started."
              action={<Button onClick={() => setCreateOpen(true)}><Plus className="h-4 w-4 mr-2" /> Create User</Button>}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.filter((u) => u.company_id).map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm">
                            {u.full_name?.charAt(0)?.toUpperCase() || '?'}
                          </div>
                          {u.full_name || 'Unnamed'}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{u.email}</TableCell>
                      <TableCell>
                        {u.id === currentUser?.id ? (
                          <Badge>{ROLE_LABELS[u.role]}</Badge>
                        ) : (
                          <Select
                            value={u.role}
                            onValueChange={(v) => updateUserRole(u.id, v as UserRole)}
                          >
                            <SelectTrigger className="w-36 h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {ROLES.map((r) => (
                                <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      </TableCell>
                      <TableCell>
                        <Select
                          value={u.company_id || 'none'}
                          onValueChange={(v) => updateUserCompany(u.id, v === 'none' ? '' : v)}
                        >
                          <SelectTrigger className="w-40 h-8">
                            <SelectValue placeholder="No company" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">No company</SelectItem>
                            {companies.map((c) => (
                              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(u.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openPermissions(u)}
                          disabled={u.role === 'admin' || u.id === currentUser?.id}
                        >
                          <Shield className="h-4 w-4 mr-2" />
                          Access Rights
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create User Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
            <DialogDescription>
              Create a new user account with a specific role and company. You can customize their module access after creation.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Full Name</Label>
              <Input value={createForm.full_name} onChange={(e) => setCreateForm({ ...createForm, full_name: e.target.value })} placeholder="John Doe" />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" value={createForm.email} onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })} placeholder="user@company.com" />
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" value={createForm.password} onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })} placeholder="Min 6 characters" />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={createForm.role} onValueChange={(v) => setCreateForm({ ...createForm, role: v as UserRole })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Company</Label>
              <Select value={createForm.company_id || 'none'} onValueChange={(v) => setCreateForm({ ...createForm, company_id: v === 'none' ? '' : v })}>
                <SelectTrigger><SelectValue placeholder="No company" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No company</SelectItem>
                  {companies.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateUser} disabled={creating}>
              {creating ? 'Creating...' : 'Create User'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Permissions Dialog */}
      <Dialog open={!!permUser} onOpenChange={(o) => !o && setPermUser(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Customize Module Access - {permUser?.full_name || permUser?.email}</DialogTitle>
            <DialogDescription>
              Toggle which modules this user can access. Defaults are based on their role ({permUser ? ROLE_LABELS[permUser.role] : ''}),
              but you can override any module below.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1 max-h-[450px] overflow-y-auto scrollbar-thin">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isOn = permDraft[item.moduleKey] ?? false;
              const isDefault = item.roles.includes(permUser?.role || 'plant_operator');
              return (
                <div
                  key={item.moduleKey}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 border border-transparent hover:border-border transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${isOn ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                      <Icon className="h-4.5 w-4.5" style={{ width: '1.125rem', height: '1.125rem' }} />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{item.label}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.group} | Default: {isDefault ? 'Allowed' : 'Hidden'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isOn !== isDefault && (
                      <Badge variant="outline" className="text-xs">
                        {isOn ? <Unlock className="h-3 w-3 mr-1" /> : <Lock className="h-3 w-3 mr-1" />}
                        Override
                      </Badge>
                    )}
                    <Switch
                      checked={isOn}
                      onCheckedChange={(checked) => setPermDraft({ ...permDraft, [item.moduleKey]: checked })}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPermUser(null)}>Cancel</Button>
            <Button onClick={savePermissions} disabled={savingPerms}>
              {savingPerms ? 'Saving...' : 'Save Access Rights'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Company Settings Dialog */}
      <Dialog open={companyDialogOpen} onOpenChange={setCompanyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Company Settings</DialogTitle>
            <DialogDescription>
              Configure your company details. These appear on invoices, quotations, and reports.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Company Name</Label>
              <Input value={companyForm.name} onChange={(e) => setCompanyForm({ ...companyForm, name: e.target.value })} placeholder="Company name" />
            </div>
            <div className="space-y-2">
              <Label>GST Number</Label>
              <Input value={companyForm.gst_number} onChange={(e) => setCompanyForm({ ...companyForm, gst_number: e.target.value })} placeholder="27AABCC1234D1Z9" />
            </div>
            <div className="space-y-2">
              <Label>Contact Number</Label>
              <Input value={companyForm.contact} onChange={(e) => setCompanyForm({ ...companyForm, contact: e.target.value })} placeholder="+91 98765 43210" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Email</Label>
              <Input type="email" value={companyForm.email} onChange={(e) => setCompanyForm({ ...companyForm, email: e.target.value })} placeholder="info@company.com" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Address</Label>
              <Textarea value={companyForm.address} onChange={(e) => setCompanyForm({ ...companyForm, address: e.target.value })} rows={2} placeholder="Full address" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Logo URL (optional)</Label>
              <Input value={companyForm.logo_url} onChange={(e) => setCompanyForm({ ...companyForm, logo_url: e.target.value })} placeholder="https://..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCompanyDialogOpen(false)}>Cancel</Button>
            <Button onClick={saveCompany}>Save Company</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approve Pending User Dialog */}
      <Dialog open={!!approveUser} onOpenChange={(o) => !o && setApproveUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve User</DialogTitle>
            <DialogDescription>
              Assign a role to {approveUser?.full_name || approveUser?.email}. They will be added to your company and gain access based on this role.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg border p-3 bg-muted/50 text-sm">
              <div className="flex justify-between py-1">
                <span className="text-muted-foreground">Name:</span>
                <span className="font-medium">{approveUser?.full_name || 'Unnamed'}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">{approveUser?.email}</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Assign Role</Label>
              <Select value={approveRole} onValueChange={(v) => setApproveRole(v as UserRole)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setApproveUser(null)}>Cancel</Button>
            <Button onClick={approvePendingUser}>
              <UserCheck className="h-4 w-4 mr-2" />
              Approve & Assign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
