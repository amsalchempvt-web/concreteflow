import { useEffect, useState, useCallback } from 'react';
import { Mail, MessageSquare, Bell, Save, TestTube, Loader2, CheckCircle2, XCircle, Trash2, History } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { PageHeader, EmptyState, formatDateTime } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';

interface NotificationSettings {
  id: string;
  email_enabled: boolean;
  smtp_host: string;
  smtp_port: number;
  smtp_username: string;
  smtp_password: string;
  smtp_from: string;
  whatsapp_enabled: boolean;
  whatsapp_phone_number_id: string;
  whatsapp_access_token: string;
  whatsapp_recipient_phone: string;
  alert_low_stock: boolean;
  alert_pending_payments: boolean;
  alert_outstanding_balance: boolean;
  alert_failed_production: boolean;
}

interface NotificationLog {
  id: string;
  channel: string;
  alert_type: string;
  recipient: string;
  subject: string | null;
  message: string;
  status: string;
  error: string | null;
  created_at: string;
}

const ALERT_LABELS: Record<string, string> = {
  low_stock: 'Low Stock',
  pending_payment: 'Pending Payment',
  outstanding_balance: 'Outstanding Balance',
  failed_production: 'Failed Production',
  test: 'Test Notification',
};

const DEFAULT_SETTINGS: Omit<NotificationSettings, 'id'> = {
  email_enabled: false,
  smtp_host: '',
  smtp_port: 587,
  smtp_username: '',
  smtp_password: '',
  smtp_from: '',
  whatsapp_enabled: false,
  whatsapp_phone_number_id: '',
  whatsapp_access_token: '',
  whatsapp_recipient_phone: '',
  alert_low_stock: true,
  alert_pending_payments: true,
  alert_outstanding_balance: true,
  alert_failed_production: true,
};

export default function NotificationSettings() {
  const [settings, setSettings] = useState<NotificationSettings | null>(null);
  const [logs, setLogs] = useState<NotificationLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [activeTab, setActiveTab] = useState('email');

  const loadSettings = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('notification_settings')
      .select('*')
      .limit(1)
      .maybeSingle();

    if (data) {
      setSettings(data as NotificationSettings);
    } else {
      setSettings({ id: '', ...DEFAULT_SETTINGS });
    }
    setLoading(false);
  }, []);

  const loadLogs = useCallback(async () => {
    const { data } = await supabase
      .from('notification_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    setLogs((data as NotificationLog[]) || []);
  }, []);

  useEffect(() => {
    loadSettings();
    loadLogs();
  }, [loadSettings, loadLogs]);

  const handleSave = async () => {
    if (!settings) return;
    setSaving(true);

    const payload = { ...settings };
    delete (payload as any).id;

    if (settings.id) {
      const { error } = await supabase
        .from('notification_settings')
        .update({ ...payload, updated_at: new Date().toISOString() })
        .eq('id', settings.id);
      if (error) toast.error('Failed to save settings');
      else toast.success('Notification settings saved');
    } else {
      const { data, error } = await supabase
        .from('notification_settings')
        .insert({ ...payload, updated_at: new Date().toISOString() })
        .select()
        .single();
      if (error) toast.error('Failed to save settings');
      else {
        toast.success('Notification settings saved');
        setSettings(data as NotificationSettings);
      }
    }
    setSaving(false);
  };

  const handleTest = async () => {
    if (!settings) return;
    setTesting(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-notification`;
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      const session = await supabase.auth.getSession();
      if (session.data.session?.access_token) {
        headers['Authorization'] = `Bearer ${session.data.session.access_token}`;
      }
      headers['apikey'] = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const resp = await fetch(apiUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          alert_type: 'test',
          subject: 'ConcreteFlow ERP - Test Notification',
          message: 'This is a test notification from ConcreteFlow ERP. If you received this, your notification setup is working correctly.',
        }),
      });

      if (!resp.ok) {
        const errBody = await resp.text();
        toast.error(`Test failed: ${errBody}`);
      } else {
        const result = await resp.json();
        if (result.sent) {
          toast.success('Test notification sent successfully');
        } else {
          toast.error(`Test notification not sent: ${result.reason || 'Unknown reason'}`);
        }
      }
      loadLogs();
    } catch (err) {
      toast.error(`Test failed: ${String(err)}`);
    }
    setTesting(false);
  };

  const updateField = (field: keyof NotificationSettings, value: any) => {
    setSettings((prev) => prev ? { ...prev, [field]: value } : prev);
  };

  const clearLogs = async () => {
    const { error } = await supabase.from('notification_logs').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    if (error) toast.error('Failed to clear logs');
    else {
      setLogs([]);
      toast.success('Logs cleared');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Notification Settings" description="Configure email and WhatsApp alerts for your ERP system">
        <Button variant="outline" onClick={handleTest} disabled={testing}>
          {testing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <TestTube className="h-4 w-4 mr-2" />}
          Send Test
        </Button>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          Save Settings
        </Button>
      </PageHeader>

      {/* Alert type toggles */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            Alert Types
          </CardTitle>
          <CardDescription>Choose which events trigger notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { key: 'alert_low_stock' as const, label: 'Low Raw Material Stock', desc: 'When material falls below minimum level' },
            { key: 'alert_pending_payments' as const, label: 'Pending Invoice Payments', desc: 'When invoices are unpaid or partially paid' },
            { key: 'alert_outstanding_balance' as const, label: 'Outstanding Customer Balance', desc: 'When customers have unpaid balances' },
            { key: 'alert_failed_production' as const, label: 'Failed Production Batch', desc: 'When a production batch fails due to insufficient stock' },
          ].map((alert) => (
            <div key={alert.key} className="flex items-center justify-between rounded-lg border border-border p-4">
              <div>
                <p className="font-medium text-sm">{alert.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{alert.desc}</p>
              </div>
              <Switch
                checked={settings?.[alert.key] ?? true}
                onCheckedChange={(v) => updateField(alert.key, v)}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Channel configuration */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="email" className="flex items-center gap-2">
            <Mail className="h-4 w-4" /> Email
          </TabsTrigger>
          <TabsTrigger value="whatsapp" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" /> WhatsApp
          </TabsTrigger>
        </TabsList>

        {/* Email Settings */}
        <TabsContent value="email" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-primary" />
                    Email Configuration
                  </CardTitle>
                  <CardDescription className="mt-1">SMTP settings for sending email alerts</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Enabled</span>
                  <Switch
                    checked={settings?.email_enabled ?? false}
                    onCheckedChange={(v) => updateField('email_enabled', v)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="smtp_host">SMTP Host</Label>
                  <Input
                    id="smtp_host"
                    placeholder="smtp.gmail.com"
                    value={settings?.smtp_host ?? ''}
                    onChange={(e) => updateField('smtp_host', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="smtp_port">SMTP Port</Label>
                  <Input
                    id="smtp_port"
                    type="number"
                    placeholder="587"
                    value={settings?.smtp_port ?? 587}
                    onChange={(e) => updateField('smtp_port', parseInt(e.target.value) || 587)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="smtp_username">SMTP Username</Label>
                  <Input
                    id="smtp_username"
                    placeholder="your-email@gmail.com"
                    value={settings?.smtp_username ?? ''}
                    onChange={(e) => updateField('smtp_username', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="smtp_password">SMTP Password / App Password</Label>
                  <Input
                    id="smtp_password"
                    type="password"
                    placeholder="••••••••"
                    value={settings?.smtp_password ?? ''}
                    onChange={(e) => updateField('smtp_password', e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp_from">From Email Address</Label>
                <Input
                  id="smtp_from"
                  placeholder="noreply@yourcompany.com"
                  value={settings?.smtp_from ?? ''}
                  onChange={(e) => updateField('smtp_from', e.target.value)}
                />
              </div>
              <div className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">
                For Gmail, use an App Password (not your regular password). Enable 2FA, then generate an App Password from your Google Account security settings.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* WhatsApp Settings */}
        <TabsContent value="whatsapp" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-success" />
                    WhatsApp Configuration
                  </CardTitle>
                  <CardDescription className="mt-1">WhatsApp Cloud API settings for sending alerts</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Enabled</span>
                  <Switch
                    checked={settings?.whatsapp_enabled ?? false}
                    onCheckedChange={(v) => updateField('whatsapp_enabled', v)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="wa_phone_id">Phone Number ID</Label>
                <Input
                  id="wa_phone_id"
                  placeholder="123456789012345"
                  value={settings?.whatsapp_phone_number_id ?? ''}
                  onChange={(e) => updateField('whatsapp_phone_number_id', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wa_token">Access Token</Label>
                <Input
                  id="wa_token"
                  type="password"
                  placeholder="EAAG..."
                  value={settings?.whatsapp_access_token ?? ''}
                  onChange={(e) => updateField('whatsapp_access_token', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wa_recipient">Default Recipient Phone Number</Label>
                <Input
                  id="wa_recipient"
                  placeholder="919876543210"
                  value={settings?.whatsapp_recipient_phone ?? ''}
                  onChange={(e) => updateField('whatsapp_recipient_phone', e.target.value)}
                />
                <p className="text-xs text-muted-foreground">Include country code without + (e.g. 91 for India)</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">
                Set up WhatsApp Business Cloud API at business.facebook.com. You need a Phone Number ID and a permanent access token from your Meta Business account.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Notification Logs */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                Notification History
              </CardTitle>
              <CardDescription className="mt-1">Recent notification delivery records</CardDescription>
            </div>
            {logs.length > 0 && (
              <Button variant="outline" size="sm" onClick={clearLogs}>
                <Trash2 className="h-4 w-4 mr-2" /> Clear
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {logs.length === 0 ? (
            <EmptyState
              icon={<History className="h-6 w-6" />}
              title="No notifications sent yet"
              description="Send a test notification to see delivery logs here."
            />
          ) : (
            <div className="space-y-2">
              {logs.map((log) => (
                <div key={log.id} className="flex items-start gap-3 rounded-lg border border-border p-3">
                  <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${
                    log.status === 'sent' ? 'bg-success/10' : 'bg-destructive/10'
                  }`}>
                    {log.status === 'sent'
                      ? <CheckCircle2 className="h-4 w-4 text-success" />
                      : <XCircle className="h-4 w-4 text-destructive" />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className="text-xs">
                        {log.channel === 'email' ? <Mail className="h-3 w-3 mr-1" /> : <MessageSquare className="h-3 w-3 mr-1" />}
                        {log.channel}
                      </Badge>
                      <Badge variant="outline" className="text-xs">{ALERT_LABELS[log.alert_type] || log.alert_type}</Badge>
                      <span className="text-xs text-muted-foreground">{formatDateTime(log.created_at)}</span>
                    </div>
                    <p className="text-sm mt-1 line-clamp-2">{log.message}</p>
                    {log.error && <p className="text-xs text-destructive mt-1">Error: {log.error}</p>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
