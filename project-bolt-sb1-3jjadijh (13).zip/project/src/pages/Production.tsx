import { useEffect, useState, useCallback } from 'react';
import { Plus, Factory, AlertTriangle, CheckCircle2, XCircle, Download, Search, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { FinishedProduct, Production, BOMItem, RawMaterial } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatNumber, formatDate } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { exportToCSV, exportToExcel } from '@/lib/export';
import { triggerNotification } from '@/lib/notify';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

interface ProductionResult {
  success: boolean;
  error?: string;
  insufficient_materials?: { name: string; required: number; available: number; unit: string }[];
  batch_number?: string;
  total_cost?: number;
  cost_per_unit?: number;
  new_finished_stock?: number;
}

export default function ProductionPage() {
  const { profile } = useAuth();
  const [productions, setProductions] = useState<Production[]>([]);
  const [products, setProducts] = useState<FinishedProduct[]>([]);
  const [bomMap, setBomMap] = useState<Record<string, BOMItem[]>>({});
  const [materials, setMaterials] = useState<RawMaterial[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [producing, setProducing] = useState(false);
  const [result, setResult] = useState<ProductionResult | null>(null);

  const [form, setForm] = useState({
    product_id: '',
    quantity: 0,
    production_date: new Date().toISOString().split('T')[0],
    operator_name: '',
    notes: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [prods, fps, boms, mats] = await Promise.all([
      supabase.from('productions').select('*, product:finished_products(*)').order('created_at', { ascending: false }).then((r) => r),
      supabase.from('finished_products').select('*').order('code').then((r) => r),
      supabase.from('finished_product_bom').select('*, material:raw_materials(*)').then((r) => r),
      supabase.from('raw_materials').select('*').order('name').then((r) => r),
    ]);
    setProductions((prods.data as Production[]) || []);
    setProducts((fps.data as FinishedProduct[]) || []);
    setMaterials((mats.data as RawMaterial[]) || []);
    const bomList = (boms.data as (BOMItem & { material: RawMaterial })[]) || [];
    const map: Record<string, BOMItem[]> = {};
    bomList.forEach((b) => {
      if (!map[b.product_id]) map[b.product_id] = [];
      map[b.product_id].push(b);
    });
    setBomMap(map);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openProduce = () => {
    setForm({
      product_id: products[0]?.id || '',
      quantity: 0,
      production_date: new Date().toISOString().split('T')[0],
      operator_name: profile?.full_name || '',
      notes: '',
    });
    setResult(null);
    setDialogOpen(true);
  };

  // Preview BOM deduction
  const bomPreview = form.product_id && form.quantity > 0
    ? (bomMap[form.product_id] || []).map((b) => {
        const required = b.quantity_per_unit * form.quantity;
        const material = materials.find((m) => m.id === b.material_id);
        const available = material?.current_stock || 0;
        return {
          name: material?.name || 'Unknown',
          required,
          available,
          unit: material?.unit || '',
          sufficient: available >= required,
          cost: required * (material?.unit_cost || 0),
        };
      })
    : [];

  const totalCost = bomPreview.reduce((s, b) => s + b.cost, 0);
  const hasInsufficient = bomPreview.some((b) => !b.sufficient);

  const handleProduce = async () => {
    if (!form.product_id || form.quantity <= 0) {
      toast.error('Select a product and enter a valid quantity');
      return;
    }
    setProducing(true);
    setResult(null);

    const { data, error } = await supabase.rpc('produce_batch', {
      p_product_id: form.product_id,
      p_quantity: Number(form.quantity),
      p_production_date: form.production_date,
      p_operator_name: form.operator_name,
      p_notes: form.notes || null,
    });

    setProducing(false);

    if (error) {
      toast.error(error.message);
      setResult({ success: false, error: error.message });
      return;
    }

    const res = data as ProductionResult;
    setResult(res);

    if (res.success) {
      toast.success(`Production batch ${res.batch_number} completed!`);
      // Log activity
      await supabase.from('activity_logs').insert({
        user_email: profile?.email || '',
        action: 'production_created',
        entity: 'production',
        details: `Batch ${res.batch_number} - ${form.quantity} units`,
      });
      fetchData();
    } else {
      toast.error(res.error || 'Production failed');
      if (res.error === 'Insufficient raw material stock') {
        // Log failed production
        await supabase.from('productions').insert({
          batch_number: `FAILED-${Date.now()}`,
          product_id: form.product_id,
          quantity: Number(form.quantity),
          production_date: form.production_date,
          operator_name: form.operator_name,
          total_cost: 0,
          status: 'failed',
          notes: `Failed: ${res.insufficient_materials?.map((m) => `${m.name} (need ${m.required}, have ${m.available})`).join(', ')}`,
        });
        fetchData();
        triggerNotification(
          'failed_production',
          'Production Batch Failed',
          `Production of ${form.quantity} units of ${products.find((p) => p.id === form.product_id)?.name || 'product'} failed due to insufficient raw materials: ${res.insufficient_materials?.map((m) => `${m.name} (need ${m.required}, have ${m.available})`).join(', ')}.`,
        );
      }
    }
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Batch Number', 'Product', 'Quantity', 'Date', 'Operator', 'Cost', 'Status'];
    const rows = filtered.map((p) => [
      p.batch_number, p.product?.name || '', p.quantity, p.production_date,
      p.operator_name, p.total_cost, p.status,
    ]);
    if (format === 'csv') exportToCSV('production-report', headers, rows);
    else exportToExcel('production-report', headers, rows);
    toast.success('Exported successfully');
  };

  const filtered = productions.filter((p) =>
    p.batch_number.toLowerCase().includes(search.toLowerCase()) ||
    (p.product?.name || '').toLowerCase().includes(search.toLowerCase()) ||
    p.operator_name.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Production Management" description="Create production batches with automatic BOM deduction">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openProduce} disabled={products.length === 0}>
          <Plus className="h-4 w-4 mr-2" /> New Production
        </Button>
      </PageHeader>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Total Batches</p>
            <p className="font-display text-2xl font-bold mt-1">{productions.filter((p) => p.status === 'completed').length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Total Production Cost</p>
            <p className="font-display text-2xl font-bold mt-1">{formatCurrency(productions.reduce((s, p) => s + Number(p.total_cost), 0))}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Failed Batches</p>
            <p className="font-display text-2xl font-bold mt-1 text-destructive">{productions.filter((p) => p.status === 'failed').length}</p>
          </CardContent>
        </Card>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by batch, product, or operator..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<Factory className="h-6 w-6" />}
              title="No production records"
              description="Create your first production batch to automatically deduct raw materials and increase finished product stock."
              action={<Button onClick={openProduce}><Plus className="h-4 w-4 mr-2" /> New Production</Button>}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Batch Number</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-right">Quantity</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Operator</TableHead>
                    <TableHead className="text-right">Total Cost</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-mono text-sm">{p.batch_number}</TableCell>
                      <TableCell className="font-medium">{p.product?.name || '-'}</TableCell>
                      <TableCell className="text-right">{formatNumber(p.quantity, 1)} {p.product?.unit || ''}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(p.production_date)}</TableCell>
                      <TableCell>{p.operator_name || '-'}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(Number(p.total_cost))}</TableCell>
                      <TableCell>
                        {p.status === 'completed' ? (
                          <Badge variant="default" className="bg-success text-success-foreground">
                            <CheckCircle2 className="h-3 w-3 mr-1" /> Completed
                          </Badge>
                        ) : (
                          <Badge variant="destructive">
                            <XCircle className="h-3 w-3 mr-1" /> Failed
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Production Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) setResult(null); }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>New Production Batch</DialogTitle>
            <DialogDescription>
              The system will automatically deduct raw materials based on the product's recipe (BOM) and increase finished product stock.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Product</Label>
              <Select value={form.product_id} onValueChange={(v) => setForm({ ...form, product_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
                <SelectContent>
                  {products.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.code} - {p.name} (Stock: {formatNumber(p.current_stock, 1)} {p.unit})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Quantity to Produce</Label>
              <Input type="number" step="0.001" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Production Date</Label>
              <Input type="date" value={form.production_date} onChange={(e) => setForm({ ...form, production_date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Operator Name</Label>
              <Input value={form.operator_name} onChange={(e) => setForm({ ...form, operator_name: e.target.value })} placeholder="Operator name" />
            </div>
            <div className="space-y-2">
              <Label>Notes (optional)</Label>
              <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes" />
            </div>
          </div>

          {/* BOM Preview */}
          {bomPreview.length > 0 && (
            <div className="rounded-lg border border-border p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold">BOM Deduction Preview</h4>
                <span className="text-sm text-muted-foreground">Total Cost: <span className="font-bold text-foreground">{formatCurrency(totalCost)}</span></span>
              </div>
              <div className="space-y-2">
                {bomPreview.map((b, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2">
                      {b.sufficient ? <CheckCircle2 className="h-4 w-4 text-success" /> : <AlertTriangle className="h-4 w-4 text-destructive" />}
                      {b.name}
                    </span>
                    <div className="text-right">
                      <span className={`font-medium ${b.sufficient ? '' : 'text-destructive'}`}>
                        {formatNumber(b.required, 1)} {b.unit}
                      </span>
                      {!b.sufficient && (
                        <span className="text-xs text-destructive ml-2">
                          (only {formatNumber(b.available, 1)} available)
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              {hasInsufficient && (
                <div className="rounded-md bg-destructive/10 border border-destructive/20 p-3 text-sm text-destructive">
                  <AlertTriangle className="h-4 w-4 inline mr-2" />
                  Production will be blocked — insufficient raw materials.
                </div>
              )}
            </div>
          )}

          {/* Result */}
          {result && (
            <div className={`rounded-lg border p-4 ${result.success ? 'bg-success/5 border-success/20' : 'bg-destructive/5 border-destructive/20'}`}>
              {result.success ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-success">
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="font-semibold">Production Successful!</span>
                  </div>
                  <p className="text-sm">Batch: <span className="font-mono font-medium">{result.batch_number}</span></p>
                  <p className="text-sm">Total Cost: <span className="font-medium">{formatCurrency(result.total_cost || 0)}</span></p>
                  <p className="text-sm">Cost per unit: <span className="font-medium">{formatCurrency(result.cost_per_unit || 0)}</span></p>
                  <p className="text-sm">New finished stock: <span className="font-medium">{formatNumber(result.new_finished_stock || 0, 1)} units</span></p>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-destructive">
                    <XCircle className="h-5 w-5" />
                    <span className="font-semibold">Production Failed</span>
                  </div>
                  <p className="text-sm">{result.error}</p>
                  {result.insufficient_materials && (
                    <div className="mt-2 space-y-1">
                      {result.insufficient_materials.map((m, i) => (
                        <p key={i} className="text-sm text-muted-foreground">
                          {m.name}: Need {formatNumber(m.required, 1)} {m.unit}, have {formatNumber(m.available, 1)} {m.unit}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              {result?.success ? 'Close' : 'Cancel'}
            </Button>
            {!result?.success && (
              <Button onClick={handleProduce} disabled={producing || hasInsufficient || form.quantity <= 0}>
                {producing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {hasInsufficient ? 'Blocked - Insufficient Stock' : 'Start Production'}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
