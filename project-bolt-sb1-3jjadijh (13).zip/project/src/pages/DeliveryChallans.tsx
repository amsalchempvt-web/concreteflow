import { useCallback, useEffect, useState } from 'react';
import { Pencil, Plus, Printer, Search, Truck } from 'lucide-react';
import { supabase, type DeliveryChallan, type Customer, type Company } from '@/lib/supabase';
import { useAuth } from '@/hooks/use-auth';
import { PageHeader, EmptyState, formatDate, formatNumber } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { printDocument } from '@/lib/export';

const escapeHtml = (value: unknown): string => String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[character] || character);

const blankForm = {
  customer_id: '', client_name: '', site: '', po_number: '', so_number: '', batch_number: '', serial_number: '1', grade: '', pump_type: 'Without Pump', quantity: 0, tm_number: '', driver_name: '', opening_cmt: 0, current_cmt: 0, total_cmt: 0, time_out: '', time_in: '', gst_number: '', pan_number: '', state_code: '', site_time: '', kms: '', gross_weight: '', tare_weight: '', net_weight: '', notes: '',
};

type ChallanForm = typeof blankForm;

export default function DeliveryChallans() {
  const { company } = useAuth();
  const [challans, setChallans] = useState<DeliveryChallan[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<DeliveryChallan | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<ChallanForm>(blankForm);

  const fetchChallans = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('delivery_challans').select('*, customer:customers(*)').order('created_at', { ascending: false });
    if (error) toast.error('Could not load delivery challans');
    setChallans((data as DeliveryChallan[]) || []);
    setLoading(false);
  }, []);

  const fetchCustomers = useCallback(async () => {
    const { data } = await supabase.from('customers').select('*').order('name');
    setCustomers((data as Customer[]) || []);
  }, []);

  useEffect(() => { fetchChallans(); fetchCustomers(); }, [fetchChallans, fetchCustomers]);

  const openCreate = () => {
    setCreating(true);
    setEditing(null);
    setForm({ ...blankForm, challan_date: new Date().toISOString().slice(0, 10) } as ChallanForm & { challan_date: string });
  };

  const openEdit = (challan: DeliveryChallan) => {
    setEditing(challan);
    setCreating(false);
    setForm({ ...blankForm, ...challan, quantity: Number(challan.quantity), opening_cmt: Number(challan.opening_cmt), current_cmt: Number(challan.current_cmt), total_cmt: Number(challan.total_cmt) });
  };

  const onCustomerChange = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId);
    setForm((prev) => ({ ...prev, customer_id: customerId, client_name: customer?.name || '', gst_number: customer?.gst_number || '' }));
  };

  const createChallan = async () => {
    if (!form.client_name.trim()) { toast.error('Client name is required'); return; }
    const { data: challanNumber } = await supabase.rpc('next_challan_number');
    const payload = { ...form, quantity: Number(form.quantity), opening_cmt: Number(form.opening_cmt), current_cmt: Number(form.current_cmt), total_cmt: Number(form.total_cmt), challan_number: challanNumber as string, challan_date: (form as unknown as { challan_date?: string }).challan_date || new Date().toISOString().slice(0, 10) };
    const { error } = await supabase.from('delivery_challans').insert(payload);
    if (error) { toast.error('Could not create the challan'); return; }
    toast.success('Delivery challan created');
    setCreating(false);
    setForm(blankForm);
    fetchChallans();
  };

  const save = async () => {
    if (!editing) return;
    const payload = { ...form, quantity: Number(form.quantity), opening_cmt: Number(form.opening_cmt), current_cmt: Number(form.current_cmt), total_cmt: Number(form.total_cmt) };
    const { error } = await supabase.from('delivery_challans').update(payload).eq('id', editing.id);
    if (error) { toast.error('Could not save the challan'); return; }
    toast.success('Delivery challan updated');
    setEditing(null);
    fetchChallans();
  };

  const printChallan = (challan: DeliveryChallan) => {
    const value = (key: keyof DeliveryChallan): string => escapeHtml(challan[key]);
    const customerName = value('client_name') || '—';
    const date = escapeHtml(formatDate(challan.challan_date));
    const c = (company || {}) as Partial<Company>;
    const companyName = escapeHtml(c.name || 'ConcreteFlow ERP');
    const companyAddress = escapeHtml(c.address || '');
    const companyContact = escapeHtml(c.contact || '');
    const companyEmail = escapeHtml(c.email || '');
    const companyGst = escapeHtml(c.gst_number || '');
    const companyPan = escapeHtml(c.pan_number || '');
    const companyState = escapeHtml(c.state_code || '');
    const tagline = escapeHtml(c.tagline || 'QUALITY · SERVICE · TRUST');
    const initials = escapeHtml((c.name || 'CF').slice(0, 2).toUpperCase());
    const logoHtml = c.logo_url
      ? `<img src="${escapeHtml(c.logo_url)}" alt="logo" style="max-width:170px;max-height:50px;object-fit:contain" />`
      : `<div class="logo"><b>${initials.charAt(0)}</b><strong>${initials}<small>RMC</small></strong><em>${tagline}</em></div>`;
    const copy = (label: string) => `<section class="challan-copy"><header class="challan-header"><div class="company-details"><strong>${companyName}</strong><span>${companyAddress}</span><span>Mobile: ${companyContact}</span><span>Email: ${companyEmail}</span></div>${logoHtml}</header><div class="challan-title"><h1>DELIVERY CHALLAN</h1><b>${label}</b></div><div class="top-fields"><span>Challan No. <b>${value('challan_number')}</b></span><span>Date : <b>${date}</b></span><span>BatchNo.: <b>${value('batch_number')}</b></span></div><div class="field-grid"><div class="field-column"><div><label>Client Name :</label><strong>${customerName}</strong></div><div><label>Site :</label><strong>${value('site')}</strong></div><div><label>GST No.:</label><strong>${value('gst_number')}</strong></div><div><label>PAN No.:</label><strong>${value('pan_number')}</strong></div></div><div class="field-column"><div><label>PO. No. :</label><strong>${value('po_number')}</strong></div><div><label>SO. No. :</label><strong>${value('so_number')}</strong></div><div><label>Serial No. :</label><strong>${value('serial_number')}</strong></div><div><label>Total Opening CMT :</label><strong>${formatNumber(Number(challan.opening_cmt), 2)}</strong></div><div><label>Add. Current :</label><strong>${formatNumber(Number(challan.current_cmt), 2)}</strong></div><div><label>Total CMT :</label><strong>${formatNumber(Number(challan.total_cmt), 2)}</strong></div></div></div><div class="mix-row"><span><label>Grade :</label><b>${value('grade')}</b></span><span><b>${value('pump_type') || 'Without Pump'}</b></span><span><label>Qty :</label><b>${formatNumber(Number(challan.quantity), 2)} CMT</b></span></div><div class="vehicle-row"><span><label>TM No. :</label><b>${value('tm_number')}</b></span><span><label>Driver :</label><b>${value('driver_name')}</b></span><span><label>Time Out :</label><b>${value('time_out')}</b></span><span><label>Time in :</label><b>${value('time_in')}</b></span></div><div class="tax-row"><b>GST No. ${companyGst}</b><b>PANNO: ${companyPan}</b><b>StateCode: ${companyState}</b></div><p class="terms">The client is responsible for all kind of centering shuttering scaffolding and reinforcement work, our company is not responsible for any damage caused due to above reasons.<br/>We are not responsible for slump, strength or quality of concrete when water is added at site on request of customer.</p><div class="weights"><span>Site time in : <b>${value('site_time')}</b> Out <b>${value('time_out')}</b></span><span>For, ${companyName}</span></div><div class="weight-row"><span>KMS : <b>${value('kms')}</b></span><span>Gross Weight : <b>${value('gross_weight')}</b></span><span>Tare Weight : <b>${value('tare_weight')}</b></span><span>Net Weight : <b>${value('net_weight')}</b></span></div><div class="signature-row"><span>Received By</span><span>Authorised Signatory</span></div></section>`;
    const style = `<style>.footer{display:none!important}.challan-copy{font-family:Arial,sans-serif;color:#111;border:1px solid #222;padding:8px 10px 7px;width:100%;font-size:8px;line-height:1.15;break-inside:avoid}.challan-copy+.challan-copy{margin-top:6px}.challan-header{display:flex;justify-content:space-between;min-height:55px}.company-details{display:flex;flex-direction:column;gap:1px}.company-details strong{font-size:16px;margin-bottom:2px}.company-details span{font-size:8px;font-weight:600}.logo{width:180px;height:50px;background:#fff200;color:#17439a;display:grid;grid-template-columns:50px 1fr;grid-template-rows:1fr 11px;align-items:center;padding:3px 7px;overflow:hidden}.logo b{font-size:54px;line-height:44px;font-style:italic;letter-spacing:-12px}.logo strong{font-size:29px;line-height:27px;letter-spacing:-1px}.logo strong small{font-size:13px;margin-left:2px}.logo em{grid-column:2;font-size:5px;color:#0f3b78;letter-spacing:.6px;font-style:normal}.challan-title{display:flex;align-items:center;justify-content:flex-end;border-bottom:1px solid #222;height:23px;position:relative}.challan-title h1{position:absolute;left:50%;transform:translateX(-50%);font-size:16px;border:1px solid #222;padding:1px 18px;background:#fff;white-space:nowrap;margin:0}.challan-title b{font-size:8px}.top-fields{display:grid;grid-template-columns:1.3fr 1fr 1fr;border-bottom:1px solid #222;padding:5px 3px 3px;gap:8px}.top-fields span,.field-column div,.mix-row span,.vehicle-row span{display:flex;align-items:baseline;gap:4px}.top-fields b,.field-column strong,.mix-row b,.vehicle-row b{border-bottom:1px solid #444;min-width:35px;flex:1;min-height:11px}.field-grid{display:grid;grid-template-columns:1.45fr 1fr;border-bottom:1px solid #222}.field-column{padding:2px 5px}.field-column+ .field-column{border-left:1px solid #222}.field-column div{min-height:14px}.field-column label{white-space:nowrap;min-width:83px}.field-column+ .field-column label{min-width:94px}.field-column strong{text-transform:uppercase;font-size:9px}.mix-row,.vehicle-row,.weights,.weight-row,.signature-row{display:flex;gap:18px;padding:4px 5px;border-bottom:1px solid #222}.mix-row span:nth-child(1){width:30%}.mix-row span:nth-child(2){width:26%;justify-content:center}.mix-row span:nth-child(3){flex:1}.mix-row label,.vehicle-row label{white-space:nowrap}.vehicle-row span{flex:1}.tax-row{display:flex;justify-content:space-between;padding:5px;border-bottom:1px solid #222;font-size:8px}.terms{font-size:7px;text-align:justify;margin:6px 5px 5px;min-height:24px}.weights{justify-content:space-between;padding-top:1px;padding-bottom:3px}.weight-row{border:0;padding-top:3px;gap:55px}.weight-row span{flex:1;white-space:nowrap}.signature-row{border:0;justify-content:space-between;padding:7px 5px 0}.signature-row span:last-child{margin-right:45px}@media print{body{padding:4px!important}.challan-copy{font-size:8px}.challan-copy+.challan-copy{margin-top:5px}}</style>`;
    printDocument(`Delivery Challan ${challan.challan_number}`, `${style}${copy('Original for Buyer')}${copy('Duplicate for Assessee')}`);
  };

  const filtered = challans.filter((challan) => [challan.challan_number, challan.client_name, challan.site, challan.batch_number].some((value) => value?.toLowerCase().includes(search.toLowerCase())));

  const formFields: { key: keyof ChallanForm; label: string; type?: string }[] = [
    { key: 'site', label: 'Site' },
    { key: 'po_number', label: 'PO Number' },
    { key: 'so_number', label: 'SO Number' },
    { key: 'batch_number', label: 'Batch Number' },
    { key: 'serial_number', label: 'Serial Number' },
    { key: 'grade', label: 'Grade' },
    { key: 'pump_type', label: 'Pump Type' },
    { key: 'tm_number', label: 'TM Number' },
    { key: 'driver_name', label: 'Driver Name' },
    { key: 'pan_number', label: 'PAN Number' },
    { key: 'state_code', label: 'State Code' },
    { key: 'time_out', label: 'Time Out' },
    { key: 'time_in', label: 'Time In' },
    { key: 'site_time', label: 'Site Time In' },
    { key: 'kms', label: 'KMS' },
    { key: 'gross_weight', label: 'Gross Weight' },
    { key: 'tare_weight', label: 'Tare Weight' },
    { key: 'net_weight', label: 'Net Weight' },
  ];

  const numberFields: { key: keyof ChallanForm; label: string }[] = [
    { key: 'quantity', label: 'Quantity' },
    { key: 'opening_cmt', label: 'Opening CMT' },
    { key: 'current_cmt', label: 'Current CMT' },
    { key: 'total_cmt', label: 'Total CMT' },
  ];

  const renderForm = (isNew: boolean) => (
    <div className="grid grid-cols-2 gap-4">
      {isNew && (
        <div className="col-span-2 space-y-2">
          <Label>Customer (optional)</Label>
          <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.customer_id} onChange={(e) => onCustomerChange(e.target.value)}>
            <option value="">Select customer</option>
            {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
      )}
      <div className="space-y-2"><Label>Client Name</Label><Input value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} /></div>
      <div className="space-y-2"><Label>GST Number</Label><Input value={form.gst_number} onChange={(e) => setForm({ ...form, gst_number: e.target.value })} /></div>
      {formFields.map((field) => (
        <div key={field.key} className="space-y-2">
          <Label>{field.label}</Label>
          <Input value={String(form[field.key])} onChange={(e) => setForm({ ...form, [field.key]: e.target.value })} />
        </div>
      ))}
      {numberFields.map((field) => (
        <div key={field.key} className="space-y-2">
          <Label>{field.label}</Label>
          <Input type="number" value={Number(form[field.key])} onChange={(e) => setForm({ ...form, [field.key]: Number(e.target.value) })} />
        </div>
      ))}
      <div className="col-span-2 space-y-2"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
    </div>
  );

  if (loading) return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;

  return (
    <div className="space-y-6">
      <PageHeader title="Delivery Challans" description="Create, update, and print the two-copy delivery challan for every invoice">
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search challans..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Button onClick={openCreate}><Plus className="h-4 w-4 mr-2" /> New Challan</Button>
      </PageHeader>

      {filtered.length === 0 ? (
        <Card><CardContent><EmptyState icon={<Truck className="h-6 w-6" />} title="No delivery challans found" description="Create a new challan manually, or one will be created automatically when you save a new invoice." /></CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Challan No.</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Site</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Qty</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((challan) => (
                  <TableRow key={challan.id}>
                    <TableCell className="font-mono">{challan.challan_number}</TableCell>
                    <TableCell>{challan.client_name || challan.customer?.name}</TableCell>
                    <TableCell>{challan.site || '—'}</TableCell>
                    <TableCell>{formatDate(challan.challan_date)}</TableCell>
                    <TableCell>{formatNumber(Number(challan.quantity), 2)}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" onClick={() => openEdit(challan)}><Pencil className="h-4 w-4 mr-2" /> Edit</Button>
                      <Button size="sm" className="ml-2" onClick={() => printChallan(challan)}><Printer className="h-4 w-4 mr-2" /> Print</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Delivery Challan</DialogTitle>
            <DialogDescription>Complete the site, vehicle, concrete, and weight details before printing.</DialogDescription>
          </DialogHeader>
          {renderForm(false)}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={save}>Save Challan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={creating} onOpenChange={setCreating}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>New Delivery Challan</DialogTitle>
            <DialogDescription>Create a standalone challan, or one will be created automatically when you save a new invoice.</DialogDescription>
          </DialogHeader>
          {renderForm(true)}
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreating(false)}>Cancel</Button>
            <Button onClick={createChallan}>Create Challan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
