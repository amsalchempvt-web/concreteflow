import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Factory, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function AuthPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await signIn(email, password);
    if (error) {
      setError(error);
      setLoading(false);
    } else {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 20% 30%, white 1px, transparent 1px), radial-gradient(circle at 60% 70%, white 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />
        <div className="relative z-10 flex flex-col justify-between p-12 text-primary-foreground">
          <div>
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-primary-foreground/15 backdrop-blur flex items-center justify-center">
                <Factory className="h-7 w-7" />
              </div>
              <div>
                <h1 className="font-display text-2xl font-bold">ConcreteFlow ERP</h1>
                <p className="text-sm text-primary-foreground/70">Plant Management System</p>
              </div>
            </div>
          </div>
          <div className="space-y-6 max-w-md">
            <h2 className="font-display text-4xl font-bold leading-tight">
              Manage your concrete plant with precision and control.
            </h2>
            <p className="text-primary-foreground/80 text-lg">
              Real-time inventory, automatic BOM deduction, production tracking, invoicing, and complete financial reporting — all in one place.
            </p>
            <div className="grid grid-cols-2 gap-4 pt-4">
              {[
                { label: 'Raw Materials', value: 'Live tracking' },
                { label: 'Production', value: 'Auto BOM deduction' },
                { label: 'Invoicing', value: 'GST compliant' },
                { label: 'Reports', value: 'P&L & analytics' },
              ].map((item) => (
                <div key={item.label} className="rounded-lg bg-primary-foreground/10 backdrop-blur p-4">
                  <div className="text-2xl font-bold">{item.value}</div>
                  <div className="text-sm text-primary-foreground/70">{item.label}</div>
                </div>
              ))}
            </div>
          </div>
          <p className="text-sm text-primary-foreground/60">
            © {new Date().getFullYear()} ConcreteFlow ERP. Built for concrete mixing plant manufacturers.
          </p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6 bg-background">
        <div className="w-full max-w-md space-y-6">
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <div className="h-10 w-10 rounded-xl bg-primary flex items-center justify-center">
              <Factory className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-xl font-bold">ConcreteFlow ERP</h1>
              <p className="text-xs text-muted-foreground">Plant Management System</p>
            </div>
          </div>

          <div>
            <h2 className="font-display text-2xl font-bold">Welcome back</h2>
            <p className="text-muted-foreground mt-1">Sign in to access your plant dashboard.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signin-email">Email</Label>
              <Input
                id="signin-email"
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signin-password">Password</Label>
              <div className="relative">
                <Input
                  id="signin-password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Sign In
            </Button>
          </form>

          <p className="text-xs text-muted-foreground text-center">
            New companies and users are created by the super admin. Contact your platform administrator for access.
          </p>
        </div>
      </div>
    </div>
  );
}
