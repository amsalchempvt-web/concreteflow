import { useEffect, useState, useCallback } from 'react';
import { Plus, Wallet, Download, Search, Pencil, Trash2, Upload } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell,
} from 'recharts';
import { supabase } from '@/lib/supabase';
import type { Expense } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatDate } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { exportToCSV, exportToExcel } from '@/lib/export';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

const CATEGORIES = ['Fuel', 'Electricity', 'Labour', 'Vehicle', 'Maintenance', 'Office Expense', 'Machinery Repair', 'Other'];
const CATEGORY_COLORS: Record<string, string> = {
  Fuel: 'hsl(38, 92%, 50%)',
  Electricity: 'hsl(200, 85%, 42%)',
  Labour: 'hsl(142, 71%, 38%)',
  Vehicle: 'hsl(270, 65%, 55%)',
  Maintenance: 'hsl(0, 72%, 51%)',
  'Office Expense': 'hsl(200, 85%, 60%)',
  'Machinery Repair': 'hsl(142, 71%, 55%)',
  Other: 'hsl(215, 16%, 47%)',
};

export default function Expenses() {
  const { profile } = useAuth();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [form, setForm] = useState({
    expense_date: new Date().toISOString().split('T')[0],
    category: 'Fuel',
    vendor: '',
    amount: 0,
    notes: '',
    receipt_url: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('expenses').select('*').order('expense_date', { ascending: false });
    setExpenses((data as Expense[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({
      expense_date: new Date().toISOString().split('T')[0],
      category: 'Fuel', vendor: '', amount: 0, notes: '', receipt_url: '',
    });
    setDialogOpen(true);
  };

  const openEdit = (e: Expense) => {
    setEditing(e);
    setForm({
      expense_date: e.expense_date, category: e.category, vendor: e.vendor,
      amount: Number(e.amount), notes: e.notes, receipt_url: e.receipt_url,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (form.amount <= 0) { toast.error('Amount must be greater than zero'); return; }
    const payload = {
      expense_date: form.expense_date,
      category: form.category,
      vendor: form.vendor,
      amount: Number(form.amount),
      notes: form.notes,
      receipt_url: form.receipt_url,
    };
    if (editing) {
      const { error } = await supabase.from('expenses').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success('Expense updated');
    } else {
      const { error } = await supabase.from('expenses').insert(payload);
      if (error) { toast.error(error.message); return; }
      await supabase.from('activity_logs').insert({
        user_email: profile?.email || '',
        action: 'expense_added',
        entity: 'expense',
        details: `${form.category} - ${formatCurrency(Number(form.amount))}`,
      });
      toast.success('Expense added');
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('expenses').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Expense deleted');
    setDeleteId(null);
    fetchData();
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Date', 'Category', 'Vendor', 'Amount', 'Notes'];
    const rows = filtered.map((e) => [e.expense_date, e.category, e.vendor, e.amount, e.notes]);
    if (format === 'csv') exportToCSV('expenses', headers, rows);
    else exportToExcel('expenses', headers, rows);
    toast.success('Exported successfully');
  };

  const filtered = expenses.filter((e) => {
    const matchSearch = e.vendor.toLowerCase().includes(search.toLowerCase()) ||
      e.notes.toLowerCase().includes(search.toLowerCase()) ||
      e.category.toLowerCase().includes(search.toLowerCase());
    const matchCategory = filterCategory === 'all' || e.category === filterCategory;
    return matchSearch && matchCategory;
  });

  // Category-wise chart data
  const categoryData = CATEGORIES.map((cat) => ({
    category: cat,
    amount: expenses.filter((e) => e.category === cat).reduce((s, e) => s + Number(e.amount), 0),
  })).filter((d) => d.amount > 0);

  const totalExpenses = expenses.reduce((s, e) => s + Number(e.amount), 0);
  const currentMonth = new Date().getMonth();
  const monthlyExpenses = expenses
    .filter((e) => new Date(e.expense_date).getMonth() === currentMonth)
    .reduce((s, e) => s + Number(e.amount), 0);

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Expense Management" description="Track all business expenses by category">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4 mr-2" /> Add Expense
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Total Expenses</p>
            <p className="font-display text-2xl font-bold mt-1">{formatCurrency(totalExpenses)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">This Month</p>
            <p className="font-display text-2xl font-bold mt-1">{formatCurrency(monthlyExpenses)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Total Entries</p>
            <p className="font-display text-2xl font-bold mt-1">{expenses.length}</p>
          </CardContent>
        </Card>
      </div>

      {categoryData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Expenses by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={categoryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="category" stroke="hsl(var(--muted-foreground))" fontSize={11} angle={-20} textAnchor="end" height={60} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '13px' }}
                  formatter={(value: number) => formatCurrency(value)}
                />
                <Bar dataKey="amount" name="Amount" radius={[4, 4, 0, 0]}>
                  {categoryData.map((entry, index) => (
                    <Cell key={index} fill={CATEGORY_COLORS[entry.category] || 'hsl(200, 85%, 42%)'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search expenses..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<Wallet className="h-6 w-6" />}
              title="No expenses found"
              description="Add your first expense to start tracking business costs."
              action={<Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> Add Expense</Button>}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Vendor</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell className="text-muted-foreground">{formatDate(e.expense_date)}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" style={{ backgroundColor: `${CATEGORY_COLORS[e.category]}20`, color: CATEGORY_COLORS[e.category] }}>
                          {e.category}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{e.vendor || '-'}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(Number(e.amount))}</TableCell>
                      <TableCell className="text-muted-foreground max-w-xs truncate">{e.notes || '-'}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(e)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(e.id)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Expense' : 'Add Expense'}</DialogTitle>
            <DialogDescription>{editing ? 'Update expense details.' : 'Record a new business expense.'}</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Date</Label>
              <Input type="date" value={form.expense_date} onChange={(e) => setForm({ ...form, expense_date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Vendor</Label>
              <Input value={form.vendor} onChange={(e) => setForm({ ...form, vendor: e.target.value })} placeholder="Vendor name" />
            </div>
            <div className="space-y-2">
              <Label>Amount (₹)</Label>
              <Input type="number" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Receipt URL (optional)</Label>
              <Input value={form.receipt_url} onChange={(e) => setForm({ ...form, receipt_url: e.target.value })} placeholder="Link to receipt" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Notes</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes" rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Add'} Expense</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Expense?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the expense record. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
