import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, Trash2, Layers, FlaskConical, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { FinishedProduct, BOMItem, RawMaterial } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatNumber } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { exportToCSV, exportToExcel } from '@/lib/export';
import { toast } from 'sonner';

const UNITS = ['Cubic Meter', 'Kg', 'Ton', 'Piece'];

export default function FinishedProducts() {
  const [products, setProducts] = useState<FinishedProduct[]>([]);
  const [materials, setMaterials] = useState<RawMaterial[]>([]);
  const [bomMap, setBomMap] = useState<Record<string, BOMItem[]>>({});
  const [loading, setLoading] = useState(true);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<FinishedProduct | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [bomProduct, setBomProduct] = useState<FinishedProduct | null>(null);

  const [form, setForm] = useState({
    code: '', name: '', unit: 'Cubic Meter', current_stock: 0, minimum_stock: 0,
    selling_price: 0, production_cost: 0,
  });
  const [bomItems, setBomItems] = useState<{ material_id: string; quantity_per_unit: number }[]>([]);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [prods, mats, boms] = await Promise.all([
      supabase.from('finished_products').select('*').order('code').then((r) => r),
      supabase.from('raw_materials').select('*').order('name').then((r) => r),
      supabase.from('finished_product_bom').select('*, material:raw_materials(*)').then((r) => r),
    ]);
    const productList = (prods.data as FinishedProduct[]) || [];
    const matList = (mats.data as RawMaterial[]) || [];
    const bomList = (boms.data as (BOMItem & { material: RawMaterial })[]) || [];

    const map: Record<string, BOMItem[]> = {};
    bomList.forEach((b) => {
      if (!map[b.product_id]) map[b.product_id] = [];
      map[b.product_id].push(b);
    });
    setProducts(productList);
    setMaterials(matList);
    setBomMap(map);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({ code: '', name: '', unit: 'Cubic Meter', current_stock: 0, minimum_stock: 0, selling_price: 0, production_cost: 0 });
    setDialogOpen(true);
  };

  const openEdit = (p: FinishedProduct) => {
    setEditing(p);
    setForm({
      code: p.code, name: p.name, unit: p.unit, current_stock: p.current_stock,
      minimum_stock: p.minimum_stock, selling_price: p.selling_price, production_cost: p.production_cost,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.code || !form.name) { toast.error('Code and name are required'); return; }
    const payload = {
      code: form.code,
      name: form.name,
      unit: form.unit,
      current_stock: Number(form.current_stock),
      minimum_stock: Number(form.minimum_stock),
      selling_price: Number(form.selling_price),
      production_cost: Number(form.production_cost),
    };
    if (editing) {
      const { error } = await supabase.from('finished_products').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success('Product updated');
    } else {
      const { error } = await supabase.from('finished_products').insert(payload);
      if (error) { toast.error(error.message); return; }
      toast.success('Product added');
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('finished_products').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Product deleted');
    setDeleteId(null);
    fetchData();
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Code', 'Name', 'Unit', 'Stock', 'Min Stock', 'Selling Price', 'Production Cost', 'Profit/m³'];
    const rows = products.map((p) => [
      p.code, p.name, p.unit, p.current_stock, p.minimum_stock, p.selling_price,
      p.production_cost, (p.selling_price - p.production_cost).toFixed(2),
    ]);
    if (format === 'csv') exportToCSV('finished-products', headers, rows);
    else exportToExcel('finished-products', headers, rows);
    toast.success('Exported successfully');
  };

  // BOM management
  const openBOM = (p: FinishedProduct) => {
    setBomProduct(p);
    const existing = bomMap[p.id] || [];
    setBomItems(existing.map((b) => ({ material_id: b.material_id, quantity_per_unit: b.quantity_per_unit })));
  };

  const addBomItem = () => {
    if (materials.length === 0) return;
    setBomItems([...bomItems, { material_id: materials[0].id, quantity_per_unit: 0 }]);
  };

  const updateBomItem = (index: number, field: 'material_id' | 'quantity_per_unit', value: string | number) => {
    const updated = [...bomItems];
    updated[index] = { ...updated[index], [field]: value };
    setBomItems(updated);
  };

  const removeBomItem = (index: number) => {
    setBomItems(bomItems.filter((_, i) => i !== index));
  };

  const saveBOM = async () => {
    if (!bomProduct) return;
    // Delete existing BOM and re-insert
    await supabase.from('finished_product_bom').delete().eq('product_id', bomProduct.id);
    if (bomItems.length > 0) {
      const { error } = await supabase.from('finished_product_bom').insert(
        bomItems
          .filter((item) => item.material_id && item.quantity_per_unit > 0)
          .map((item) => ({
            product_id: bomProduct.id,
            material_id: item.material_id,
            quantity_per_unit: Number(item.quantity_per_unit),
          }))
      );
      if (error) { toast.error(error.message); return; }
    }
    toast.success('Recipe (BOM) saved');
    setBomProduct(null);
    fetchData();
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Finished Products" description="Manage concrete grades and their Bill of Materials (recipes)">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4 mr-2" /> Add Product
        </Button>
      </PageHeader>

      {products.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<Layers className="h-6 w-6" />}
              title="No finished products found"
              description="Add concrete grades like M10, M15, M20, M25, etc. with their recipes."
              action={<Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> Add Product</Button>}
            />
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((p) => {
            const bom = bomMap[p.id] || [];
            const profit = p.selling_price - p.production_cost;
            const margin = p.selling_price > 0 ? (profit / p.selling_price) * 100 : 0;
            return (
              <Card key={p.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-display text-lg font-bold">{p.code}</h3>
                        <Badge variant={bom.length > 0 ? 'default' : 'outline'}>
                          {bom.length > 0 ? `${bom.length} BOM items` : 'No recipe'}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{p.name}</p>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" title="Edit Recipe" onClick={() => openBOM(p)}>
                        <FlaskConical className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(p)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(p.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                    <div className="rounded-lg bg-muted/50 p-3">
                      <p className="text-xs text-muted-foreground">Current Stock</p>
                      <p className="font-semibold">{formatNumber(p.current_stock, 1)} {p.unit}</p>
                    </div>
                    <div className="rounded-lg bg-muted/50 p-3">
                      <p className="text-xs text-muted-foreground">Selling Price</p>
                      <p className="font-semibold">{formatCurrency(p.selling_price)}</p>
                    </div>
                    <div className="rounded-lg bg-muted/50 p-3">
                      <p className="text-xs text-muted-foreground">Production Cost</p>
                      <p className="font-semibold">{formatCurrency(p.production_cost)}</p>
                    </div>
                    <div className="rounded-lg bg-success/5 p-3">
                      <p className="text-xs text-muted-foreground">Profit / Unit</p>
                      <p className="font-semibold text-success">{formatCurrency(profit)}</p>
                      <p className="text-xs text-success/70">{margin.toFixed(1)}% margin</p>
                    </div>
                  </div>

                  {bom.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Recipe (per {p.unit})</p>
                      <div className="space-y-1">
                        {bom.map((b) => (
                          <div key={b.id} className="flex justify-between text-sm">
                            <span className="text-muted-foreground">{b.material?.name || 'Unknown'}</span>
                            <span className="font-medium">{formatNumber(b.quantity_per_unit, 1)} {b.material?.unit || ''}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Product' : 'Add Finished Product'}</DialogTitle>
            <DialogDescription>
              {editing ? 'Update product details.' : 'Define a new concrete grade or product.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Product Code</Label>
              <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="e.g. M25" />
            </div>
            <div className="space-y-2">
              <Label>Product Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. M25 Concrete" />
            </div>
            <div className="space-y-2">
              <Label>Unit</Label>
              <Select value={form.unit} onValueChange={(v) => setForm({ ...form, unit: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Current Stock</Label>
              <Input type="number" step="0.001" value={form.current_stock} onChange={(e) => setForm({ ...form, current_stock: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Minimum Stock Level</Label>
              <Input type="number" step="0.001" value={form.minimum_stock} onChange={(e) => setForm({ ...form, minimum_stock: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Selling Price (₹)</Label>
              <Input type="number" step="0.01" value={form.selling_price} onChange={(e) => setForm({ ...form, selling_price: Number(e.target.value) })} />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Production Cost (₹) - auto-calculated from BOM after production</Label>
              <Input type="number" step="0.01" value={form.production_cost} onChange={(e) => setForm({ ...form, production_cost: Number(e.target.value) })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Add'} Product</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* BOM Editor Dialog */}
      <Dialog open={!!bomProduct} onOpenChange={(o) => !o && setBomProduct(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Recipe (BOM) - {bomProduct?.code} {bomProduct?.name}</DialogTitle>
            <DialogDescription>
              Define the raw materials required to produce one {bomProduct?.unit} of this product.
              These quantities are automatically deducted during production.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[400px] overflow-y-auto scrollbar-thin">
            {bomItems.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No ingredients added yet. Click below to add.</p>
            ) : (
              bomItems.map((item, i) => (
                <div key={i} className="flex gap-2 items-end">
                  <div className="flex-1 space-y-1">
                    <Label className="text-xs">Raw Material</Label>
                    <Select value={item.material_id} onValueChange={(v) => updateBomItem(i, 'material_id', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {materials.map((m) => <SelectItem key={m.id} value={m.id}>{m.name} ({m.unit})</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="w-32 space-y-1">
                    <Label className="text-xs">Qty per unit</Label>
                    <Input type="number" step="0.001" value={item.quantity_per_unit} onChange={(e) => updateBomItem(i, 'quantity_per_unit', Number(e.target.value))} />
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeBomItem(i)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={addBomItem}>
              <Plus className="h-4 w-4 mr-2" /> Add Ingredient
            </Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBomProduct(null)}>Cancel</Button>
            <Button onClick={saveBOM}>Save Recipe</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Product?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the product and its recipe. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
