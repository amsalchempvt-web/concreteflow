import { useEffect, useState } from 'react';
import { History, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { ActivityLog } from '@/lib/supabase';
import { PageHeader, EmptyState, formatDateTime } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';

export default function ActivityLogs() {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('activity_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);
    setLogs((data as ActivityLog[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const actionColors: Record<string, string> = {
    production_created: 'default',
    invoice_created: 'default',
    quotation_created: 'secondary',
    expense_added: 'destructive',
    customer_added: 'secondary',
    supplier_added: 'secondary',
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Activity Logs & Audit Trail" description="Complete record of all user actions in the system">
        <Button variant="outline" size="sm" onClick={fetchData}>
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
      </PageHeader>

      {loading ? (
        <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>
      ) : logs.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<History className="h-6 w-6" />}
              title="No activity logged yet"
              description="Actions like creating invoices, productions, and expenses will appear here."
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Entity</TableHead>
                    <TableHead>Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="text-muted-foreground whitespace-nowrap">{formatDateTime(log.created_at)}</TableCell>
                      <TableCell className="font-medium">{log.user_email || 'System'}</TableCell>
                      <TableCell>
                        <Badge variant={(actionColors[log.action] as any) || 'outline'}>
                          {log.action.replace(/_/g, ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{log.entity || '-'}</TableCell>
                      <TableCell className="text-muted-foreground max-w-md truncate">{log.details || '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
