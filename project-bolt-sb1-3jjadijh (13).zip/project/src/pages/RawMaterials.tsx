import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, Trash2, Package, ArrowDownCircle, ArrowUpCircle, History, Download, Search, ShoppingCart } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { RawMaterial, RawMaterialMovement, Supplier } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatNumber, formatDateTime } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { exportToCSV, exportToExcel } from '@/lib/export';
import { triggerNotification } from '@/lib/notify';
import { toast } from 'sonner';

const UNITS = ['Kg', 'Ton', 'Cubic Meter', 'Liter', 'Piece'];

export default function RawMaterials() {
  const [materials, setMaterials] = useState<RawMaterial[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [movements, setMovements] = useState<RawMaterialMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<RawMaterial | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [historyMaterial, setHistoryMaterial] = useState<RawMaterial | null>(null);
  const [stockDialog, setStockDialog] = useState<{ material: RawMaterial; type: 'in' | 'out' } | null>(null);
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '', code: '', unit: 'Kg', current_stock: 0, minimum_stock: 0, unit_cost: 0, supplier_id: '',
  });
  const [stockForm, setStockForm] = useState({ quantity: 0, notes: '', reference: '' });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [mats, sups, movs] = await Promise.all([
      supabase.from('raw_materials').select('*, supplier:suppliers(*)').order('name').then((r) => r),
      supabase.from('suppliers').select('*').order('name').then((r) => r),
      supabase.from('raw_material_movements').select('*, material:raw_materials(*)').order('created_at', { ascending: false }).limit(100).then((r) => r),
    ]);
    setMaterials((mats.data as RawMaterial[]) || []);
    setSuppliers((sups.data as Supplier[]) || []);
    setMovements((movs.data as RawMaterialMovement[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', code: '', unit: 'Kg', current_stock: 0, minimum_stock: 0, unit_cost: 0, supplier_id: '' });
    setDialogOpen(true);
  };

  const openEdit = (m: RawMaterial) => {
    setEditing(m);
    setForm({
      name: m.name, code: m.code, unit: m.unit, current_stock: m.current_stock,
      minimum_stock: m.minimum_stock, unit_cost: m.unit_cost, supplier_id: m.supplier_id || '',
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.code) {
      toast.error('Name and code are required');
      return;
    }
    const payload = {
      name: form.name,
      code: form.code,
      unit: form.unit,
      current_stock: Number(form.current_stock),
      minimum_stock: Number(form.minimum_stock),
      unit_cost: Number(form.unit_cost),
      supplier_id: form.supplier_id || null,
    };

    if (editing) {
      const { error } = await supabase.from('raw_materials').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      // Record initial stock as movement if stock changed
      if (Number(form.current_stock) !== editing.current_stock) {
        const diff = Number(form.current_stock) - editing.current_stock;
        await supabase.from('raw_material_movements').insert({
          material_id: editing.id,
          movement_type: 'adjustment',
          quantity_change: diff,
          balance_after: Number(form.current_stock),
          reference: 'Manual adjustment',
          notes: 'Stock adjusted during edit',
        });
      }
      toast.success('Raw material updated');
    } else {
      const { data, error } = await supabase.from('raw_materials').insert(payload).select().single();
      if (error) { toast.error(error.message); return; }
      if (data && Number(form.current_stock) > 0) {
        await supabase.from('raw_material_movements').insert({
          material_id: data.id,
          movement_type: 'stock_in',
          quantity_change: Number(form.current_stock),
          balance_after: Number(form.current_stock),
          reference: 'Initial stock',
          notes: 'Initial stock entry',
        });
      }
      toast.success('Raw material added');
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('raw_materials').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Raw material deleted');
    setDeleteId(null);
    fetchData();
  };

  const handleStock = async () => {
    if (!stockDialog || stockForm.quantity <= 0) {
      toast.error('Quantity must be greater than zero');
      return;
    }
    const material = stockDialog.material;
    const change = stockDialog.type === 'in' ? stockForm.quantity : -stockForm.quantity;
    const newStock = material.current_stock + change;

    if (stockDialog.type === 'out' && newStock < 0) {
      toast.error('Insufficient stock');
      return;
    }

    const { error: updateErr } = await supabase
      .from('raw_materials')
      .update({ current_stock: newStock, updated_at: new Date().toISOString() })
      .eq('id', material.id);

    if (updateErr) { toast.error(updateErr.message); return; }

    await supabase.from('raw_material_movements').insert({
      material_id: material.id,
      movement_type: stockDialog.type === 'in' ? 'stock_in' : 'stock_out',
      quantity_change: change,
      balance_after: newStock,
      reference: stockForm.reference || 'Manual entry',
      notes: stockForm.notes,
    });

    // If stock in with unit cost reference, could update cost — skip for now
    toast.success(`Stock ${stockDialog.type === 'in' ? 'added' : 'removed'} successfully`);

    if (newStock <= material.minimum_stock) {
      triggerNotification(
        'low_stock',
        'Low Stock Alert',
        `${material.name} is ${newStock <= 0 ? 'out of stock' : 'below minimum level'}. Current: ${newStock} ${material.unit}, Minimum: ${material.minimum_stock} ${material.unit}.`,
      );
    }
    setStockDialog(null);
    setStockForm({ quantity: 0, notes: '', reference: '' });
    fetchData();
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Name', 'Code', 'Unit', 'Current Stock', 'Min Stock', 'Unit Cost', 'Stock Value', 'Supplier'];
    const rows = filtered.map((m) => [
      m.name, m.code, m.unit, m.current_stock, m.minimum_stock, m.unit_cost,
      (m.current_stock * m.unit_cost).toFixed(2), m.supplier?.name || '',
    ]);
    if (format === 'csv') exportToCSV('raw-materials', headers, rows);
    else exportToExcel('raw-materials', headers, rows);
    toast.success('Exported successfully');
  };

  const filtered = materials.filter((m) =>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.code.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Raw Material Inventory" description="Manage cement, sand, aggregate, admixtures and more">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button variant="outline" onClick={() => navigate('/purchases')}>
          <ShoppingCart className="h-4 w-4 mr-2" /> Record Purchase
        </Button>
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4 mr-2" /> Add Material
        </Button>
      </PageHeader>

      <Tabs defaultValue="inventory">
        <TabsList>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="movements">Stock Movements</TabsTrigger>
        </TabsList>

        <TabsContent value="inventory" className="mt-4">
          <div className="mb-4 relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search materials..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>

          {filtered.length === 0 ? (
            <Card>
              <CardContent>
                <EmptyState
                  icon={<Package className="h-6 w-6" />}
                  title="No raw materials found"
                  description="Add your first raw material to start tracking inventory."
                  action={<Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> Add Material</Button>}
                />
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Code</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead className="text-right">Current Stock</TableHead>
                        <TableHead className="text-right">Min Level</TableHead>
                        <TableHead className="text-right">Unit Cost</TableHead>
                        <TableHead className="text-right">Stock Value</TableHead>
                        <TableHead>Supplier</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.map((m) => {
                        const isLow = m.current_stock <= m.minimum_stock;
                        return (
                          <TableRow key={m.id}>
                            <TableCell className="font-medium">{m.name}</TableCell>
                            <TableCell className="text-muted-foreground">{m.code}</TableCell>
                            <TableCell>{m.unit}</TableCell>
                            <TableCell className="text-right font-semibold">{formatNumber(m.current_stock, 1)}</TableCell>
                            <TableCell className="text-right text-muted-foreground">{formatNumber(m.minimum_stock, 1)}</TableCell>
                            <TableCell className="text-right">{formatCurrency(m.unit_cost)}</TableCell>
                            <TableCell className="text-right font-semibold">{formatCurrency(m.current_stock * m.unit_cost)}</TableCell>
                            <TableCell className="text-muted-foreground">{m.supplier?.name || '-'}</TableCell>
                            <TableCell>
                              {isLow ? (
                                <Badge variant="destructive">Low Stock</Badge>
                              ) : (
                                <Badge variant="secondary">In Stock</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="icon" title="Stock In" onClick={() => setStockDialog({ material: m, type: 'in' })}>
                                  <ArrowDownCircle className="h-4 w-4 text-success" />
                                </Button>
                                <Button variant="ghost" size="icon" title="Stock Out" onClick={() => setStockDialog({ material: m, type: 'out' })}>
                                  <ArrowUpCircle className="h-4 w-4 text-destructive" />
                                </Button>
                                <Button variant="ghost" size="icon" title="History" onClick={() => setHistoryMaterial(m)}>
                                  <History className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(m)}>
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(m.id)}>
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="movements" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Stock Movement History</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Material</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Change</TableHead>
                      <TableHead className="text-right">Balance After</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {movements.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                          No stock movements recorded yet.
                        </TableCell>
                      </TableRow>
                    ) : (
                      movements.map((mv) => (
                        <TableRow key={mv.id}>
                          <TableCell className="text-muted-foreground">{formatDateTime(mv.created_at)}</TableCell>
                          <TableCell className="font-medium">{mv.material?.name || '-'}</TableCell>
                          <TableCell>
                            <Badge variant={
                              mv.movement_type === 'purchase' || mv.movement_type === 'stock_in' ? 'default' :
                              mv.movement_type === 'production_consumption' || mv.movement_type === 'stock_out' ? 'destructive' : 'secondary'
                            }>
                              {mv.movement_type.replace(/_/g, ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell className={`text-right font-semibold ${mv.quantity_change > 0 ? 'text-success' : 'text-destructive'}`}>
                            {mv.quantity_change > 0 ? '+' : ''}{formatNumber(mv.quantity_change, 1)}
                          </TableCell>
                          <TableCell className="text-right">{formatNumber(mv.balance_after, 1)}</TableCell>
                          <TableCell className="text-muted-foreground">{mv.reference || '-'}</TableCell>
                          <TableCell className="text-muted-foreground max-w-xs truncate">{mv.notes || '-'}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Raw Material' : 'Add Raw Material'}</DialogTitle>
            <DialogDescription>
              {editing ? 'Update material details and stock levels.' : 'Enter details for the new raw material.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Material Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Cement" />
            </div>
            <div className="space-y-2">
              <Label>Code</Label>
              <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="e.g. CEM-001" />
            </div>
            <div className="space-y-2">
              <Label>Unit</Label>
              <Select value={form.unit} onValueChange={(v) => setForm({ ...form, unit: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Current Stock</Label>
              <Input type="number" step="0.001" value={form.current_stock} onChange={(e) => setForm({ ...form, current_stock: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Minimum Stock Level</Label>
              <Input type="number" step="0.001" value={form.minimum_stock} onChange={(e) => setForm({ ...form, minimum_stock: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Unit Cost (₹)</Label>
              <Input type="number" step="0.01" value={form.unit_cost} onChange={(e) => setForm({ ...form, unit_cost: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Supplier</Label>
              <Select value={form.supplier_id} onValueChange={(v) => setForm({ ...form, supplier_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
                <SelectContent>
                  {suppliers.map((s) => <SelectItem key={s.id} value={s.id}>{s.name} - {s.company}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Add'} Material</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stock In/Out Dialog */}
      <Dialog open={!!stockDialog} onOpenChange={(o) => !o && setStockDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Stock {stockDialog?.type === 'in' ? 'In' : 'Out'} - {stockDialog?.material.name}</DialogTitle>
            <DialogDescription>
              Current stock: {stockDialog && formatNumber(stockDialog.material.current_stock, 1)} {stockDialog?.material.unit}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Quantity</Label>
              <Input type="number" step="0.001" value={stockForm.quantity} onChange={(e) => setStockForm({ ...stockForm, quantity: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Reference</Label>
              <Input value={stockForm.reference} onChange={(e) => setStockForm({ ...stockForm, reference: e.target.value })} placeholder="e.g. Purchase order, batch number" />
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Input value={stockForm.notes} onChange={(e) => setStockForm({ ...stockForm, notes: e.target.value })} placeholder="Additional notes" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStockDialog(null)}>Cancel</Button>
            <Button onClick={handleStock} variant={stockDialog?.type === 'in' ? 'default' : 'destructive'}>
              {stockDialog?.type === 'in' ? 'Add Stock' : 'Remove Stock'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={!!historyMaterial} onOpenChange={(o) => !o && setHistoryMaterial(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Stock History - {historyMaterial?.name}</DialogTitle>
            <DialogDescription>Movement history for this material</DialogDescription>
          </DialogHeader>
          <div className="max-h-[400px] overflow-y-auto scrollbar-thin">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Change</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {movements.filter((m) => m.material_id === historyMaterial?.id).map((mv) => (
                  <TableRow key={mv.id}>
                    <TableCell className="text-xs text-muted-foreground">{formatDateTime(mv.created_at)}</TableCell>
                    <TableCell><Badge variant="secondary">{mv.movement_type.replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell className={`text-right font-semibold ${mv.quantity_change > 0 ? 'text-success' : 'text-destructive'}`}>
                      {mv.quantity_change > 0 ? '+' : ''}{formatNumber(mv.quantity_change, 1)}
                    </TableCell>
                    <TableCell className="text-right">{formatNumber(mv.balance_after, 1)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Raw Material?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the material and all its movement history. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
