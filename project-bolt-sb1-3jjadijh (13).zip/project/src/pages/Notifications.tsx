import { useEffect, useState } from 'react';
import { Bell, AlertTriangle, CheckCircle2, XCircle, Info, RefreshCw } from 'lucide-react';
import { useNotifications, type Alert } from '@/hooks/use-notifications';
import { PageHeader, EmptyState } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';

const SEVERITY_CONFIG = {
  error: { icon: XCircle, color: 'text-destructive', bg: 'bg-destructive/5', border: 'border-destructive/20' },
  warning: { icon: AlertTriangle, color: 'text-warning', bg: 'bg-warning/5', border: 'border-warning/20' },
  info: { icon: Info, color: 'text-primary', bg: 'bg-primary/5', border: 'border-primary/20' },
};

const TYPE_LABELS: Record<Alert['type'], string> = {
  low_stock: 'Low Stock',
  pending_payment: 'Pending Payment',
  outstanding_balance: 'Outstanding Balance',
  failed_production: 'Failed Production',
};

export default function Notifications() {
  const { alerts, loading, refresh } = useNotifications();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'all' | Alert['severity']>('all');

  const filtered = filter === 'all' ? alerts : alerts.filter((a) => a.severity === filter);

  const handleAlertClick = (alert: Alert) => {
    switch (alert.type) {
      case 'low_stock': navigate('/raw-materials'); break;
      case 'pending_payment': navigate('/sales'); break;
      case 'outstanding_balance': navigate('/customers'); break;
      case 'failed_production': navigate('/production'); break;
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Notifications & Alerts" description="Stay informed about critical business events">
        <Button variant="outline" size="sm" onClick={refresh}>
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
      </PageHeader>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-5 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-destructive/10 flex items-center justify-center">
              <XCircle className="h-5 w-5 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Critical</p>
              <p className="font-display text-xl font-bold">{alerts.filter((a) => a.severity === 'error').length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
              <AlertTriangle className="h-5 w-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Warnings</p>
              <p className="font-display text-xl font-bold">{alerts.filter((a) => a.severity === 'warning').length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Info className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Info</p>
              <p className="font-display text-xl font-bold">{alerts.filter((a) => a.severity === 'info').length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(['all', 'error', 'warning', 'info'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              filter === f ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/70'
            }`}
          >
            {f === 'all' ? 'All' : f === 'error' ? 'Critical' : f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Alerts list */}
      {loading ? (
        <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<CheckCircle2 className="h-6 w-6" />}
              title="All clear!"
              description="No alerts at this time. Everything looks good."
            />
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((alert) => {
            const config = SEVERITY_CONFIG[alert.severity];
            const Icon = config.icon;
            return (
              <Card
                key={alert.id}
                className={`cursor-pointer hover:shadow-md transition-shadow ${config.border}`}
                onClick={() => handleAlertClick(alert)}
              >
                <CardContent className="p-4 flex items-start gap-3">
                  <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${config.bg}`}>
                    <Icon className={`h-5 w-5 ${config.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-sm">{alert.title}</h3>
                      <Badge variant="outline" className="text-xs">{TYPE_LABELS[alert.type]}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{alert.message}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
