import { useEffect, useState, useCallback } from 'react';
import { Plus, ShoppingCart, Download, Search, Pencil, Trash2, Printer, Eye } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Purchase, Supplier, RawMaterial } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatNumber, formatDate } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { exportToCSV, exportToExcel, printDocument } from '@/lib/export';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

export default function Purchases() {
  const { profile } = useAuth();
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [materials, setMaterials] = useState<RawMaterial[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Purchase | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [viewPurchase, setViewPurchase] = useState<Purchase | null>(null);

  const [form, setForm] = useState({
    supplier_id: '',
    bill_number: '',
    bill_date: new Date().toISOString().split('T')[0],
    material_id: '',
    quantity: 0,
    unit_cost: 0,
    amount_paid: 0,
    notes: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [purs, sups, mats] = await Promise.all([
      supabase.from('purchases').select('*, supplier:suppliers(*), material:raw_materials(*)').order('created_at', { ascending: false }).then((r) => r),
      supabase.from('suppliers').select('*').order('name').then((r) => r),
      supabase.from('raw_materials').select('*').order('name').then((r) => r),
    ]);
    setPurchases((purs.data as Purchase[]) || []);
    setSuppliers((sups.data as Supplier[]) || []);
    setMaterials((mats.data as RawMaterial[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({
      supplier_id: '', bill_number: '', bill_date: new Date().toISOString().split('T')[0],
      material_id: '', quantity: 0, unit_cost: 0, amount_paid: 0, notes: '',
    });
    setDialogOpen(true);
  };

  const openEdit = (p: Purchase) => {
    setEditing(p);
    setForm({
      supplier_id: p.supplier_id, bill_number: p.bill_number, bill_date: p.bill_date,
      material_id: p.material_id, quantity: p.quantity, unit_cost: Number(p.unit_cost),
      amount_paid: Number(p.amount_paid), notes: p.notes,
    });
    setDialogOpen(true);
  };

  const billAmount = form.quantity * form.unit_cost;
  const paymentStatus = form.amount_paid >= billAmount ? 'paid' : form.amount_paid > 0 ? 'partial' : 'unpaid';

  const handleSave = async () => {
    if (!form.supplier_id || !form.material_id || form.quantity <= 0) {
      toast.error('Supplier, material, and quantity are required');
      return;
    }

    const payload = {
      supplier_id: form.supplier_id,
      bill_number: form.bill_number,
      bill_date: form.bill_date,
      material_id: form.material_id,
      quantity: Number(form.quantity),
      unit_cost: Number(form.unit_cost),
      bill_amount: Number(billAmount.toFixed(2)),
      amount_paid: Number(form.amount_paid),
      payment_status: paymentStatus,
      notes: form.notes,
    };

    if (editing) {
      const { error } = await supabase.from('purchases').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success('Purchase updated');
    } else {
      const { data: numData } = await supabase.rpc('next_purchase_number');
      const purNumber = numData as string;
      const { error } = await supabase.from('purchases').insert({ ...payload, purchase_number: purNumber });
      if (error) { toast.error(error.message); return; }

      // Add stock to the raw material
      const material = materials.find((m) => m.id === form.material_id);
      if (material) {
        const newStock = material.current_stock + Number(form.quantity);
        await supabase
          .from('raw_materials')
          .update({ current_stock: newStock, unit_cost: Number(form.unit_cost), updated_at: new Date().toISOString() })
          .eq('id', form.material_id);

        // Record stock movement linked to the bill
        await supabase.from('raw_material_movements').insert({
          material_id: form.material_id,
          movement_type: 'purchase',
          quantity_change: Number(form.quantity),
          balance_after: newStock,
          reference: `${purNumber} (Bill: ${form.bill_number || 'N/A'})`,
          notes: `Purchase from ${suppliers.find((s) => s.id === form.supplier_id)?.name || ''} - ${form.notes || ''}`,
        });
      }

      // Update supplier outstanding payment
      const supplier = suppliers.find((s) => s.id === form.supplier_id);
      if (supplier) {
        const outstanding = billAmount - Number(form.amount_paid);
        await supabase.from('suppliers').update({
          outstanding_payment: Number(supplier.outstanding_payment) + outstanding,
        }).eq('id', form.supplier_id);
      }

      await supabase.from('activity_logs').insert({
        user_email: profile?.email || '',
        action: 'purchase_created',
        entity: 'purchase',
        details: `Purchase ${purNumber} - ${formatCurrency(billAmount)} (Bill: ${form.bill_number || 'N/A'})`,
      });

      toast.success(`Purchase ${purNumber} recorded — stock added`);
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const purchase = purchases.find((p) => p.id === deleteId);
    if (purchase) {
      // Reverse the stock addition
      const material = materials.find((m) => m.id === purchase.material_id);
      if (material) {
        const newStock = material.current_stock - purchase.quantity;
        await supabase
          .from('raw_materials')
          .update({ current_stock: newStock, updated_at: new Date().toISOString() })
          .eq('id', purchase.material_id);

        await supabase.from('raw_material_movements').insert({
          material_id: purchase.material_id,
          movement_type: 'adjustment',
          quantity_change: -purchase.quantity,
          balance_after: newStock,
          reference: `Reversed: ${purchase.purchase_number}`,
          notes: 'Stock reversed due to purchase deletion',
        });
      }

      // Reverse supplier outstanding
      const supplier = suppliers.find((s) => s.id === purchase.supplier_id);
      if (supplier) {
        const outstanding = Number(purchase.bill_amount) - Number(purchase.amount_paid);
        await supabase.from('suppliers').update({
          outstanding_payment: Math.max(0, Number(supplier.outstanding_payment) - outstanding),
        }).eq('id', purchase.supplier_id);
      }
    }

    const { error } = await supabase.from('purchases').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Purchase deleted and stock reversed');
    setDeleteId(null);
    fetchData();
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Purchase #', 'Bill #', 'Bill Date', 'Supplier', 'Material', 'Qty', 'Unit Cost', 'Bill Amount', 'Paid', 'Outstanding', 'Status'];
    const rows = filtered.map((p) => [
      p.purchase_number, p.bill_number, p.bill_date, p.supplier?.name || '',
      p.material?.name || '', p.quantity, p.unit_cost, p.bill_amount,
      p.amount_paid, (Number(p.bill_amount) - Number(p.amount_paid)).toFixed(2), p.payment_status,
    ]);
    if (format === 'csv') exportToCSV('purchases', headers, rows);
    else exportToExcel('purchases', headers, rows);
    toast.success('Exported successfully');
  };

  const printPurchase = (p: Purchase) => {
    const html = `
      <div class="header">
        <div>
          <div class="company-name">ConcreteFlow ERP</div>
          <p style="font-size:13px;color:#666;">Concrete Mixing Plant Manufacturer</p>
        </div>
        <div class="meta">
          <h1>PURCHASE BILL</h1>
          <p><strong>${p.purchase_number}</strong></p>
          <p>Bill Date: ${formatDate(p.bill_date)}</p>
          <p>Status: <span class="badge" style="background:${p.payment_status === 'paid' ? '#dcfce7' : p.payment_status === 'partial' ? '#fef9c3' : '#fee2e2'};color:${p.payment_status === 'paid' ? '#166534' : p.payment_status === 'partial' ? '#854d0e' : '#991b1b'};">${p.payment_status.toUpperCase()}</span></p>
        </div>
      </div>
      <div style="margin-bottom:24px;">
        <h2 style="font-size:14px;color:#999;margin-bottom:4px;">Supplier:</h2>
        <p style="font-size:15px;font-weight:bold;">${p.supplier?.name || ''}</p>
        <p style="font-size:13px;color:#555;">${p.supplier?.company || ''}</p>
        <p style="font-size:13px;color:#555;">GST: ${p.supplier?.gst_number || 'N/A'}</p>
        <p style="font-size:13px;color:#555;">${p.supplier?.contact || ''}</p>
      </div>
      <table>
        <thead>
          <tr>
            <th>Material</th>
            <th>Quantity</th>
            <th>Unit Cost</th>
            <th style="text-align:right;">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${p.material?.name || ''}</td>
            <td>${formatNumber(p.quantity, 1)} ${p.material?.unit || ''}</td>
            <td>${formatCurrency(Number(p.unit_cost))}</td>
            <td style="text-align:right;">${formatCurrency(Number(p.bill_amount))}</td>
          </tr>
        </tbody>
      </table>
      <table class="totals">
        <tr><td>Bill Amount:</td><td style="text-align:right;">${formatCurrency(Number(p.bill_amount))}</td></tr>
        <tr><td>Amount Paid:</td><td style="text-align:right;">${formatCurrency(Number(p.amount_paid))}</td></tr>
        <tr class="grand"><td>Outstanding:</td><td style="text-align:right;">${formatCurrency(Number(p.bill_amount) - Number(p.amount_paid))}</td></tr>
      </table>
      ${p.notes ? `<p style="margin-top:24px;font-size:13px;color:#666;"><strong>Notes:</strong> ${p.notes}</p>` : ''}
    `;
    printDocument(`Purchase ${p.purchase_number}`, html);
  };

  const filtered = purchases.filter((p) =>
    p.purchase_number.toLowerCase().includes(search.toLowerCase()) ||
    p.bill_number.toLowerCase().includes(search.toLowerCase()) ||
    (p.supplier?.name || '').toLowerCase().includes(search.toLowerCase()) ||
    (p.material?.name || '').toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Purchase Entries" description="Record raw material purchases with full supplier bill details">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openAdd} disabled={suppliers.length === 0 || materials.length === 0}>
          <Plus className="h-4 w-4 mr-2" /> New Purchase
        </Button>
      </PageHeader>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Total Purchases</p>
            <p className="font-display text-2xl font-bold mt-1">{formatCurrency(purchases.reduce((s, p) => s + Number(p.bill_amount), 0))}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Total Paid</p>
            <p className="font-display text-2xl font-bold mt-1 text-success">{formatCurrency(purchases.reduce((s, p) => s + Number(p.amount_paid), 0))}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5">
            <p className="text-sm text-muted-foreground">Outstanding to Suppliers</p>
            <p className="font-display text-2xl font-bold mt-1 text-destructive">
              {formatCurrency(purchases.reduce((s, p) => s + (Number(p.bill_amount) - Number(p.amount_paid)), 0))}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by bill number, supplier, or material..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<ShoppingCart className="h-6 w-6" />}
              title="No purchase entries found"
              description={suppliers.length === 0 ? 'Add suppliers first, then record purchases.' : 'Record your first supplier purchase to add raw material stock with full bill details.'}
              action={suppliers.length > 0 && materials.length > 0 ? <Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> New Purchase</Button> : undefined}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Purchase #</TableHead>
                    <TableHead>Bill #</TableHead>
                    <TableHead>Bill Date</TableHead>
                    <TableHead>Supplier</TableHead>
                    <TableHead>Material</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Bill Amount</TableHead>
                    <TableHead className="text-right">Paid</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-mono text-sm">{p.purchase_number}</TableCell>
                      <TableCell className="font-medium">{p.bill_number || '-'}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(p.bill_date)}</TableCell>
                      <TableCell>{p.supplier?.name || '-'}</TableCell>
                      <TableCell>{p.material?.name || '-'}</TableCell>
                      <TableCell className="text-right">{formatNumber(p.quantity, 1)} {p.material?.unit || ''}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(Number(p.bill_amount))}</TableCell>
                      <TableCell className="text-right">{formatCurrency(Number(p.amount_paid))}</TableCell>
                      <TableCell>
                        <Badge variant={p.payment_status === 'paid' ? 'default' : p.payment_status === 'partial' ? 'secondary' : 'destructive'}>
                          {p.payment_status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" title="View" onClick={() => setViewPurchase(p)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Print" onClick={() => printPurchase(p)}>
                            <Printer className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(p)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(p.id)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Purchase Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Purchase' : 'New Purchase Entry'}</DialogTitle>
            <DialogDescription>
              Record a supplier purchase with full bill details. Raw material stock will be added automatically,
              and the supplier's outstanding payment will be updated.
            </DialogDescription>
          </DialogHeader>

          {/* Supplier Bill Details */}
          <div className="rounded-lg bg-muted/30 p-4 space-y-3">
            <h4 className="text-sm font-semibold">Supplier Bill Details</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Supplier</Label>
                <Select value={form.supplier_id} onValueChange={(v) => setForm({ ...form, supplier_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
                  <SelectContent>
                    {suppliers.map((s) => (
                      <SelectItem key={s.id} value={s.id}>{s.name} - {s.company}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Bill Number</Label>
                <Input value={form.bill_number} onChange={(e) => setForm({ ...form, bill_number: e.target.value })} placeholder="Supplier's bill number" />
              </div>
              <div className="space-y-2">
                <Label>Bill Date</Label>
                <Input type="date" value={form.bill_date} onChange={(e) => setForm({ ...form, bill_date: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Amount Paid (₹)</Label>
                <Input type="number" step="0.01" value={form.amount_paid} onChange={(e) => setForm({ ...form, amount_paid: Number(e.target.value) })} />
              </div>
            </div>
          </div>

          {/* Material Details */}
          <div className="rounded-lg bg-muted/30 p-4 space-y-3">
            <h4 className="text-sm font-semibold">Material Details</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2 col-span-2">
                <Label>Raw Material</Label>
                <Select
                  value={form.material_id}
                  onValueChange={(v) => {
                    const m = materials.find((m) => m.id === v);
                    setForm({ ...form, material_id: v, unit_cost: m ? Number(m.unit_cost) : form.unit_cost });
                  }}
                >
                  <SelectTrigger><SelectValue placeholder="Select material" /></SelectTrigger>
                  <SelectContent>
                    {materials.map((m) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.name} ({m.unit}) - Stock: {formatNumber(m.current_stock, 1)} - Cost: {formatCurrency(m.unit_cost)}/{m.unit}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quantity</Label>
                <Input type="number" step="0.001" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} />
              </div>
              <div className="space-y-2">
                <Label>Unit Cost (₹)</Label>
                <Input type="number" step="0.01" value={form.unit_cost} onChange={(e) => setForm({ ...form, unit_cost: Number(e.target.value) })} />
              </div>
              <div className="space-y-2 col-span-2">
                <Label>Notes</Label>
                <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} placeholder="Additional notes about this purchase" />
              </div>
            </div>
          </div>

          {/* Bill Summary */}
          <div className="rounded-lg border p-4 space-y-2 text-sm">
            <div className="flex justify-between"><span>Bill Amount (Qty x Cost):</span><span className="font-medium">{formatCurrency(billAmount)}</span></div>
            <div className="flex justify-between"><span>Amount Paid:</span><span className="font-medium text-success">{formatCurrency(Number(form.amount_paid))}</span></div>
            <div className="flex justify-between font-bold border-t pt-2"><span>Outstanding:</span><span className="text-destructive">{formatCurrency(billAmount - Number(form.amount_paid))}</span></div>
            <div className="flex justify-between"><span>Payment Status:</span>
              <Badge variant={paymentStatus === 'paid' ? 'default' : paymentStatus === 'partial' ? 'secondary' : 'destructive'}>{paymentStatus}</Badge>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Record'} Purchase</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Purchase Dialog */}
      <Dialog open={!!viewPurchase} onOpenChange={(o) => !o && setViewPurchase(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Purchase {viewPurchase?.purchase_number}</DialogTitle>
            <DialogDescription>Supplier bill details</DialogDescription>
          </DialogHeader>
          {viewPurchase && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Supplier</p>
                  <p className="font-medium">{viewPurchase.supplier?.name}</p>
                  <p className="text-muted-foreground">{viewPurchase.supplier?.company}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Bill Number</p>
                  <p className="font-medium">{viewPurchase.bill_number || 'N/A'}</p>
                  <p className="text-muted-foreground">{formatDate(viewPurchase.bill_date)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Material</p>
                  <p className="font-medium">{viewPurchase.material?.name}</p>
                  <p className="text-muted-foreground">{formatNumber(viewPurchase.quantity, 1)} {viewPurchase.material?.unit} @ {formatCurrency(Number(viewPurchase.unit_cost))}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Payment</p>
                  <Badge variant={viewPurchase.payment_status === 'paid' ? 'default' : viewPurchase.payment_status === 'partial' ? 'secondary' : 'destructive'}>
                    {viewPurchase.payment_status}
                  </Badge>
                </div>
              </div>
              <div className="rounded-lg border p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span>Bill Amount:</span><span className="font-medium">{formatCurrency(Number(viewPurchase.bill_amount))}</span></div>
                <div className="flex justify-between"><span>Paid:</span><span className="font-medium text-success">{formatCurrency(Number(viewPurchase.amount_paid))}</span></div>
                <div className="flex justify-between font-bold border-t pt-2"><span>Outstanding:</span><span className="text-destructive">{formatCurrency(Number(viewPurchase.bill_amount) - Number(viewPurchase.amount_paid))}</span></div>
              </div>
              {viewPurchase.notes && (
                <div>
                  <p className="text-sm text-muted-foreground">Notes</p>
                  <p className="text-sm">{viewPurchase.notes}</p>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewPurchase(null)}>Close</Button>
            <Button onClick={() => viewPurchase && printPurchase(viewPurchase)}>
              <Printer className="h-4 w-4 mr-2" /> Print / PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Purchase Entry?</AlertDialogTitle>
            <AlertDialogDescription>
              This will reverse the stock addition and supplier outstanding payment. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete & Reverse Stock
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
