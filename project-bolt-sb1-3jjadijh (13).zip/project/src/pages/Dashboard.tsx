import { useEffect, useState, useMemo } from 'react';
import {
  Package, Layers, Factory, TrendingUp, Wallet, TrendingDown,
  DollarSign, AlertTriangle, ArrowRight,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { supabase } from '@/lib/supabase';
import type { RawMaterial, FinishedProduct, Production, SalesInvoice, Expense } from '@/lib/supabase';
import { PageHeader, StatCard, formatCurrency, formatNumber, formatDateTime } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '@/hooks/use-notifications';

interface DashboardData {
  rawMaterials: RawMaterial[];
  finishedProducts: FinishedProduct[];
  productions: Production[];
  invoices: SalesInvoice[];
  expenses: Expense[];
}

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { alerts } = useNotifications();

  useEffect(() => {
    (async () => {
      const [rawMaterials, finishedProducts, productions, invoices, expenses] = await Promise.all([
        supabase.from('raw_materials').select('*').then((r) => r.data as RawMaterial[] | null),
        supabase.from('finished_products').select('*').then((r) => r.data as FinishedProduct[] | null),
        supabase.from('productions').select('*').order('created_at', { ascending: false }).limit(20).then((r) => r.data as Production[] | null),
        supabase.from('sales_invoices').select('*').order('created_at', { ascending: false }).limit(20).then((r) => r.data as SalesInvoice[] | null),
        supabase.from('expenses').select('*').order('expense_date', { ascending: false }).limit(50).then((r) => r.data as Expense[] | null),
      ]);

      setData({
        rawMaterials: rawMaterials || [],
        finishedProducts: finishedProducts || [],
        productions: productions || [],
        invoices: invoices || [],
        expenses: expenses || [],
      });
      setLoading(false);
    })();
  }, []);

  const metrics = useMemo(() => {
    if (!data) return null;

    const totalRawStock = data.rawMaterials.reduce(
      (sum, m) => sum + m.current_stock * m.unit_cost, 0
    );
    const totalFinishedStock = data.finishedProducts.reduce(
      (sum, p) => sum + p.current_stock * p.selling_price, 0
    );

    const today = new Date().toISOString().split('T')[0];
    const todayProduction = data.productions.filter(
      (p) => p.production_date === today
    );
    const todayProductionQty = todayProduction.reduce((s, p) => s + p.quantity, 0);

    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    const monthlySales = data.invoices.filter((inv) => {
      const d = new Date(inv.invoice_date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });
    const monthlyRevenue = monthlySales.reduce((s, inv) => s + Number(inv.total_amount), 0);

    const totalRevenue = data.invoices.reduce((s, inv) => s + Number(inv.total_amount), 0);
    const totalExpenses = data.expenses.reduce((s, e) => s + Number(e.amount), 0);
    const totalProductionCost = data.productions.reduce((s, p) => s + Number(p.total_cost), 0);

    const outstandingPayments = data.invoices
      .filter((inv) => inv.payment_status !== 'paid')
      .reduce((s, inv) => s + (Number(inv.total_amount) - Number(inv.amount_paid)), 0);

    const grossProfit = totalRevenue - totalProductionCost - totalExpenses;

    const lowStockMaterials = data.rawMaterials.filter(
      (m) => m.current_stock <= m.minimum_stock
    );

    return {
      totalRawStock,
      totalFinishedStock,
      todayProductionQty,
      todayProductionCount: todayProduction.length,
      monthlyRevenue,
      totalRevenue,
      totalExpenses,
      grossProfit,
      outstandingPayments,
      lowStockMaterials,
    };
  }, [data]);

  // Monthly chart data (last 6 months)
  const monthlyChartData = useMemo(() => {
    if (!data) return [];
    const months: { month: string; revenue: number; expenses: number; production: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const m = d.getMonth();
      const y = d.getFullYear();
      const monthName = d.toLocaleString('en-US', { month: 'short' });

      const revenue = data.invoices
        .filter((inv) => {
          const id = new Date(inv.invoice_date);
          return id.getMonth() === m && id.getFullYear() === y;
        })
        .reduce((s, inv) => s + Number(inv.total_amount), 0);

      const expenses = data.expenses
        .filter((e) => {
          const ed = new Date(e.expense_date);
          return ed.getMonth() === m && ed.getFullYear() === y;
        })
        .reduce((s, e) => s + Number(e.amount), 0);

      const production = data.productions
        .filter((p) => {
          const pd = new Date(p.production_date);
          return pd.getMonth() === m && pd.getFullYear() === y;
        })
        .reduce((s, p) => s + p.quantity, 0);

      months.push({ month: monthName, revenue, expenses, production });
    }
    return months;
  }, [data]);

  // Product stock distribution
  const productStockData = useMemo(() => {
    if (!data) return [];
    return data.finishedProducts
      .filter((p) => p.current_stock > 0)
      .map((p) => ({ name: p.code, value: p.current_stock, stockValue: p.current_stock * p.selling_price }));
  }, [data]);

  // Recent transactions
  const recentTransactions = useMemo(() => {
    if (!data) return [];
    const txns: { date: string; type: string; description: string; amount: number; status: string }[] = [];

    data.invoices.slice(0, 5).forEach((inv) => {
      txns.push({
        date: inv.created_at,
        type: 'Sale',
        description: `Invoice ${inv.invoice_number}`,
        amount: Number(inv.total_amount),
        status: inv.payment_status,
      });
    });

    data.expenses.slice(0, 5).forEach((e) => {
      txns.push({
        date: e.created_at,
        type: 'Expense',
        description: `${e.category} - ${e.vendor || 'N/A'}`,
        amount: Number(e.amount),
        status: 'paid',
      });
    });

    return txns.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 8);
  }, [data]);

  if (loading || !metrics) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-shimmer h-8 w-8 rounded-full" />
      </div>
    );
  }

  const PIE_COLORS = ['hsl(200, 85%, 42%)', 'hsl(142, 71%, 38%)', 'hsl(38, 92%, 50%)', 'hsl(0, 72%, 51%)', 'hsl(270, 65%, 55%)', 'hsl(200, 85%, 60%)', 'hsl(142, 71%, 55%)'];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        description="Real-time overview of your concrete plant operations"
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Raw Material Stock Value"
          value={formatCurrency(metrics.totalRawStock)}
          icon={<Package className="h-5 w-5" />}
          variant="primary"
        />
        <StatCard
          title="Finished Product Stock Value"
          value={formatCurrency(metrics.totalFinishedStock)}
          icon={<Layers className="h-5 w-5" />}
          variant="success"
        />
        <StatCard
          title="Today's Production"
          value={`${formatNumber(metrics.todayProductionQty, 1)} m³`}
          icon={<Factory className="h-5 w-5" />}
          variant="warning"
          trend={{ value: `${metrics.todayProductionCount} batches`, positive: true }}
        />
        <StatCard
          title="Monthly Sales"
          value={formatCurrency(metrics.monthlyRevenue)}
          icon={<TrendingUp className="h-5 w-5" />}
          variant="primary"
        />
        <StatCard
          title="Total Revenue"
          value={formatCurrency(metrics.totalRevenue)}
          icon={<DollarSign className="h-5 w-5" />}
          variant="success"
        />
        <StatCard
          title="Total Expenses"
          value={formatCurrency(metrics.totalExpenses)}
          icon={<TrendingDown className="h-5 w-5" />}
          variant="error"
        />
        <StatCard
          title="Gross Profit / Loss"
          value={formatCurrency(metrics.grossProfit)}
          icon={<Wallet className="h-5 w-5" />}
          variant={metrics.grossProfit >= 0 ? 'success' : 'error'}
        />
        <StatCard
          title="Outstanding Payments"
          value={formatCurrency(metrics.outstandingPayments)}
          icon={<AlertTriangle className="h-5 w-5" />}
          variant="warning"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Revenue vs Expenses chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Revenue vs Expenses (6 Months)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={monthlyChartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(200, 85%, 42%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(200, 85%, 42%)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(0, 72%, 51%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(0, 72%, 51%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '13px',
                  }}
                  formatter={(value: number) => formatCurrency(value)}
                />
                <Legend />
                <Area type="monotone" dataKey="revenue" name="Revenue" stroke="hsl(200, 85%, 42%)" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
                <Area type="monotone" dataKey="expenses" name="Expenses" stroke="hsl(0, 72%, 51%)" fillOpacity={1} fill="url(#colorExpenses)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Product stock distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Product Stock Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            {productStockData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={productStockData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    innerRadius={50}
                    paddingAngle={2}
                  >
                    {productStockData.map((_, index) => (
                      <Cell key={index} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                      fontSize: '13px',
                    }}
                    formatter={(value: number, _name, props) => [`${formatNumber(value, 1)} m³`, props.payload.name]}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground text-sm">
                No finished product stock yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Production chart + Low stock alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Monthly Production (m³)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={monthlyChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '13px',
                  }}
                />
                <Bar dataKey="production" name="Production (m³)" fill="hsl(38, 92%, 50%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Low stock alerts */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Low Stock Alerts</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate('/notifications')}>
              View all <ArrowRight className="h-3.5 w-3.5 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-3 max-h-[250px] overflow-y-auto scrollbar-thin">
            {metrics.lowStockMaterials.length === 0 && alerts.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">All stock levels are healthy.</p>
            ) : (
              <>
                {metrics.lowStockMaterials.map((m) => (
                  <div key={m.id} className="flex items-start gap-3 p-3 rounded-lg bg-warning/5 border border-warning/20">
                    <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium">{m.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatNumber(m.current_stock, 1)} {m.unit} left (min: {formatNumber(m.minimum_stock, 1)} {m.unit})
                      </p>
                    </div>
                  </div>
                ))}
                {alerts.filter((a) => a.type !== 'low_stock' && a.type !== 'outstanding_balance').map((a) => (
                  <div key={a.id} className={`flex items-start gap-3 p-3 rounded-lg border ${a.severity === 'error' ? 'bg-destructive/5 border-destructive/20' : 'bg-warning/5 border-warning/20'}`}>
                    <AlertTriangle className={`h-4 w-4 mt-0.5 shrink-0 ${a.severity === 'error' ? 'text-destructive' : 'text-warning'}`} />
                    <div className="min-w-0">
                      <p className="text-sm font-medium">{a.title}</p>
                      <p className="text-xs text-muted-foreground">{a.message}</p>
                    </div>
                  </div>
                ))}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          {recentTransactions.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">No transactions yet.</p>
          ) : (
            <div className="space-y-2">
              {recentTransactions.map((txn, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${txn.type === 'Sale' ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'}`}>
                      {txn.type === 'Sale' ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{txn.description}</p>
                      <p className="text-xs text-muted-foreground">{formatDateTime(txn.date)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <Badge variant={txn.status === 'paid' ? 'default' : txn.status === 'partial' ? 'secondary' : 'outline'}>
                      {txn.status}
                    </Badge>
                    <span className={`text-sm font-semibold ${txn.type === 'Sale' ? 'text-success' : 'text-destructive'}`}>
                      {txn.type === 'Sale' ? '+' : '-'}{formatCurrency(txn.amount)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
