import { useState, useRef, useCallback } from 'react';
import { Database, Download, Upload, Loader2, AlertTriangle, CheckCircle2, FileJson, Clock, ShieldCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { PageHeader } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { formatDateTime } from '@/components/shared';
import { toast } from 'sonner';

interface BackupMeta {
  version: number;
  exported_at: string;
  tableCount: number;
  totalRows: number;
}

export default function BackupRestore() {
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [lastBackup, setLastBackup] = useState<BackupMeta | null>(null);
  const [parsedFile, setParsedFile] = useState<{ data: any; name: string; size: number } | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleExport = useCallback(async () => {
    setExporting(true);
    try {
      const { data, error } = await supabase.rpc('export_backup');
      if (error) {
        toast.error(error.message);
        return;
      }

      const tables = data?.tables || {};
      const tableNames = Object.keys(tables);
      let totalRows = 0;
      for (const t of tableNames) {
        totalRows += Array.isArray(tables[t]) ? tables[t].length : 0;
      }

      const meta: BackupMeta = {
        version: data.version || 1,
        exported_at: data.exported_at || new Date().toISOString(),
        tableCount: tableNames.length,
        totalRows,
      };
      setLastBackup(meta);

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `concreteflow-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success(`Backup downloaded (${totalRows} records from ${tableNames.length} tables)`);
    } catch (err) {
      toast.error(`Backup failed: ${String(err)}`);
    }
    setExporting(false);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        if (!data.tables) {
          toast.error('Invalid backup file: missing "tables" key');
          return;
        }
        const tableNames = Object.keys(data.tables);
        let totalRows = 0;
        for (const t of tableNames) {
          totalRows += Array.isArray(data.tables[t]) ? data.tables[t].length : 0;
        }
        setParsedFile({ data, name: file.name, size: file.size });
        toast.success(`Backup file loaded: ${tableNames.length} tables, ${totalRows} records`);
      } catch {
        toast.error('Could not parse file. Make sure it is a valid JSON backup.');
      }
    };
    reader.readAsText(file);
  };

  const handleRestore = async () => {
    if (!parsedFile) return;
    setImporting(true);
    setShowConfirm(false);
    try {
      const { data, error } = await supabase.rpc('import_backup', { p_data: parsedFile.data });
      if (error) {
        toast.error(error.message);
        return;
      }
      if (data?.success === false) {
        toast.error(data.error || 'Restore failed');
        return;
      }
      // Re-sync profiles from auth.users so user accounts aren't lost after restore
      await supabase.rpc('sync_profiles_from_auth_users');
      toast.success(`Database restored successfully (${data?.rows_restored || 0} records)`);
      setParsedFile(null);
      if (fileRef.current) fileRef.current.value = '';
    } catch (err) {
      toast.error(`Restore failed: ${String(err)}`);
    }
    setImporting(false);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Backup & Restore"
        description="Export your entire database to a file, or restore from a previous backup"
      />

      {/* Warning banner */}
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Important</AlertTitle>
        <AlertDescription>
          Restoring a backup will permanently replace ALL current data in the system. Make sure you have a current backup before restoring. This action cannot be undone.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Export Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Download className="h-5 w-5 text-primary" />
              </div>
              Export Backup
            </CardTitle>
            <CardDescription>Download all your ERP data as a JSON file</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>Creates a complete snapshot of your database including:</p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>All raw materials, finished products, and BOMs</li>
                <li>Production batches and stock movements</li>
                <li>Sales invoices, quotations, and customers</li>
                <li>Purchases, suppliers, and expenses</li>
                <li>Notification settings and logs</li>
                <li>User permissions, profiles, and company info</li>
              </ul>
            </div>
            <Button onClick={handleExport} disabled={exporting} className="w-full">
              {exporting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" /> Download Backup
                </>
              )}
            </Button>
            {lastBackup && (
              <div className="rounded-lg border border-border p-3 space-y-1">
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-success" />
                  <span className="font-medium">Last backup exported</span>
                </div>
                <div className="text-xs text-muted-foreground space-y-0.5 pl-6">
                  <p>{formatDateTime(lastBackup.exported_at)}</p>
                  <p>{lastBackup.totalRows} records across {lastBackup.tableCount} tables</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Import Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center">
                <Upload className="h-5 w-5 text-warning" />
              </div>
              Restore from Backup
            </CardTitle>
            <CardDescription>Upload a backup file to restore your database</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>Upload a previously downloaded backup JSON file to restore your data.</p>
              <p className="flex items-start gap-1.5 text-destructive">
                <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>This will erase all current data and replace it with the backup contents.</span>
              </p>
            </div>

            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              onChange={handleFileSelect}
              className="hidden"
            />

            <Button
              variant="outline"
              onClick={() => fileRef.current?.click()}
              disabled={importing}
              className="w-full"
            >
              <FileJson className="h-4 w-4 mr-2" /> Choose Backup File
            </Button>

            {parsedFile && (
              <div className="space-y-3">
                <div className="rounded-lg border border-border p-3 space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <FileJson className="h-4 w-4 text-primary" />
                    <span className="font-medium truncate">{parsedFile.name}</span>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-0.5 pl-6">
                    <p>Size: {formatFileSize(parsedFile.size)}</p>
                    <p>Exported: {parsedFile.data.exported_at ? formatDateTime(parsedFile.data.exported_at) : 'Unknown'}</p>
                    <p>Version: {parsedFile.data.version || 'Unknown'}</p>
                  </div>
                </div>
                <Button
                  variant="destructive"
                  onClick={() => setShowConfirm(true)}
                  disabled={importing}
                  className="w-full"
                >
                  {importing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Restoring...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" /> Restore Database
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Info card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            How Backup & Restore Works
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Database className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="font-medium text-foreground">Full Database Snapshot</p>
              <p>The export captures all business data tables including user profiles and permissions in a single JSON file. Authentication accounts are managed separately and automatically re-linked after restore.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Clock className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="font-medium text-foreground">Point-in-Time Recovery</p>
              <p>Each backup file includes a timestamp. Download backups regularly and keep them somewhere safe — they are your recovery point if data is ever lost or corrupted.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <ShieldCheck className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="font-medium text-foreground">Admin Only</p>
              <p>Only admin users can access this page and perform backup or restore operations.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confirmation dialog */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={() => setShowConfirm(false)}>
          <div className="bg-background rounded-lg shadow-lg max-w-md w-full mx-4 p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <h3 className="font-display text-lg font-bold">Confirm Restore</h3>
                <p className="text-sm text-muted-foreground">This action cannot be undone.</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              You are about to replace ALL current data with the contents of <span className="font-medium text-foreground">{parsedFile?.name}</span>. All existing records will be permanently deleted.
            </p>
            <p className="text-sm font-medium text-destructive">
              Are you sure you want to continue?
            </p>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setShowConfirm(false)}>Cancel</Button>
              <Button variant="destructive" onClick={handleRestore}>Yes, Restore Now</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
