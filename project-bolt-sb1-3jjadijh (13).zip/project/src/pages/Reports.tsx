import { useEffect, useState } from 'react';
import { FileBarChart, Download, FileSpreadsheet, FileText, Printer } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { RawMaterial, FinishedProduct, Production, SalesInvoice, Expense, Customer, Supplier, Purchase } from '@/lib/supabase';
import { PageHeader, formatCurrency, formatNumber, formatDate } from '@/components/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { exportToCSV, exportToExcel, printDocument } from '@/lib/export';
import { toast } from 'sonner';

type ReportType = 'stock' | 'production' | 'sales' | 'purchase' | 'expense' | 'profit_loss' | 'gst' | 'customer' | 'supplier';

const REPORTS: { value: ReportType; label: string; description: string }[] = [
  { value: 'stock', label: 'Stock Report', description: 'Current inventory of raw materials and finished products' },
  { value: 'production', label: 'Production Report', description: 'All production batches with costs' },
  { value: 'sales', label: 'Sales Report', description: 'All invoices with payment status' },
  { value: 'purchase', label: 'Purchase Report', description: 'Raw material purchase history' },
  { value: 'expense', label: 'Expense Report', description: 'All expenses by category' },
  { value: 'profit_loss', label: 'Profit & Loss Report', description: 'Revenue, costs, and net profit' },
  { value: 'gst', label: 'GST Report', description: 'GST collected on sales' },
  { value: 'customer', label: 'Customer Report', description: 'Customer outstanding and purchase history' },
  { value: 'supplier', label: 'Supplier Report', description: 'Supplier details and outstanding payments' },
];

export default function Reports() {
  const [reportType, setReportType] = useState<ReportType>('stock');
  const [data, setData] = useState<any[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const generateReport = async () => {
    setLoading(true);
    let rows: any[] = [];
    let cols: string[] = [];

    switch (reportType) {
      case 'stock': {
        const [mats, prods] = await Promise.all([
          supabase.from('raw_materials').select('*').then((r) => r.data as RawMaterial[]),
          supabase.from('finished_products').select('*').then((r) => r.data as FinishedProduct[]),
        ]);
        cols = ['Type', 'Name', 'Code', 'Unit', 'Current Stock', 'Min Stock', 'Unit Cost', 'Stock Value'];
        rows = [
          ...(mats || []).map((m) => ['Raw Material', m.name, m.code, m.unit, m.current_stock, m.minimum_stock, m.unit_cost, (m.current_stock * m.unit_cost).toFixed(2)]),
          ...(prods || []).map((p) => ['Finished Product', p.name, p.code, p.unit, p.current_stock, p.minimum_stock, p.selling_price, (p.current_stock * p.selling_price).toFixed(2)]),
        ];
        break;
      }
      case 'production': {
        const prods = await supabase.from('productions').select('*, product:finished_products(*)').order('production_date', { ascending: false }).then((r) => r.data as Production[]);
        cols = ['Batch Number', 'Product', 'Quantity', 'Date', 'Operator', 'Total Cost', 'Status'];
        rows = (prods || []).map((p) => [p.batch_number, p.product?.name, p.quantity, p.production_date, p.operator_name, p.total_cost, p.status]);
        break;
      }
      case 'sales': {
        const invs = await supabase.from('sales_invoices').select('*, customer:customers(*), product:finished_products(*)').order('invoice_date', { ascending: false }).then((r) => r.data as SalesInvoice[]);
        cols = ['Invoice #', 'Customer', 'Date', 'Product', 'Qty', 'Rate', 'GST %', 'Subtotal', 'Tax', 'Total', 'Paid', 'Status'];
        rows = (invs || []).map((inv) => [inv.invoice_number, inv.customer?.name, inv.invoice_date, inv.product?.name, inv.quantity, inv.rate, inv.tax_rate, inv.subtotal, inv.tax_amount, inv.total_amount, inv.amount_paid, inv.payment_status]);
        break;
      }
      case 'purchase': {
        const purs = await supabase.from('purchases').select('*, supplier:suppliers(*), material:raw_materials(*)').order('bill_date', { ascending: false }).then((r) => r.data as Purchase[]);
        cols = ['Purchase #', 'Bill #', 'Bill Date', 'Supplier', 'Material', 'Qty', 'Unit Cost', 'Bill Amount', 'Paid', 'Outstanding', 'Status'];
        rows = (purs || []).map((p) => [
          p.purchase_number, p.bill_number, p.bill_date, p.supplier?.name,
          p.material?.name, p.quantity, p.unit_cost, p.bill_amount,
          p.amount_paid, (Number(p.bill_amount) - Number(p.amount_paid)).toFixed(2), p.payment_status,
        ]);
        break;
      }
      case 'expense': {
        const exps = await supabase.from('expenses').select('*').order('expense_date', { ascending: false }).then((r) => r.data as Expense[]);
        cols = ['Date', 'Category', 'Vendor', 'Amount', 'Notes'];
        rows = (exps || []).map((e) => [e.expense_date, e.category, e.vendor, e.amount, e.notes]);
        break;
      }
      case 'profit_loss': {
        const [invs, exps, prods] = await Promise.all([
          supabase.from('sales_invoices').select('*').then((r) => r.data as SalesInvoice[]),
          supabase.from('expenses').select('*').then((r) => r.data as Expense[]),
          supabase.from('productions').select('*').then((r) => r.data as Production[]),
        ]);
        const totalSales = (invs || []).reduce((s, i) => s + Number(i.total_amount), 0);
        const totalProdCost = (prods || []).reduce((s, p) => s + Number(p.total_cost), 0);
        const totalExp = (exps || []).reduce((s, e) => s + Number(e.amount), 0);
        const gross = totalSales - totalProdCost;
        const net = gross - totalExp;
        cols = ['Metric', 'Amount'];
        rows = [
          ['Total Sales', totalSales.toFixed(2)],
          ['Production Cost', totalProdCost.toFixed(2)],
          ['Gross Profit', gross.toFixed(2)],
          ['Operating Expenses', totalExp.toFixed(2)],
          ['Net Profit', net.toFixed(2)],
          ['Profit Margin %', totalSales > 0 ? ((net / totalSales) * 100).toFixed(2) : '0'],
        ];
        break;
      }
      case 'gst': {
        const invs = await supabase.from('sales_invoices').select('*, customer:customers(*)').order('invoice_date', { ascending: false }).then((r) => r.data as SalesInvoice[]);
        cols = ['Invoice #', 'Customer', 'Date', 'GST %', 'Subtotal', 'GST Amount', 'Total'];
        rows = (invs || []).map((inv) => [inv.invoice_number, inv.customer?.name, inv.invoice_date, inv.tax_rate, inv.subtotal, inv.tax_amount, inv.total_amount]);
        break;
      }
      case 'customer': {
        const custs = await supabase.from('customers').select('*').order('name').then((r) => r.data as Customer[]);
        cols = ['Name', 'Company', 'Mobile', 'Email', 'GST', 'Outstanding'];
        rows = (custs || []).map((c) => [c.name, c.company, c.mobile, c.email, c.gst_number, c.outstanding_balance]);
        break;
      }
      case 'supplier': {
        const sups = await supabase.from('suppliers').select('*').order('name').then((r) => r.data as Supplier[]);
        cols = ['Name', 'Company', 'Contact', 'GST', 'Material', 'Outstanding'];
        rows = (sups || []).map((s) => [s.name, s.company, s.contact, s.gst_number, s.material_supplied, s.outstanding_payment]);
        break;
      }
    }

    setHeaders(cols);
    setData(rows);
    setLoading(false);
  };

  useEffect(() => {
    generateReport();
  }, [reportType]);

  const handleExport = (format: 'csv' | 'excel') => {
    const filename = `${reportType}-report`;
    if (format === 'csv') exportToCSV(filename, headers, data);
    else exportToExcel(filename, headers, data);
    toast.success('Exported successfully');
  };

  const handlePrint = () => {
    const reportInfo = REPORTS.find((r) => r.value === reportType);
    const tableHtml = `
      <div class="header">
        <div>
          <div class="company-name">ConcreteFlow ERP</div>
          <p style="font-size:13px;color:#666;">Concrete Mixing Plant Manufacturer</p>
        </div>
        <div class="meta">
          <h1>${reportInfo?.label}</h1>
          <p>Generated: ${new Date().toLocaleString('en-IN')}</p>
        </div>
      </div>
      <table>
        <thead>
          <tr>${headers.map((h) => `<th>${h}</th>`).join('')}</tr>
        </thead>
        <tbody>
          ${data.map((row) => `<tr>${row.map((c: any) => `<td>${c ?? ''}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>
      <p style="margin-top:16px;font-size:13px;color:#666;">Total Records: ${data.length}</p>
    `;
    printDocument(`${reportInfo?.label} - ConcreteFlow ERP`, tableHtml);
  };

  const currentReport = REPORTS.find((r) => r.value === reportType);

  return (
    <div className="space-y-6">
      <PageHeader title="Reports" description="Generate and export business reports">
        <Button variant="outline" size="sm" onClick={handlePrint}>
          <Printer className="h-4 w-4 mr-2" /> Print / PDF
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <FileText className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <FileSpreadsheet className="h-4 w-4 mr-2" /> Excel
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Report selector */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Select Report</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {REPORTS.map((r) => (
              <button
                key={r.value}
                onClick={() => setReportType(r.value)}
                className={`w-full text-left p-3 rounded-lg border transition-colors ${
                  reportType === r.value
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'border-border hover:bg-muted/50'
                }`}
              >
                <div className="font-medium text-sm">{r.label}</div>
                <div className={`text-xs mt-0.5 ${reportType === r.value ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                  {r.description}
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Report data */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-base">{currentReport?.label}</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>
            ) : data.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <FileBarChart className="h-10 w-10 mx-auto mb-3 opacity-50" />
                <p>No data available for this report.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      {headers.map((h) => (
                        <th key={h} className="text-left font-semibold py-2 px-3 text-muted-foreground">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {data.slice(0, 100).map((row, i) => (
                      <tr key={i} className="border-b hover:bg-muted/30">
                        {row.map((cell: any, j: number) => (
                          <td key={j} className="py-2 px-3">{cell ?? '-'}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
                {data.length > 100 && (
                  <p className="text-center text-sm text-muted-foreground mt-4">
                    Showing 100 of {data.length} records. Export to view all.
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
