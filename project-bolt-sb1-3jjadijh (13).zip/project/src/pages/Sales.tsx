import { useEffect, useState, useCallback } from 'react';
import { Plus, ReceiptText, Download, Search, Printer, FileDown, Mail, Pencil } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { SalesInvoice, Customer, FinishedProduct } from '@/lib/supabase';
import { PageHeader, EmptyState, formatCurrency, formatNumber, formatDate } from '@/components/shared';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { exportToCSV, exportToExcel, printDocument } from '@/lib/export';
import { triggerNotification } from '@/lib/notify';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/use-auth';

export default function Sales() {
  const { profile } = useAuth();
  const [invoices, setInvoices] = useState<SalesInvoice[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<FinishedProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<SalesInvoice | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [viewInvoice, setViewInvoice] = useState<SalesInvoice | null>(null);

  const [form, setForm] = useState({
    customer_id: '',
    product_id: '',
    quantity: 0,
    rate: 0,
    tax_rate: 18,
    amount_paid: 0,
    invoice_date: new Date().toISOString().split('T')[0],
    notes: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [invs, custs, prods] = await Promise.all([
      supabase.from('sales_invoices').select('*, customer:customers(*), product:finished_products(*)').order('created_at', { ascending: false }).then((r) => r),
      supabase.from('customers').select('*').order('name').then((r) => r),
      supabase.from('finished_products').select('*').order('code').then((r) => r),
    ]);
    setInvoices((invs.data as SalesInvoice[]) || []);
    setCustomers((custs.data as Customer[]) || []);
    setProducts((prods.data as FinishedProduct[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openAdd = () => {
    setEditing(null);
    setForm({
      customer_id: '', product_id: '', quantity: 0, rate: 0, tax_rate: 18,
      amount_paid: 0, invoice_date: new Date().toISOString().split('T')[0], notes: '',
    });
    setDialogOpen(true);
  };

  const openEdit = (inv: SalesInvoice) => {
    setEditing(inv);
    setForm({
      customer_id: inv.customer_id, product_id: inv.product_id,
      quantity: inv.quantity, rate: Number(inv.rate), tax_rate: Number(inv.tax_rate),
      amount_paid: Number(inv.amount_paid), invoice_date: inv.invoice_date, notes: inv.notes,
    });
    setDialogOpen(true);
  };

  const subtotal = form.quantity * form.rate;
  const taxAmount = (subtotal * form.tax_rate) / 100;
  const totalAmount = subtotal + taxAmount;
  const paymentStatus = form.amount_paid >= totalAmount ? 'paid' : form.amount_paid > 0 ? 'partial' : 'unpaid';

  const handleSave = async () => {
    if (!form.customer_id || !form.product_id || form.quantity <= 0) {
      toast.error('Customer, product, and quantity are required');
      return;
    }

    const payload = {
      customer_id: form.customer_id,
      product_id: form.product_id,
      quantity: Number(form.quantity),
      rate: Number(form.rate),
      tax_rate: Number(form.tax_rate),
      subtotal: Number(subtotal.toFixed(2)),
      tax_amount: Number(taxAmount.toFixed(2)),
      total_amount: Number(totalAmount.toFixed(2)),
      amount_paid: Number(form.amount_paid),
      payment_status: paymentStatus,
      invoice_date: form.invoice_date,
      notes: form.notes,
    };

    if (editing) {
      const { error } = await supabase.from('sales_invoices').update(payload).eq('id', editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success('Invoice updated');
    } else {
      // Generate invoice number
      const { data: numData } = await supabase.rpc('next_invoice_number');
      const invoiceNumber = numData as string;
      const { data: invoiceData, error } = await supabase.from('sales_invoices').insert({ ...payload, invoice_number: invoiceNumber }).select('id').maybeSingle();
      if (error || !invoiceData) { toast.error('Could not create the invoice'); return; }

      const { data: challanNumber } = await supabase.rpc('next_challan_number');
      const { error: challanError } = await supabase.from('delivery_challans').insert({
        invoice_id: invoiceData.id,
        challan_number: challanNumber as string,
        challan_date: form.invoice_date,
        customer_id: form.customer_id,
        client_name: customers.find((customer) => customer.id === form.customer_id)?.name || '',
        gst_number: customers.find((customer) => customer.id === form.customer_id)?.gst_number || '',
        quantity: Number(form.quantity),
        total_cmt: Number(form.quantity),
      });
      if (challanError) { toast.error('Invoice created, but the delivery challan could not be created'); return; }

      // Deduct finished product stock
      const product = products.find((p) => p.id === form.product_id);
      if (product) {
        const newStock = product.current_stock - Number(form.quantity);
        if (newStock < 0) {
          toast.warning('Warning: Product stock is now negative');
        }
        await supabase.from('finished_products').update({ current_stock: newStock, updated_at: new Date().toISOString() }).eq('id', form.product_id);
        await supabase.from('finished_product_movements').insert({
          product_id: form.product_id,
          movement_type: 'sales',
          quantity_change: -Number(form.quantity),
          balance_after: newStock,
          reference: invoiceNumber,
          notes: 'Sold via invoice',
        });
      }

      // Update customer outstanding balance
      const outstanding = totalAmount - Number(form.amount_paid);
      if (outstanding > 0) {
        const customer = customers.find((c) => c.id === form.customer_id);
        if (customer) {
          await supabase.from('customers').update({
            outstanding_balance: Number(customer.outstanding_balance) + outstanding,
          }).eq('id', form.customer_id);
        }
      }

      // Log activity
      await supabase.from('activity_logs').insert({
        user_email: profile?.email || '',
        action: 'invoice_created',
        entity: 'sales_invoice',
        details: `Invoice ${invoiceNumber} - ${formatCurrency(totalAmount)}`,
      });

      toast.success(`Invoice ${invoiceNumber} created`);

      if (paymentStatus !== 'paid') {
        triggerNotification(
          'pending_payment',
          'New Unpaid Invoice',
          `Invoice ${invoiceNumber} for ${formatCurrency(totalAmount)} was created with ${paymentStatus} payment status. Customer: ${customers.find((c) => c.id === form.customer_id)?.name || 'Unknown'}.`,
        );
      }
    }
    setDialogOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('sales_invoices').delete().eq('id', deleteId);
    if (error) { toast.error(error.message); return; }
    toast.success('Invoice deleted');
    setDeleteId(null);
    fetchData();
  };

  const handleExport = (format: 'csv' | 'excel') => {
    const headers = ['Invoice #', 'Customer', 'Date', 'Product', 'Qty', 'Rate', 'Tax', 'Total', 'Paid', 'Status'];
    const rows = filtered.map((inv) => [
      inv.invoice_number, inv.customer?.name || '', inv.invoice_date, inv.product?.name || '',
      inv.quantity, inv.rate, inv.tax_rate, inv.total_amount, inv.amount_paid, inv.payment_status,
    ]);
    if (format === 'csv') exportToCSV('sales-invoices', headers, rows);
    else exportToExcel('sales-invoices', headers, rows);
    toast.success('Exported successfully');
  };

  const printInvoice = (inv: SalesInvoice) => {
    const html = `
      <div class="header">
        <div>
          <div class="company-name">ConcreteFlow ERP</div>
          <p style="font-size:13px;color:#666;">Concrete Mixing Plant Manufacturer</p>
          <p style="font-size:13px;color:#666;">GST: 27AABCC1234D1Z9</p>
        </div>
        <div class="meta">
          <h1>INVOICE</h1>
          <p><strong>${inv.invoice_number}</strong></p>
          <p>Date: ${formatDate(inv.invoice_date)}</p>
          <p>Status: <span class="badge" style="background:${inv.payment_status === 'paid' ? '#dcfce7' : inv.payment_status === 'partial' ? '#fef9c3' : '#fee2e2'};color:${inv.payment_status === 'paid' ? '#166534' : inv.payment_status === 'partial' ? '#854d0e' : '#991b1b'};">${inv.payment_status.toUpperCase()}</span></p>
        </div>
      </div>
      <div style="margin-bottom:24px;">
        <h2 style="font-size:14px;color:#999;margin-bottom:4px;">Bill To:</h2>
        <p style="font-size:15px;font-weight:bold;">${inv.customer?.name || ''}</p>
        <p style="font-size:13px;color:#555;">${inv.customer?.company || ''}</p>
        <p style="font-size:13px;color:#555;">${inv.customer?.address || ''}</p>
        <p style="font-size:13px;color:#555;">GST: ${inv.customer?.gst_number || 'N/A'}</p>
        <p style="font-size:13px;color:#555;">${inv.customer?.mobile || ''} ${inv.customer?.email || ''}</p>
      </div>
      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Rate</th>
            <th style="text-align:right;">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>${inv.product?.name || ''}</td>
            <td>${formatNumber(inv.quantity, 1)} ${inv.product?.unit || ''}</td>
            <td>${formatCurrency(Number(inv.rate))}</td>
            <td style="text-align:right;">${formatCurrency(Number(inv.subtotal))}</td>
          </tr>
        </tbody>
      </table>
      <table class="totals">
        <tr><td>Subtotal:</td><td style="text-align:right;">${formatCurrency(Number(inv.subtotal))}</td></tr>
        <tr><td>GST (${inv.tax_rate}%):</td><td style="text-align:right;">${formatCurrency(Number(inv.tax_amount))}</td></tr>
        <tr class="grand"><td>Total:</td><td style="text-align:right;">${formatCurrency(Number(inv.total_amount))}</td></tr>
        <tr><td>Amount Paid:</td><td style="text-align:right;">${formatCurrency(Number(inv.amount_paid))}</td></tr>
        <tr class="grand"><td>Balance Due:</td><td style="text-align:right;">${formatCurrency(Number(inv.total_amount) - Number(inv.amount_paid))}</td></tr>
      </table>
      ${inv.notes ? `<p style="margin-top:24px;font-size:13px;color:#666;"><strong>Notes:</strong> ${inv.notes}</p>` : ''}
    `;
    printDocument(`Invoice ${inv.invoice_number}`, html);
  };

  const filtered = invoices.filter((inv) =>
    inv.invoice_number.toLowerCase().includes(search.toLowerCase()) ||
    (inv.customer?.name || '').toLowerCase().includes(search.toLowerCase()) ||
    inv.payment_status.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="animate-shimmer h-8 w-8 rounded-full" /></div>;
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Sales & Invoices" description="Generate GST-compliant invoices and track payments">
        <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
          <Download className="h-4 w-4 mr-2" /> CSV
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
          <Download className="h-4 w-4 mr-2" /> Excel
        </Button>
        <Button onClick={openAdd} disabled={customers.length === 0 || products.length === 0}>
          <Plus className="h-4 w-4 mr-2" /> New Invoice
        </Button>
      </PageHeader>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search invoices..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<ReceiptText className="h-6 w-6" />}
              title="No invoices found"
              description={customers.length === 0 ? 'Add customers first, then create invoices.' : 'Create your first invoice to start tracking sales.'}
              action={customers.length > 0 && products.length > 0 ? <Button onClick={openAdd}><Plus className="h-4 w-4 mr-2" /> New Invoice</Button> : undefined}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice #</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Paid</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((inv) => (
                    <TableRow key={inv.id}>
                      <TableCell className="font-mono text-sm">{inv.invoice_number}</TableCell>
                      <TableCell className="font-medium">{inv.customer?.name || '-'}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(inv.invoice_date)}</TableCell>
                      <TableCell>{inv.product?.name || '-'}</TableCell>
                      <TableCell className="text-right">{formatNumber(inv.quantity, 1)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(Number(inv.total_amount))}</TableCell>
                      <TableCell className="text-right">{formatCurrency(Number(inv.amount_paid))}</TableCell>
                      <TableCell>
                        <Badge variant={inv.payment_status === 'paid' ? 'default' : inv.payment_status === 'partial' ? 'secondary' : 'destructive'}>
                          {inv.payment_status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" title="View & Print" onClick={() => setViewInvoice(inv)}>
                            <Printer className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Edit" onClick={() => openEdit(inv)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Delete" onClick={() => setDeleteId(inv.id)}>
                            <FileDown className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Invoice' : 'New Invoice'}</DialogTitle>
            <DialogDescription>
              {editing ? 'Update invoice details.' : 'Create a new sales invoice. Finished product stock will be deducted automatically.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Customer</Label>
              <Select value={form.customer_id} onValueChange={(v) => setForm({ ...form, customer_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                <SelectContent>
                  {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.name} - {c.company}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Product</Label>
              <Select
                value={form.product_id}
                onValueChange={(v) => {
                  const p = products.find((p) => p.id === v);
                  setForm({ ...form, product_id: v, rate: p ? Number(p.selling_price) : form.rate });
                }}
              >
                <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
                <SelectContent>
                  {products.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.code} - {p.name} (Stock: {formatNumber(p.current_stock, 1)} {p.unit}) - {formatCurrency(p.selling_price)}/{p.unit}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Quantity</Label>
              <Input type="number" step="0.001" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Rate (₹)</Label>
              <Input type="number" step="0.01" value={form.rate} onChange={(e) => setForm({ ...form, rate: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>GST Tax Rate (%)</Label>
              <Input type="number" step="0.01" value={form.tax_rate} onChange={(e) => setForm({ ...form, tax_rate: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>Amount Paid (₹)</Label>
              <Input type="number" step="0.01" value={form.amount_paid} onChange={(e) => setForm({ ...form, amount_paid: Number(e.target.value) })} />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Invoice Date</Label>
              <Input type="date" value={form.invoice_date} onChange={(e) => setForm({ ...form, invoice_date: e.target.value })} />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Notes</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes" />
            </div>
          </div>

          {/* Summary */}
          <div className="rounded-lg bg-muted/50 p-4 space-y-2 text-sm">
            <div className="flex justify-between"><span>Subtotal:</span><span className="font-medium">{formatCurrency(subtotal)}</span></div>
            <div className="flex justify-between"><span>GST ({form.tax_rate}%):</span><span className="font-medium">{formatCurrency(taxAmount)}</span></div>
            <div className="flex justify-between font-bold text-base border-t border-border pt-2"><span>Total:</span><span>{formatCurrency(totalAmount)}</span></div>
            <div className="flex justify-between"><span>Payment Status:</span>
              <Badge variant={paymentStatus === 'paid' ? 'default' : paymentStatus === 'partial' ? 'secondary' : 'destructive'}>{paymentStatus}</Badge>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Create'} Invoice</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View/Print Dialog */}
      <Dialog open={!!viewInvoice} onOpenChange={(o) => !o && setViewInvoice(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Invoice {viewInvoice?.invoice_number}</DialogTitle>
            <DialogDescription>Review and print this invoice</DialogDescription>
          </DialogHeader>
          {viewInvoice && (
            <div className="space-y-4">
              <div className="flex justify-between border-b pb-4">
                <div>
                  <h3 className="font-display font-bold text-primary">ConcreteFlow ERP</h3>
                  <p className="text-sm text-muted-foreground">Concrete Mixing Plant Manufacturer</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">INVOICE</p>
                  <p className="text-sm text-muted-foreground">{viewInvoice.invoice_number}</p>
                  <p className="text-sm text-muted-foreground">{formatDate(viewInvoice.invoice_date)}</p>
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Bill To:</p>
                <p className="font-medium">{viewInvoice.customer?.name}</p>
                <p className="text-sm text-muted-foreground">{viewInvoice.customer?.company}</p>
                <p className="text-sm text-muted-foreground">GST: {viewInvoice.customer?.gst_number || 'N/A'}</p>
              </div>
              <div className="rounded-lg border p-3">
                <div className="flex justify-between text-sm py-1"><span>Product:</span><span className="font-medium">{viewInvoice.product?.name}</span></div>
                <div className="flex justify-between text-sm py-1"><span>Quantity:</span><span className="font-medium">{formatNumber(viewInvoice.quantity, 1)} {viewInvoice.product?.unit}</span></div>
                <div className="flex justify-between text-sm py-1"><span>Rate:</span><span className="font-medium">{formatCurrency(Number(viewInvoice.rate))}</span></div>
                <div className="flex justify-between text-sm py-1"><span>Subtotal:</span><span className="font-medium">{formatCurrency(Number(viewInvoice.subtotal))}</span></div>
                <div className="flex justify-between text-sm py-1"><span>GST ({viewInvoice.tax_rate}%):</span><span className="font-medium">{formatCurrency(Number(viewInvoice.tax_amount))}</span></div>
                <div className="flex justify-between font-bold border-t mt-1 pt-1"><span>Total:</span><span>{formatCurrency(Number(viewInvoice.total_amount))}</span></div>
                <div className="flex justify-between text-sm py-1"><span>Paid:</span><span className="font-medium text-success">{formatCurrency(Number(viewInvoice.amount_paid))}</span></div>
                <div className="flex justify-between text-sm py-1"><span>Balance:</span><span className="font-medium text-destructive">{formatCurrency(Number(viewInvoice.total_amount) - Number(viewInvoice.amount_paid))}</span></div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewInvoice(null)}>Close</Button>
            <Button variant="outline" onClick={() => viewInvoice && printInvoice(viewInvoice)}>
              <Mail className="h-4 w-4 mr-2" /> Email
            </Button>
            <Button onClick={() => viewInvoice && printInvoice(viewInvoice)}>
              <Printer className="h-4 w-4 mr-2" /> Print / PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Invoice?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the invoice. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
