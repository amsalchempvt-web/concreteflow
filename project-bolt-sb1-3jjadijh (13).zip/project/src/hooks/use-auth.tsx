import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, type Profile, type UserRole, type UserPermission, type Company, type ModuleKey } from '@/lib/supabase';
import { NAV_ITEMS } from '@/lib/navigation';

interface AuthContextValue {
  session: Session | null;
  profile: Profile | null;
  permissions: UserPermission[];
  company: Company | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, fullName: string, role: UserRole, companyName?: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  hasModuleAccess: (moduleKey: ModuleKey) => boolean;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [permissions, setPermissions] = useState<UserPermission[]>([]);
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (!data.session) setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      if (!newSession) {
        setProfile(null);
        setPermissions([]);
        setCompany(null);
        setLoading(false);
      }
    });

    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!session) {
      setProfile(null);
      setPermissions([]);
      setCompany(null);
      return;
    }
    setLoading(true);
    (async () => {
      const { data: profileData, error } = await supabase
        .from('profiles')
        .select('*, company:companies(*)')
        .eq('id', session.user.id)
        .maybeSingle();
      if (error) {
        console.error('Profile fetch error:', error.message);
      }
      const p = profileData as Profile | null;
      setProfile(p);

      if (p) {
        const { data: permData } = await supabase
          .from('user_permissions')
          .select('*')
          .eq('user_id', session.user.id);
        setPermissions((permData as UserPermission[]) || []);

        if (p.company) {
          setCompany(p.company as Company);
        } else {
          setCompany(null);
        }
      }
      setLoading(false);
    })();
  }, [session]);

  const hasModuleAccess = (moduleKey: ModuleKey): boolean => {
    if (!profile) return false;
    // Admin always has access to everything
    if (profile.role === 'admin' || profile.role === 'super_admin') return true;

    // Check if there's a custom permission override
    const perm = permissions.find((p) => p.module === moduleKey);
    if (perm) return perm.allowed;

    // Fall back to role-based default from NAV_ITEMS
    const navItem = NAV_ITEMS.find((n) => n.moduleKey === moduleKey && n.path !== '/delivery-challans');
    if (navItem) return navItem.roles.includes(profile.role);

    return false;
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error ? error.message : null };
  };

  const signUp = async (email: string, password: string, fullName: string, role: UserRole, companyName?: string) => {
    const metadata: Record<string, string> = { full_name: fullName, role };
    if (companyName) metadata.company_name = companyName;
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: metadata },
    });
    return { error: error ? error.message : null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setPermissions([]);
    setCompany(null);
  };

  return (
    <AuthContext.Provider value={{ session, profile, permissions, company, loading, signIn, signUp, signOut, hasModuleAccess }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
