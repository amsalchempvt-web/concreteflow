import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { RawMaterial } from '@/lib/supabase';

export interface Alert {
  id: string;
  type: 'low_stock' | 'pending_payment' | 'outstanding_balance' | 'failed_production';
  title: string;
  message: string;
  severity: 'warning' | 'error' | 'info';
}

export function useNotifications() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const newAlerts: Alert[] = [];

    // Low stock alerts
    const { data: materials } = await supabase
      .from('raw_materials')
      .select('*');

    if (materials) {
      for (const m of (materials as RawMaterial[])) {
        if (m.current_stock <= m.minimum_stock) {
          newAlerts.push({
            id: `low-${m.id}`,
            type: 'low_stock',
            title: 'Low Raw Material Stock',
            message: `${m.name} is below minimum level (${m.current_stock} ${m.unit} left, min: ${m.minimum_stock} ${m.unit})`,
            severity: m.current_stock <= 0 ? 'error' : 'warning',
          });
        }
      }
    }

    // Pending payments (unpaid invoices)
    const { count: unpaidCount } = await supabase
      .from('sales_invoices')
      .select('*', { count: 'exact', head: true })
      .in('payment_status', ['unpaid', 'partial']);

    if (unpaidCount && unpaidCount > 0) {
      newAlerts.push({
        id: 'pending-payments',
        type: 'pending_payment',
        title: 'Pending Payments',
        message: `${unpaidCount} invoice(s) have pending or partial payments.`,
        severity: 'warning',
      });
    }

    // Outstanding customer balances
    const { data: customers } = await supabase
      .from('customers')
      .select('name, outstanding_balance')
      .gt('outstanding_balance', 0);

    if (customers) {
      for (const c of customers) {
        newAlerts.push({
          id: `outstanding-${c.name}`,
          type: 'outstanding_balance',
          title: 'Outstanding Customer Balance',
          message: `${c.name} has an outstanding balance of ₹${Number(c.outstanding_balance).toLocaleString('en-IN')}`,
          severity: 'info',
        });
      }
    }

    // Failed productions
    const { count: failedCount } = await supabase
      .from('productions')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'failed');

    if (failedCount && failedCount > 0) {
      newAlerts.push({
        id: 'failed-production',
        type: 'failed_production',
        title: 'Failed Production',
        message: `${failedCount} production batch(es) failed due to insufficient stock.`,
        severity: 'error',
      });
    }

    setAlerts(newAlerts);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { alerts, loading, refresh };
}
