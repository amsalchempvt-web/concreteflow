/*
# Fix RLS policies for pending user approval flow

## Problem
The current profiles SELECT policy uses `company_id = get_user_company_id()`.
When a new user signs up without a company (pending approval), their company_id is NULL.
`NULL = NULL` evaluates to false in SQL, so:
1. The pending user cannot read their own profile row — the frontend sees profile=null
   and the "pending approval" screen never shows; the user falls through to the dashboard.
2. The admin cannot see pending users in User Management, because their company_id (NULL)
   doesn't match the admin's company_id.

## Fix
Update the profiles SELECT policy to allow:
- A user to always read their own row (by auth.uid() = id), regardless of company_id.
- An admin to read all profiles in their company AND pending users (company_id IS NULL).

Also update the UPDATE policy so an admin can approve pending users by setting their
company_id and role — the current USING clause references `profiles.company_id` which
fails for NULL rows.

## Changes
- profiles SELECT policy: own row OR (admin AND same company) OR (admin AND pending NULL)
- profiles UPDATE policy: own row OR (admin AND same company) OR (admin AND target pending)
*/

-- Fix SELECT policy on profiles
DROP POLICY IF EXISTS "auth_select_profiles" ON profiles;
CREATE POLICY "auth_select_profiles" ON profiles FOR SELECT TO authenticated
  USING (
    id = auth.uid()
    OR (
      EXISTS (
        SELECT 1 FROM profiles p
        WHERE p.id = auth.uid() AND p.role = 'admin'
      )
      AND (
        company_id = public.get_user_company_id()
        OR company_id IS NULL
      )
    )
  );

-- Fix UPDATE policy on profiles so admin can approve pending (NULL company_id) users
DROP POLICY IF EXISTS "auth_update_profiles" ON profiles;
CREATE POLICY "auth_update_profiles" ON profiles FOR UPDATE TO authenticated
  USING (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  )
  WITH CHECK (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );
