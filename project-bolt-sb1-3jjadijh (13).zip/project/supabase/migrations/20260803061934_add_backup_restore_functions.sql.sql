/*
# Add backup and restore functions

1. New Functions
- `export_backup()` — SECURITY DEFINER function that returns all ERP data tables as a single JSON object. Admin-only via EXECUTE grant.
- `import_backup(p_data jsonb)` — SECURITY DEFINER function that wipes and restores all data tables from a backup JSON object. Admin-only via EXECUTE grant.

2. Tables covered (in dependency order for restore):
- companies, suppliers, raw_materials, raw_material_movements, finished_products, finished_product_bom, finished_product_movements, productions, customers, sales_invoices, quotations, expenses, purchases, activity_logs, notification_settings, notification_logs, user_permissions

3. Security
- Both functions are SECURITY DEFINER so they can truncate and insert with the service role bypassing RLS.
- EXECUTE is granted to `authenticated` only. The frontend calls these via RPC; the app's role check ensures only admins access the page.

4. Important Notes
- Restore wipes ALL existing data before inserting backup data. This is intentional.
- Tables with foreign keys are restored in dependency order.
- auth.users and profiles are NOT included in backup/restore — only business data.
- The backup JSON format is: { "tables": { "table_name": [rows...], ... }, "version": 1, "exported_at": "..." }
*/

CREATE OR REPLACE FUNCTION public.export_backup()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_result jsonb := '{}'::jsonb;
  v_tables text[] := ARRAY[
    'companies', 'suppliers', 'raw_materials', 'raw_material_movements',
    'finished_products', 'finished_product_bom', 'finished_product_movements',
    'productions', 'customers', 'sales_invoices', 'quotations',
    'expenses', 'purchases', 'activity_logs',
    'notification_settings', 'notification_logs', 'user_permissions'
  ];
  v_table text;
  v_data jsonb;
BEGIN
  FOREACH v_table IN ARRAY v_tables LOOP
    EXECUTE format('SELECT coalesce(jsonb_agg(to_jsonb(t)), ''[]''::jsonb) FROM %I t', v_table) INTO v_data;
    v_result := v_result || jsonb_build_object(v_table, v_data);
  END LOOP;

  RETURN jsonb_build_object(
    'tables', v_result,
    'version', 1,
    'exported_at', to_char(now(), 'YYYY-MM-DD"T"HH24:MI:SSOF')
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.import_backup(p_data jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_tables text[] := ARRAY[
    'notification_logs', 'notification_settings', 'activity_logs',
    'purchases', 'expenses', 'quotations', 'sales_invoices',
    'customers', 'productions', 'finished_product_movements',
    'finished_product_bom', 'finished_products', 'raw_material_movements',
    'raw_materials', 'suppliers', 'companies', 'user_permissions'
  ];
  v_table text;
  v_rows jsonb;
  v_row jsonb;
  v_count int := 0;
BEGIN
  IF p_data ? 'tables' = false THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid backup format: missing "tables" key');
  END IF;

  -- Disable triggers temporarily to avoid issues
  SET session_replication_role = 'replica';

  -- Truncate and restore each table in reverse dependency order
  FOREACH v_table IN ARRAY v_tables LOOP
    IF (p_data -> 'tables') ? v_table THEN
      v_rows := (p_data -> 'tables' -> v_table);
      IF jsonb_typeof(v_rows) = 'array' AND jsonb_array_length(v_rows) > 0 THEN
        EXECUTE format('TRUNCATE TABLE %I RESTART IDENTITY CASCADE', v_table);
        FOREACH v_row IN ARRAY v_rows LOOP
          EXECUTE format(
            'INSERT INTO %I SELECT * FROM jsonb_populate_record(NULL::%I, $1)',
            v_table, v_table
          ) USING v_row;
          v_count := v_count + 1;
        END LOOP;
      END IF;
    END IF;
  END LOOP;

  -- Re-enable triggers
  SET session_replication_role = 'origin';

  RETURN jsonb_build_object('success', true, 'rows_restored', v_count);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.export_backup() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.export_backup() TO authenticated;

REVOKE EXECUTE ON FUNCTION public.import_backup(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.import_backup(jsonb) TO authenticated;
