-- Enforce admin uniqueness and first-user-is-admin rule at the database level
-- Demote duplicate admin to plant_operator before adding unique constraint

-- Demote the second admin (a@b.com) to plant_operator
UPDATE public.profiles
SET role = 'plant_operator'
WHERE id = '609628b8-52fc-48e8-92fc-231760656100';

-- Update the trigger function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_user_count int;
  v_assigned_role text;
BEGIN
  SELECT COUNT(*) INTO v_user_count FROM public.profiles;

  IF v_user_count = 0 THEN
    v_assigned_role := 'admin';
  ELSE
    v_assigned_role := 'plant_operator';
  END IF;

  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    v_assigned_role
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;

-- Ensure only one admin can exist
CREATE UNIQUE INDEX IF NOT EXISTS profiles_only_one_admin
ON public.profiles ((1))
WHERE role = 'admin';

-- Prevent non-admins from changing their own role via the profiles table
-- (admin role changes must go through the admin-create-user edge function)
DROP POLICY IF EXISTS "auth_update_profiles" ON profiles;
CREATE POLICY "auth_update_profiles" ON profiles
  FOR UPDATE TO authenticated
  USING (
    id = auth.uid()
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  )
  WITH CHECK (
    -- Users can update their own name, but only admin can change role/company
    id = auth.uid()
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );
