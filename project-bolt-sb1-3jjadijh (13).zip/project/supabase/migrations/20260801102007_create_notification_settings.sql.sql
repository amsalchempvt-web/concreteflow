/*
# Create notification settings and logs tables

1. New Tables
- `notification_settings`: Stores email and WhatsApp notification configuration (SMTP credentials, WhatsApp API token, enabled flags, per-event toggles).
- `notification_logs`: Records every notification dispatched (type, channel, recipient, status, error message).

2. Columns — notification_settings
- `id` (uuid, primary key)
- `email_enabled` (boolean, default false) — master toggle for email notifications
- `smtp_host` (text) — SMTP server hostname
- `smtp_port` (int, default 587) — SMTP server port
- `smtp_username` (text) — SMTP auth username
- `smtp_password` (text) — SMTP auth password (stored as plaintext for edge function use)
- `smtp_from` (text) — From email address
- `whatsapp_enabled` (boolean, default false) — master toggle for WhatsApp notifications
- `whatsapp_phone_number_id` (text) — WhatsApp Cloud API phone number ID
- `whatsapp_access_token` (text) — WhatsApp Cloud API access token
- `whatsapp_recipient_phone` (text) — Default recipient phone number for alerts
- `alert_low_stock` (boolean, default true) — notify when raw material falls below minimum
- `alert_pending_payments` (boolean, default true) — notify when invoices are unpaid
- `alert_outstanding_balance` (boolean, default true) — notify when customers have outstanding balances
- `alert_failed_production` (boolean, default true) — notify when production batches fail
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

3. Columns — notification_logs
- `id` (uuid, primary key)
- `channel` (text) — 'email' or 'whatsapp'
- `alert_type` (text) — e.g. 'low_stock', 'pending_payment'
- `recipient` (text) — email address or phone number
- `subject` (text) — subject line (email only)
- `message` (text) — notification body
- `status` (text) — 'sent', 'failed'
- `error` (text, nullable) — error message if failed
- `created_at` (timestamptz)

4. Security
- Enable RLS on both tables.
- Admin-only access (TO authenticated) since notification config contains credentials.

5. Notes
- Only one row in notification_settings is expected (singleton). The app upserts the row with a fixed id.
*/

CREATE TABLE IF NOT EXISTS notification_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email_enabled boolean NOT NULL DEFAULT false,
  smtp_host text DEFAULT '',
  smtp_port int NOT NULL DEFAULT 587,
  smtp_username text DEFAULT '',
  smtp_password text DEFAULT '',
  smtp_from text DEFAULT '',
  whatsapp_enabled boolean NOT NULL DEFAULT false,
  whatsapp_phone_number_id text DEFAULT '',
  whatsapp_access_token text DEFAULT '',
  whatsapp_recipient_phone text DEFAULT '',
  alert_low_stock boolean NOT NULL DEFAULT true,
  alert_pending_payments boolean NOT NULL DEFAULT true,
  alert_outstanding_balance boolean NOT NULL DEFAULT true,
  alert_failed_production boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE notification_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_notification_settings" ON notification_settings;
CREATE POLICY "select_notification_settings" ON notification_settings
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_notification_settings" ON notification_settings;
CREATE POLICY "insert_notification_settings" ON notification_settings
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_notification_settings" ON notification_settings;
CREATE POLICY "update_notification_settings" ON notification_settings
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_notification_settings" ON notification_settings;
CREATE POLICY "delete_notification_settings" ON notification_settings
  FOR DELETE TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS notification_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel text NOT NULL,
  alert_type text NOT NULL,
  recipient text NOT NULL,
  subject text,
  message text NOT NULL,
  status text NOT NULL,
  error text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notification_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_notification_logs" ON notification_logs;
CREATE POLICY "select_notification_logs" ON notification_logs
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_notification_logs" ON notification_logs;
CREATE POLICY "insert_notification_logs" ON notification_logs
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "delete_notification_logs" ON notification_logs;
CREATE POLICY "delete_notification_logs" ON notification_logs
  FOR DELETE TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_notification_logs_created_at ON notification_logs (created_at DESC);
