-- Fix import_backup: truncate ALL tables first, then insert all data
-- (previous version cascaded truncates into already-restored tables, wiping them)
CREATE OR REPLACE FUNCTION public.import_backup(p_data jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_tables text[] := ARRAY[
    'notification_logs', 'notification_settings', 'activity_logs',
    'purchases', 'expenses', 'quotations', 'sales_invoices',
    'customers', 'productions', 'finished_product_movements',
    'finished_product_bom', 'finished_products', 'raw_material_movements',
    'raw_materials', 'suppliers', 'companies', 'user_permissions'
  ];
  v_table text;
  v_rows jsonb;
  v_row jsonb;
  v_count int := 0;
BEGIN
  IF p_data ? 'tables' = false THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid backup format: missing "tables" key');
  END IF;

  SET session_replication_role = 'replica';

  -- Phase 1: truncate ALL tables at once so no cascade wipes already-inserted rows
  FOREACH v_table IN ARRAY v_tables LOOP
    IF (p_data -> 'tables') ? v_table THEN
      v_rows := (p_data -> 'tables' -> v_table);
      IF jsonb_typeof(v_rows) = 'array' AND jsonb_array_length(v_rows) > 0 THEN
        EXECUTE format('TRUNCATE TABLE %I RESTART IDENTITY CASCADE', v_table);
      END IF;
    END IF;
  END LOOP;

  -- Phase 2: insert all data (reverse dependency order so parents exist before children)
  FOREACH v_table IN ARRAY v_tables LOOP
    IF (p_data -> 'tables') ? v_table THEN
      v_rows := (p_data -> 'tables' -> v_table);
      IF jsonb_typeof(v_rows) = 'array' AND jsonb_array_length(v_rows) > 0 THEN
        FOR v_row IN SELECT jsonb_array_elements(v_rows) LOOP
          EXECUTE format(
            'INSERT INTO %I SELECT * FROM jsonb_populate_record(NULL::%I, $1)',
            v_table, v_table
          ) USING v_row;
          v_count := v_count + 1;
        END LOOP;
      END IF;
    END IF;
  END LOOP;

  SET session_replication_role = 'origin';

  RETURN jsonb_build_object('success', true, 'rows_restored', v_count);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.import_backup(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.import_backup(jsonb) TO authenticated;
