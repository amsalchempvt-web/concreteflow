/*
# Fix infinite RLS recursion on profiles table

## Problem
The profiles SELECT/UPDATE/DELETE policies use:
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
This subquery on `profiles` triggers RLS on `profiles`, which evaluates the same
policy, which contains another `EXISTS (SELECT 1 FROM profiles p ...)`, and so on —
infinite recursion. PostgreSQL throws an error, so admins cannot load User Management
or see any profiles besides their own.

## Fix
1. Create `is_user_admin()` — a SECURITY DEFINER function that checks if the current
   authenticated user has role='admin'. Being SECURITY DEFINER, it bypasses RLS and
   avoids the recursion.
2. Rewrite all profiles policies to use `is_user_admin()` instead of the inline
   EXISTS subquery.
3. Keep the same access logic:
   - Users can always read/update/delete their own profile row.
   - Admins can read/update/delete profiles in their own company + pending (NULL company_id) users.
   - INSERT stays company-scoped via get_user_company_id().
*/

CREATE OR REPLACE FUNCTION public.is_user_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT role = 'admin' FROM public.profiles WHERE id = auth.uid();
$$;

-- Re-grant execute to authenticated
REVOKE EXECUTE ON FUNCTION public.is_user_admin() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_user_admin() TO authenticated;

-- Fix SELECT policy
DROP POLICY IF EXISTS "auth_select_profiles" ON profiles;
CREATE POLICY "auth_select_profiles" ON profiles FOR SELECT TO authenticated
  USING (
    id = auth.uid()
    OR (
      public.is_user_admin()
      AND (company_id = public.get_user_company_id() OR company_id IS NULL)
    )
  );

-- Fix UPDATE policy
DROP POLICY IF EXISTS "auth_update_profiles" ON profiles;
CREATE POLICY "auth_update_profiles" ON profiles FOR UPDATE TO authenticated
  USING (
    id = auth.uid()
    OR (
      public.is_user_admin()
      AND (company_id = public.get_user_company_id() OR company_id IS NULL)
    )
  )
  WITH CHECK (
    id = auth.uid()
    OR (
      public.is_user_admin()
      AND (company_id = public.get_user_company_id() OR company_id IS NULL)
    )
  );

-- Fix DELETE policy
DROP POLICY IF EXISTS "auth_delete_profiles" ON profiles;
CREATE POLICY "auth_delete_profiles" ON profiles FOR DELETE TO authenticated
  USING (
    id = auth.uid()
    OR (
      public.is_user_admin()
      AND (company_id = public.get_user_company_id() OR company_id IS NULL)
    )
  );
