-- Auto-set company_id on insert for all company-scoped tables
-- This prevents insert failures since frontend doesn't pass company_id

CREATE OR REPLACE FUNCTION public.set_company_id_on_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_company_id uuid;
BEGIN
  SELECT company_id INTO v_company_id FROM public.profiles WHERE id = auth.uid();
  
  IF v_company_id IS NOT NULL AND (TG_ARGV[0] = 'company_id' OR TG_OP = 'INSERT') THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.company_id IS NULL THEN
        NEW.company_id := v_company_id;
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      -- Prevent cross-company updates
      IF NEW.company_id IS DISTINCT FROM OLD.company_id AND NEW.company_id IS NULL THEN
        NEW.company_id := OLD.company_id;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.set_company_id_on_insert() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.set_company_id_on_insert() FROM anon;
REVOKE EXECUTE ON FUNCTION public.set_company_id_on_insert() FROM authenticated;

-- Attach triggers to all company-scoped tables
DROP TRIGGER IF EXISTS set_company_suppliers ON suppliers;
CREATE TRIGGER set_company_suppliers BEFORE INSERT ON suppliers
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_raw_materials ON raw_materials;
CREATE TRIGGER set_company_raw_materials BEFORE INSERT ON raw_materials
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_rm_movements ON raw_material_movements;
CREATE TRIGGER set_company_rm_movements BEFORE INSERT ON raw_material_movements
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_finished_products ON finished_products;
CREATE TRIGGER set_company_finished_products BEFORE INSERT ON finished_products
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_bom ON finished_product_bom;
CREATE TRIGGER set_company_bom BEFORE INSERT ON finished_product_bom
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_fp_movements ON finished_product_movements;
CREATE TRIGGER set_company_fp_movements BEFORE INSERT ON finished_product_movements
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_productions ON productions;
CREATE TRIGGER set_company_productions BEFORE INSERT ON productions
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_customers ON customers;
CREATE TRIGGER set_company_customers BEFORE INSERT ON customers
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_invoices ON sales_invoices;
CREATE TRIGGER set_company_invoices BEFORE INSERT ON sales_invoices
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_quotations ON quotations;
CREATE TRIGGER set_company_quotations BEFORE INSERT ON quotations
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_expenses ON expenses;
CREATE TRIGGER set_company_expenses BEFORE INSERT ON expenses
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_purchases ON purchases;
CREATE TRIGGER set_company_purchases BEFORE INSERT ON purchases
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_activity_logs ON activity_logs;
CREATE TRIGGER set_company_activity_logs BEFORE INSERT ON activity_logs
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DROP TRIGGER IF EXISTS set_company_notification_settings ON notification_settings;
CREATE TRIGGER set_company_notification_settings BEFORE INSERT ON notification_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notification_logs' AND column_name='company_id') THEN
    DROP TRIGGER IF EXISTS set_company_notification_logs ON notification_logs;
    CREATE TRIGGER set_company_notification_logs BEFORE INSERT ON notification_logs
      FOR EACH ROW EXECUTE FUNCTION public.set_company_id_on_insert();
  END IF;
END $$;
