-- Fix handle_new_user: each signup with company_name creates a new company + admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = 'public'
AS $function$
DECLARE
  v_assigned_role text;
  v_new_company_id uuid;
  v_company_name text;
BEGIN
  v_company_name := NEW.raw_user_meta_data->>'company_name';

  IF v_company_name IS NOT NULL AND v_company_name != '' THEN
    v_assigned_role := COALESCE(NEW.raw_user_meta_data->>'role', 'admin');
    INSERT INTO public.companies (name) VALUES (v_company_name)
    RETURNING id INTO v_new_company_id;
  ELSE
    v_assigned_role := COALESCE(NEW.raw_user_meta_data->>'role', 'plant_operator');
    v_new_company_id := NULL;
  END IF;

  INSERT INTO public.profiles (id, email, full_name, role, company_id)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    v_assigned_role,
    v_new_company_id
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$function$;

-- Replace the global "only one admin" index with per-company uniqueness
DROP INDEX IF EXISTS public.profiles_only_one_admin;
CREATE UNIQUE INDEX profiles_one_admin_per_company
  ON public.profiles (company_id)
  WHERE role = 'admin' AND company_id IS NOT NULL;

-- Fix the existing broken user
DO $$
DECLARE
  v_company_id uuid;
  v_company_name text;
BEGIN
  SELECT raw_user_meta_data->>'company_name' INTO v_company_name
  FROM auth.users WHERE id = '5cc07d6d-47cc-4d95-a5dd-02acfa9717ed';

  IF v_company_name IS NULL OR v_company_name = '' THEN
    v_company_name := 'My Company';
  END IF;

  INSERT INTO public.companies (name) VALUES (v_company_name)
  RETURNING id INTO v_company_id;

  UPDATE public.profiles
  SET role = 'admin', company_id = v_company_id
  WHERE id = '5cc07d6d-47cc-4d95-a5dd-02acfa9717ed';
END $$;
