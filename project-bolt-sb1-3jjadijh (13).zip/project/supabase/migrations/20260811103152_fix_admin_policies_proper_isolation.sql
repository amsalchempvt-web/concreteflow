/*
# Fix admin profile policies with proper company isolation

## Problem
The previous fix (fix_pending_user_rls_policies) made the UPDATE policy too permissive:
it allowed any admin to update ANY profile across all companies, breaking multi-tenant
isolation. Also, there was no DELETE policy, so the "Reject" button in User Management
couldn't delete pending users.

## Fix
1. UPDATE policy: admin can update profiles in their own company OR pending (NULL company)
   users. Users can always update their own profile.
2. DELETE policy: admin can delete profiles in their own company OR pending (NULL company)
   users. This allows rejecting pending signups.
3. INSERT policy: keep the existing company-scoped check (handles new users in own company).

## Security
- Multi-tenant isolation is preserved: admin can only modify/delete users in their company
  plus pending users (company_id IS NULL).
- Users can still update their own profile.
*/

-- Fix UPDATE policy: admin can update own-company users + pending (NULL) users
DROP POLICY IF EXISTS "auth_update_profiles" ON profiles;
CREATE POLICY "auth_update_profiles" ON profiles FOR UPDATE TO authenticated
  USING (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.role = 'admin'
      AND (
        profiles.company_id = p.company_id
        OR profiles.company_id IS NULL
      )
    )
  )
  WITH CHECK (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.role = 'admin'
      AND (
        profiles.company_id = p.company_id
        OR profiles.company_id IS NULL
      )
    )
  );

-- Add DELETE policy: admin can delete own-company users + pending (NULL) users
DROP POLICY IF EXISTS "auth_delete_profiles" ON profiles;
CREATE POLICY "auth_delete_profiles" ON profiles FOR DELETE TO authenticated
  USING (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.role = 'admin'
      AND (
        profiles.company_id = p.company_id
        OR profiles.company_id IS NULL
      )
    )
  );
