-- Revoke EXECUTE from PUBLIC on all SECURITY DEFINER functions
-- (PUBLIC grants to anon implicitly, so REVOKE FROM anon alone is insufficient)

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.next_invoice_number() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.next_quotation_number() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.next_purchase_number() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.produce_batch(uuid, numeric, date, text, text) FROM PUBLIC;
