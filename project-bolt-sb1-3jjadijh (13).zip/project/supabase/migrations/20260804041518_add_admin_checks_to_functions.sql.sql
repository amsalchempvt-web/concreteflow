-- Add admin authorization checks inside SECURITY DEFINER functions
-- so non-admins cannot call them directly via the REST API

CREATE OR REPLACE FUNCTION public.export_backup()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_result jsonb := '{}'::jsonb;
  v_tables text[] := ARRAY[
    'companies', 'suppliers', 'raw_materials', 'raw_material_movements',
    'finished_products', 'finished_product_bom', 'finished_product_movements',
    'productions', 'customers', 'sales_invoices', 'quotations',
    'expenses', 'purchases', 'activity_logs',
    'notification_settings', 'notification_logs', 'user_permissions',
    'profiles'
  ];
  v_table text;
  v_data jsonb;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  FOREACH v_table IN ARRAY v_tables LOOP
    EXECUTE format('SELECT coalesce(jsonb_agg(to_jsonb(t)), ''[]''::jsonb) FROM %I t', v_table) INTO v_data;
    v_result := v_result || jsonb_build_object(v_table, v_data);
  END LOOP;

  RETURN jsonb_build_object(
    'tables', v_result,
    'version', 1,
    'exported_at', to_char(now(), 'YYYY-MM-DD"T"HH24:MI:SSOF')
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.export_backup() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.export_backup() TO authenticated;

CREATE OR REPLACE FUNCTION public.import_backup(p_data jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_tables text[] := ARRAY[
    'notification_logs', 'notification_settings', 'activity_logs',
    'purchases', 'expenses', 'quotations', 'sales_invoices',
    'customers', 'productions', 'finished_product_movements',
    'finished_product_bom', 'finished_products', 'raw_material_movements',
    'raw_materials', 'suppliers', 'companies', 'user_permissions',
    'profiles'
  ];
  v_table text;
  v_rows jsonb;
  v_row jsonb;
  v_count int := 0;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  IF p_data ? 'tables' = false THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid backup format: missing "tables" key');
  END IF;

  SET session_replication_role = 'replica';

  FOREACH v_table IN ARRAY v_tables LOOP
    IF (p_data -> 'tables') ? v_table THEN
      v_rows := (p_data -> 'tables' -> v_table);
      IF jsonb_typeof(v_rows) = 'array' AND jsonb_array_length(v_rows) > 0 THEN
        EXECUTE format('TRUNCATE TABLE %I RESTART IDENTITY CASCADE', v_table);
      END IF;
    END IF;
  END LOOP;

  FOREACH v_table IN ARRAY v_tables LOOP
    IF (p_data -> 'tables') ? v_table THEN
      v_rows := (p_data -> 'tables' -> v_table);
      IF jsonb_typeof(v_rows) = 'array' AND jsonb_array_length(v_rows) > 0 THEN
        FOR v_row IN SELECT jsonb_array_elements(v_rows) LOOP
          EXECUTE format(
            'INSERT INTO %I SELECT * FROM jsonb_populate_record(NULL::%I, $1)',
            v_table, v_table
          ) USING v_row;
          v_count := v_count + 1;
        END LOOP;
      END IF;
    END IF;
  END LOOP;

  SET session_replication_role = 'origin';

  RETURN jsonb_build_object('success', true, 'rows_restored', v_count);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.import_backup(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.import_backup(jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.sync_profiles_from_auth_users()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_count int := 0;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  INSERT INTO public.profiles (id, email, full_name, role)
  SELECT
    u.id,
    u.email,
    COALESCE(u.raw_user_meta_data->>'full_name', ''),
    COALESCE(u.raw_user_meta_data->>'role', 'plant_operator')
  FROM auth.users u
  WHERE NOT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = u.id)
  ON CONFLICT (id) DO NOTHING;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN jsonb_build_object('success', true, 'profiles_created', v_count);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.sync_profiles_from_auth_users() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.sync_profiles_from_auth_users() TO authenticated;
