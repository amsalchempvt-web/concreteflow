/*
# Delivery challans and super-admin controls

1. New role
- Adds `super_admin` to profiles so only the platform owner can create companies and users.

2. New table
- `delivery_challans` stores the delivery challan linked one-to-one to a sales invoice.
- Stores challan number, customer/site details, order and vehicle details, concrete grade,
  quantity, meter readings, timing, GST/PAN, weights, and notes used by the printed form.

3. Security
- Adds a SECURITY DEFINER `is_super_admin()` helper that checks the signed-in profile.
- Super admins can read and create companies and can read all profiles.
- Existing company admins retain company-scoped access and cannot use super-admin controls.
- Delivery challans use the same authenticated ERP access model as sales invoices.
*/

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_role_check') THEN
    ALTER TABLE public.profiles DROP CONSTRAINT profiles_role_check;
  END IF;
  ALTER TABLE public.profiles
    ADD CONSTRAINT profiles_role_check CHECK (role IN ('super_admin','admin','manager','accountant','plant_operator','sales_executive'));
END $$;

CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT role = 'super_admin' FROM public.profiles WHERE id = auth.uid();
$$;

REVOKE EXECUTE ON FUNCTION public.is_super_admin() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_super_admin() TO authenticated;

DROP POLICY IF EXISTS "auth_select_profiles" ON public.profiles;
CREATE POLICY "auth_select_profiles" ON public.profiles FOR SELECT TO authenticated
USING (
  id = auth.uid()
  OR public.is_super_admin()
  OR (public.is_user_admin() AND (company_id = public.get_user_company_id() OR company_id IS NULL))
);

DROP POLICY IF EXISTS "auth_select_companies" ON public.companies;
CREATE POLICY "auth_select_companies" ON public.companies FOR SELECT TO authenticated
USING (public.is_super_admin() OR id = public.get_user_company_id());

DROP POLICY IF EXISTS "auth_insert_companies" ON public.companies;
CREATE POLICY "auth_insert_companies" ON public.companies FOR INSERT TO authenticated
WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "auth_update_companies" ON public.companies;
CREATE POLICY "auth_update_companies" ON public.companies FOR UPDATE TO authenticated
USING (public.is_super_admin() OR id = public.get_user_company_id())
WITH CHECK (public.is_super_admin() OR id = public.get_user_company_id());

CREATE TABLE IF NOT EXISTS public.delivery_challans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid UNIQUE REFERENCES public.sales_invoices(id) ON DELETE CASCADE,
  challan_number text UNIQUE NOT NULL,
  challan_date date NOT NULL DEFAULT CURRENT_DATE,
  customer_id uuid NOT NULL REFERENCES public.customers(id) ON DELETE RESTRICT,
  client_name text NOT NULL DEFAULT '',
  site text NOT NULL DEFAULT '',
  po_number text NOT NULL DEFAULT '',
  so_number text NOT NULL DEFAULT '',
  batch_number text NOT NULL DEFAULT '',
  serial_number text NOT NULL DEFAULT '1',
  grade text NOT NULL DEFAULT '',
  pump_type text NOT NULL DEFAULT '',
  quantity numeric(14,3) NOT NULL DEFAULT 0,
  tm_number text NOT NULL DEFAULT '',
  driver_name text NOT NULL DEFAULT '',
  opening_cmt numeric(14,3) NOT NULL DEFAULT 0,
  current_cmt numeric(14,3) NOT NULL DEFAULT 0,
  total_cmt numeric(14,3) NOT NULL DEFAULT 0,
  time_out text NOT NULL DEFAULT '',
  time_in text NOT NULL DEFAULT '',
  gst_number text NOT NULL DEFAULT '',
  pan_number text NOT NULL DEFAULT '',
  state_code text NOT NULL DEFAULT '',
  site_time text NOT NULL DEFAULT '',
  kms text NOT NULL DEFAULT '',
  gross_weight text NOT NULL DEFAULT '',
  tare_weight text NOT NULL DEFAULT '',
  net_weight text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_delivery_challans_date ON public.delivery_challans(challan_date DESC);
CREATE INDEX IF NOT EXISTS idx_delivery_challans_customer ON public.delivery_challans(customer_id);

ALTER TABLE public.delivery_challans ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_delivery_challans" ON public.delivery_challans;
CREATE POLICY "auth_select_delivery_challans" ON public.delivery_challans FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_delivery_challans" ON public.delivery_challans;
CREATE POLICY "auth_insert_delivery_challans" ON public.delivery_challans FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_delivery_challans" ON public.delivery_challans;
CREATE POLICY "auth_update_delivery_challans" ON public.delivery_challans FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_delivery_challans" ON public.delivery_challans;
CREATE POLICY "auth_delete_delivery_challans" ON public.delivery_challans FOR DELETE TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.next_challan_number()
RETURNS text
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT 'DC-' || to_char(now(), 'YYYYMM') || '-' || lpad((COUNT(*) + 1)::text, 4, '0')
  FROM public.delivery_challans
  WHERE to_char(challan_date, 'YYYYMM') = to_char(now(), 'YYYYMM');
$$;

REVOKE EXECUTE ON FUNCTION public.next_challan_number() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.next_challan_number() TO authenticated;
