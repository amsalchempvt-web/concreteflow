/*
# Multi-Tenant Company Isolation

## Overview
Transforms the database from a single shared company model to a multi-tenant architecture
where each company's data is strictly isolated via Row Level Security. Every user belongs
to one company and can only see/modify their own company's data.

## Changes
1. Adds `company_id` column to all data tables
2. Assigns all existing data to the current default company
3. Replaces all RLS policies with company-scoped policies
4. Updates handle_new_user trigger to create a new company on first signup
5. Updates company-scoped helper functions

## Security
- All RLS policies enforce company isolation via get_user_company_id() helper
- INSERT/UPDATE policies use WITH CHECK to prevent cross-company writes
*/

-- Add company_id to all data tables and backfill existing data
DO $$
DECLARE
  v_default_company uuid;
BEGIN
  SELECT id INTO v_default_company FROM companies ORDER BY created_at LIMIT 1;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='suppliers' AND column_name='company_id') THEN
    ALTER TABLE suppliers ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE suppliers SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='raw_materials' AND column_name='company_id') THEN
    ALTER TABLE raw_materials ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE raw_materials SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='raw_material_movements' AND column_name='company_id') THEN
    ALTER TABLE raw_material_movements ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE raw_material_movements rmm SET company_id = rm.company_id FROM raw_materials rm WHERE rmm.material_id = rm.id AND rmm.company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='finished_products' AND column_name='company_id') THEN
    ALTER TABLE finished_products ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE finished_products SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='finished_product_bom' AND column_name='company_id') THEN
    ALTER TABLE finished_product_bom ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE finished_product_bom bom SET company_id = fp.company_id FROM finished_products fp WHERE bom.product_id = fp.id AND bom.company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='finished_product_movements' AND column_name='company_id') THEN
    ALTER TABLE finished_product_movements ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE finished_product_movements fpm SET company_id = fp.company_id FROM finished_products fp WHERE fpm.product_id = fp.id AND fpm.company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='productions' AND column_name='company_id') THEN
    ALTER TABLE productions ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE productions p SET company_id = fp.company_id FROM finished_products fp WHERE p.product_id = fp.id AND p.company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='customers' AND column_name='company_id') THEN
    ALTER TABLE customers ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE customers SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='sales_invoices' AND column_name='company_id') THEN
    ALTER TABLE sales_invoices ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE sales_invoices si SET company_id = c.company_id FROM customers c WHERE si.customer_id = c.id AND si.company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='quotations' AND column_name='company_id') THEN
    ALTER TABLE quotations ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE quotations q SET company_id = COALESCE(c.company_id, v_default_company) FROM customers c WHERE q.customer_id = c.id AND q.company_id IS NULL;
    UPDATE quotations SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='expenses' AND column_name='company_id') THEN
    ALTER TABLE expenses ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE expenses SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='purchases' AND column_name='company_id') THEN
    ALTER TABLE purchases ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE purchases pur SET company_id = s.company_id FROM suppliers s WHERE pur.supplier_id = s.id AND pur.company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='activity_logs' AND column_name='company_id') THEN
    ALTER TABLE activity_logs ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE activity_logs SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notification_settings' AND column_name='company_id') THEN
    ALTER TABLE notification_settings ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE notification_settings SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notification_logs' AND column_name='company_id') THEN
    ALTER TABLE notification_logs ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
    UPDATE notification_logs SET company_id = v_default_company WHERE company_id IS NULL;
  END IF;
  
  UPDATE profiles SET company_id = v_default_company WHERE company_id IS NULL;
END $$;

-- Helper function: get current user's company_id
CREATE OR REPLACE FUNCTION public.get_user_company_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT company_id FROM public.profiles WHERE id = auth.uid();
$$;

REVOKE EXECUTE ON FUNCTION public.get_user_company_id() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.get_user_company_id() FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_user_company_id() FROM authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_company_id() TO authenticated;

-- ============================================================
-- RLS POLICIES FOR COMPANY ISOLATION
-- ============================================================

-- PROFILES
DROP POLICY IF EXISTS "auth_select_profiles" ON profiles;
CREATE POLICY "auth_select_profiles" ON profiles FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());

DROP POLICY IF EXISTS "auth_insert_profiles" ON profiles;
CREATE POLICY "auth_insert_profiles" ON profiles FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());

DROP POLICY IF EXISTS "auth_update_profiles" ON profiles;
CREATE POLICY "auth_update_profiles" ON profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin' AND p.company_id = profiles.company_id))
  WITH CHECK (id = auth.uid() OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin' AND p.company_id = profiles.company_id));

-- COMPANIES
DROP POLICY IF EXISTS "auth_select_companies" ON companies;
CREATE POLICY "auth_select_companies" ON companies FOR SELECT TO authenticated
  USING (id = public.get_user_company_id());

DROP POLICY IF EXISTS "auth_insert_companies" ON companies;
CREATE POLICY "auth_insert_companies" ON companies FOR INSERT TO authenticated
  WITH CHECK (false);

DROP POLICY IF EXISTS "auth_update_companies" ON companies;
CREATE POLICY "auth_update_companies" ON companies FOR UPDATE TO authenticated
  USING (id = public.get_user_company_id())
  WITH CHECK (id = public.get_user_company_id());

DROP POLICY IF EXISTS "auth_delete_companies" ON companies;
CREATE POLICY "auth_delete_companies" ON companies FOR DELETE TO authenticated
  USING (false);

-- SUPPLIERS
DROP POLICY IF EXISTS "auth_select_suppliers" ON suppliers;
CREATE POLICY "auth_select_suppliers" ON suppliers FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_suppliers" ON suppliers;
CREATE POLICY "auth_insert_suppliers" ON suppliers FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_suppliers" ON suppliers;
CREATE POLICY "auth_update_suppliers" ON suppliers FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_suppliers" ON suppliers;
CREATE POLICY "auth_delete_suppliers" ON suppliers FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- RAW MATERIALS
DROP POLICY IF EXISTS "auth_select_raw_materials" ON raw_materials;
CREATE POLICY "auth_select_raw_materials" ON raw_materials FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_raw_materials" ON raw_materials;
CREATE POLICY "auth_insert_raw_materials" ON raw_materials FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_raw_materials" ON raw_materials;
CREATE POLICY "auth_update_raw_materials" ON raw_materials FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_raw_materials" ON raw_materials;
CREATE POLICY "auth_delete_raw_materials" ON raw_materials FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- RAW MATERIAL MOVEMENTS
DROP POLICY IF EXISTS "auth_select_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_select_rm_movements" ON raw_material_movements FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_insert_rm_movements" ON raw_material_movements FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_update_rm_movements" ON raw_material_movements FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_delete_rm_movements" ON raw_material_movements FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- FINISHED PRODUCTS
DROP POLICY IF EXISTS "auth_select_finished_products" ON finished_products;
CREATE POLICY "auth_select_finished_products" ON finished_products FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_finished_products" ON finished_products;
CREATE POLICY "auth_insert_finished_products" ON finished_products FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_finished_products" ON finished_products;
CREATE POLICY "auth_update_finished_products" ON finished_products FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_finished_products" ON finished_products;
CREATE POLICY "auth_delete_finished_products" ON finished_products FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- FINISHED PRODUCT BOM
DROP POLICY IF EXISTS "auth_select_bom" ON finished_product_bom;
CREATE POLICY "auth_select_bom" ON finished_product_bom FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_bom" ON finished_product_bom;
CREATE POLICY "auth_insert_bom" ON finished_product_bom FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_bom" ON finished_product_bom;
CREATE POLICY "auth_update_bom" ON finished_product_bom FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_bom" ON finished_product_bom;
CREATE POLICY "auth_delete_bom" ON finished_product_bom FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- FINISHED PRODUCT MOVEMENTS
DROP POLICY IF EXISTS "auth_select_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_select_fp_movements" ON finished_product_movements FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_insert_fp_movements" ON finished_product_movements FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_update_fp_movements" ON finished_product_movements FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_delete_fp_movements" ON finished_product_movements FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- PRODUCTIONS
DROP POLICY IF EXISTS "auth_select_productions" ON productions;
CREATE POLICY "auth_select_productions" ON productions FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_productions" ON productions;
CREATE POLICY "auth_insert_productions" ON productions FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_productions" ON productions;
CREATE POLICY "auth_update_productions" ON productions FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_productions" ON productions;
CREATE POLICY "auth_delete_productions" ON productions FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- CUSTOMERS
DROP POLICY IF EXISTS "auth_select_customers" ON customers;
CREATE POLICY "auth_select_customers" ON customers FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_customers" ON customers;
CREATE POLICY "auth_insert_customers" ON customers FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_customers" ON customers;
CREATE POLICY "auth_update_customers" ON customers FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_customers" ON customers;
CREATE POLICY "auth_delete_customers" ON customers FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- SALES INVOICES
DROP POLICY IF EXISTS "auth_select_invoices" ON sales_invoices;
CREATE POLICY "auth_select_invoices" ON sales_invoices FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_invoices" ON sales_invoices;
CREATE POLICY "auth_insert_invoices" ON sales_invoices FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_invoices" ON sales_invoices;
CREATE POLICY "auth_update_invoices" ON sales_invoices FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_invoices" ON sales_invoices;
CREATE POLICY "auth_delete_invoices" ON sales_invoices FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- QUOTATIONS
DROP POLICY IF EXISTS "auth_select_quotations" ON quotations;
CREATE POLICY "auth_select_quotations" ON quotations FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_quotations" ON quotations;
CREATE POLICY "auth_insert_quotations" ON quotations FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_quotations" ON quotations;
CREATE POLICY "auth_update_quotations" ON quotations FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_quotations" ON quotations;
CREATE POLICY "auth_delete_quotations" ON quotations FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- EXPENSES
DROP POLICY IF EXISTS "auth_select_expenses" ON expenses;
CREATE POLICY "auth_select_expenses" ON expenses FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_expenses" ON expenses;
CREATE POLICY "auth_insert_expenses" ON expenses FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_expenses" ON expenses;
CREATE POLICY "auth_update_expenses" ON expenses FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_expenses" ON expenses;
CREATE POLICY "auth_delete_expenses" ON expenses FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- PURCHASES
DROP POLICY IF EXISTS "auth_select_purchases" ON purchases;
CREATE POLICY "auth_select_purchases" ON purchases FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_purchases" ON purchases;
CREATE POLICY "auth_insert_purchases" ON purchases FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_purchases" ON purchases;
CREATE POLICY "auth_update_purchases" ON purchases FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_purchases" ON purchases;
CREATE POLICY "auth_delete_purchases" ON purchases FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- ACTIVITY LOGS
DROP POLICY IF EXISTS "auth_select_activity_logs" ON activity_logs;
CREATE POLICY "auth_select_activity_logs" ON activity_logs FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_activity_logs" ON activity_logs;
CREATE POLICY "auth_insert_activity_logs" ON activity_logs FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());

-- USER PERMISSIONS
DROP POLICY IF EXISTS "auth_select_user_permissions" ON user_permissions;
CREATE POLICY "auth_select_user_permissions" ON user_permissions FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = user_permissions.user_id AND p.company_id = public.get_user_company_id()));
DROP POLICY IF EXISTS "auth_insert_user_permissions" ON user_permissions;
CREATE POLICY "auth_insert_user_permissions" ON user_permissions FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = user_permissions.user_id AND p.company_id = public.get_user_company_id()));
DROP POLICY IF EXISTS "auth_update_user_permissions" ON user_permissions;
CREATE POLICY "auth_update_user_permissions" ON user_permissions FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = user_permissions.user_id AND p.company_id = public.get_user_company_id()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = user_permissions.user_id AND p.company_id = public.get_user_company_id()));
DROP POLICY IF EXISTS "auth_delete_user_permissions" ON user_permissions;
CREATE POLICY "auth_delete_user_permissions" ON user_permissions FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = user_permissions.user_id AND p.company_id = public.get_user_company_id()));

-- NOTIFICATION SETTINGS
DROP POLICY IF EXISTS "auth_select_notification_settings" ON notification_settings;
CREATE POLICY "auth_select_notification_settings" ON notification_settings FOR SELECT TO authenticated
  USING (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_insert_notification_settings" ON notification_settings;
CREATE POLICY "auth_insert_notification_settings" ON notification_settings FOR INSERT TO authenticated
  WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_update_notification_settings" ON notification_settings;
CREATE POLICY "auth_update_notification_settings" ON notification_settings FOR UPDATE TO authenticated
  USING (company_id = public.get_user_company_id()) WITH CHECK (company_id = public.get_user_company_id());
DROP POLICY IF EXISTS "auth_delete_notification_settings" ON notification_settings;
CREATE POLICY "auth_delete_notification_settings" ON notification_settings FOR DELETE TO authenticated
  USING (company_id = public.get_user_company_id());

-- NOTIFICATION LOGS (if table exists with company_id)
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notification_logs' AND column_name='company_id') THEN
    DROP POLICY IF EXISTS "auth_select_notification_logs" ON notification_logs;
    CREATE POLICY "auth_select_notification_logs" ON notification_logs FOR SELECT TO authenticated
      USING (company_id = public.get_user_company_id());
    DROP POLICY IF EXISTS "auth_insert_notification_logs" ON notification_logs;
    CREATE POLICY "auth_insert_notification_logs" ON notification_logs FOR INSERT TO authenticated
      WITH CHECK (company_id = public.get_user_company_id());
  END IF;
END $$;

-- ============================================================
-- HANDLE_NEW_USER TRIGGER (multi-company)
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_admin_count int;
  v_assigned_role text;
  v_new_company_id uuid;
  v_company_name text;
BEGIN
  SELECT COUNT(*) INTO v_admin_count FROM public.profiles WHERE role = 'admin';

  IF v_admin_count = 0 THEN
    v_assigned_role := 'admin';
    v_company_name := COALESCE(NEW.raw_user_meta_data->>'company_name', 'My Company');
    INSERT INTO public.companies (name) VALUES (v_company_name)
    RETURNING id INTO v_new_company_id;
  ELSE
    v_assigned_role := 'plant_operator';
    v_new_company_id := NULL;
  END IF;

  INSERT INTO public.profiles (id, email, full_name, role, company_id)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    v_assigned_role,
    v_new_company_id
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;

-- ============================================================
-- COMPANY-SCOPED HELPER FUNCTIONS
-- ============================================================
CREATE OR REPLACE FUNCTION next_invoice_number()
RETURNS text
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT 'INV-' || to_char(now(), 'YYYYMM') || '-' || lpad((COUNT(*) + 1)::text, 4, '0')
  FROM sales_invoices
  WHERE to_char(invoice_date, 'YYYYMM') = to_char(now(), 'YYYYMM')
    AND company_id = public.get_user_company_id();
$$;

CREATE OR REPLACE FUNCTION next_quotation_number()
RETURNS text
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT 'QUO-' || to_char(now(), 'YYYYMM') || '-' || lpad((COUNT(*) + 1)::text, 4, '0')
  FROM quotations
  WHERE to_char(quotation_date, 'YYYYMM') = to_char(now(), 'YYYYMM')
    AND company_id = public.get_user_company_id();
$$;

CREATE OR REPLACE FUNCTION next_purchase_number()
RETURNS text
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT 'PUR-' || to_char(now(), 'YYYYMM') || '-' || lpad((COUNT(*) + 1)::text, 4, '0')
  FROM purchases
  WHERE to_char(bill_date, 'YYYYMM') = to_char(now(), 'YYYYMM')
    AND company_id = public.get_user_company_id();
$$;

-- PRODUCE_BATCH (company-scoped)
CREATE OR REPLACE FUNCTION produce_batch(
  p_product_id uuid,
  p_quantity numeric,
  p_production_date date DEFAULT CURRENT_DATE,
  p_operator_name text DEFAULT '',
  p_notes text DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_company_id uuid;
  v_product RECORD;
  v_bom RECORD;
  v_batch_number text;
  v_total_cost numeric(14,2) := 0;
  v_material_cost numeric(14,2);
  v_insufficient jsonb[] := '{}'::jsonb[];
  v_new_rm_stock numeric(14,3);
  v_new_fp_stock numeric(14,3);
  v_prod_id uuid;
  v_seq int;
BEGIN
  v_company_id := public.get_user_company_id();
  IF v_company_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'No company assigned');
  END IF;

  SELECT * INTO v_product FROM finished_products WHERE id = p_product_id AND company_id = v_company_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Product not found');
  END IF;

  IF p_quantity <= 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Quantity must be greater than zero');
  END IF;

  FOR v_bom IN
    SELECT b.material_id, b.quantity_per_unit, m.name, m.current_stock, m.unit, m.unit_cost
    FROM finished_product_bom b
    JOIN raw_materials m ON m.id = b.material_id
    WHERE b.product_id = p_product_id AND b.company_id = v_company_id
  LOOP
    v_material_cost := v_bom.quantity_per_unit * p_quantity * v_bom.unit_cost;
    v_total_cost := v_total_cost + v_material_cost;
    IF v_bom.current_stock < (v_bom.quantity_per_unit * p_quantity) THEN
      v_insufficient := array_append(v_insufficient, jsonb_build_object(
        'material_id', v_bom.material_id, 'name', v_bom.name,
        'required', v_bom.quantity_per_unit * p_quantity,
        'available', v_bom.current_stock, 'unit', v_bom.unit
      ));
    END IF;
  END LOOP;

  IF array_length(v_insufficient, 1) > 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Insufficient raw material stock', 'insufficient_materials', to_jsonb(v_insufficient));
  END IF;

  v_seq := COALESCE((SELECT COUNT(*) + 1 FROM productions WHERE production_date = p_production_date AND company_id = v_company_id), 1);
  v_batch_number := 'BATCH-' || to_char(p_production_date, 'YYYYMMDD') || '-' || lpad(v_seq::text, 3, '0');

  FOR v_bom IN
    SELECT b.material_id, b.quantity_per_unit, m.current_stock, m.unit_cost
    FROM finished_product_bom b
    JOIN raw_materials m ON m.id = b.material_id
    WHERE b.product_id = p_product_id AND b.company_id = v_company_id
  LOOP
    v_new_rm_stock := v_bom.current_stock - (v_bom.quantity_per_unit * p_quantity);
    UPDATE raw_materials SET current_stock = v_new_rm_stock, updated_at = now() WHERE id = v_bom.material_id AND company_id = v_company_id;
    INSERT INTO raw_material_movements (material_id, movement_type, quantity_change, balance_after, reference, notes, company_id)
    VALUES (v_bom.material_id, 'production_consumption', -(v_bom.quantity_per_unit * p_quantity), v_new_rm_stock, v_batch_number, 'Consumed for production batch', v_company_id);
  END LOOP;

  v_new_fp_stock := v_product.current_stock + p_quantity;
  UPDATE finished_products SET current_stock = v_new_fp_stock, production_cost = v_total_cost / p_quantity, updated_at = now() WHERE id = p_product_id AND company_id = v_company_id;

  INSERT INTO finished_product_movements (product_id, movement_type, quantity_change, balance_after, reference, notes, company_id)
  VALUES (p_product_id, 'production', p_quantity, v_new_fp_stock, v_batch_number, 'Production batch', v_company_id);

  INSERT INTO productions (batch_number, product_id, quantity, production_date, operator_name, total_cost, status, notes, company_id)
  VALUES (v_batch_number, p_product_id, p_quantity, p_production_date, p_operator_name, v_total_cost, 'completed', p_notes, v_company_id)
  RETURNING id INTO v_prod_id;

  RETURN jsonb_build_object('success', true, 'production_id', v_prod_id, 'batch_number', v_batch_number, 'total_cost', v_total_cost, 'cost_per_unit', v_total_cost / p_quantity, 'new_finished_stock', v_new_fp_stock);
END;
$$;

-- Grant execute on helper functions to authenticated users
REVOKE EXECUTE ON FUNCTION public.produce_batch(uuid, numeric, date, text, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.produce_batch(uuid, numeric, date, text, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.produce_batch(uuid, numeric, date, text, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.next_invoice_number() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.next_invoice_number() FROM anon;
GRANT EXECUTE ON FUNCTION public.next_invoice_number() TO authenticated;

REVOKE EXECUTE ON FUNCTION public.next_quotation_number() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.next_quotation_number() FROM anon;
GRANT EXECUTE ON FUNCTION public.next_quotation_number() TO authenticated;

REVOKE EXECUTE ON FUNCTION public.next_purchase_number() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.next_purchase_number() FROM anon;
GRANT EXECUTE ON FUNCTION public.next_purchase_number() TO authenticated;

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_suppliers_company ON suppliers(company_id);
CREATE INDEX IF NOT EXISTS idx_raw_materials_company ON raw_materials(company_id);
CREATE INDEX IF NOT EXISTS idx_rm_movements_company ON raw_material_movements(company_id);
CREATE INDEX IF NOT EXISTS idx_finished_products_company ON finished_products(company_id);
CREATE INDEX IF NOT EXISTS idx_bom_company ON finished_product_bom(company_id);
CREATE INDEX IF NOT EXISTS idx_fp_movements_company ON finished_product_movements(company_id);
CREATE INDEX IF NOT EXISTS idx_productions_company ON productions(company_id);
CREATE INDEX IF NOT EXISTS idx_customers_company ON customers(company_id);
CREATE INDEX IF NOT EXISTS idx_invoices_company ON sales_invoices(company_id);
CREATE INDEX IF NOT EXISTS idx_quotations_company ON quotations(company_id);
CREATE INDEX IF NOT EXISTS idx_expenses_company ON expenses(company_id);
CREATE INDEX IF NOT EXISTS idx_purchases_company ON purchases(company_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_company ON activity_logs(company_id);
CREATE INDEX IF NOT EXISTS idx_notification_settings_company ON notification_settings(company_id);
