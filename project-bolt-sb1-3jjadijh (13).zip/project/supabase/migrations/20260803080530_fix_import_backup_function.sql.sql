/*
# Fix import_backup function

The previous version used FOREACH over a jsonb array, which fails because
FOREACH expects a native PostgreSQL array, not jsonb. This version uses
jsonb_array_elements() to iterate over rows, and builds column lists dynamically
from the JSON keys so we only insert columns present in the backup data.
*/

CREATE OR REPLACE FUNCTION public.import_backup(p_data jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_tables text[] := ARRAY[
    'notification_logs', 'notification_settings', 'activity_logs',
    'purchases', 'expenses', 'quotations', 'sales_invoices',
    'customers', 'productions', 'finished_product_movements',
    'finished_product_bom', 'finished_products', 'raw_material_movements',
    'raw_materials', 'suppliers', 'companies', 'user_permissions'
  ];
  v_table text;
  v_rows jsonb;
  v_row jsonb;
  v_count int := 0;
  v_cols text;
  v_placeholders text;
  v_col text;
  v_idx int;
BEGIN
  IF p_data ? 'tables' = false THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid backup format: missing "tables" key');
  END IF;

  SET session_replication_role = 'replica';

  FOREACH v_table IN ARRAY v_tables LOOP
    IF (p_data -> 'tables') ? v_table THEN
      v_rows := (p_data -> 'tables' -> v_table);
      IF jsonb_typeof(v_rows) = 'array' AND jsonb_array_length(v_rows) > 0 THEN
        EXECUTE format('TRUNCATE TABLE %I RESTART IDENTITY CASCADE', v_table);

        FOR v_row IN SELECT jsonb_array_elements(v_rows) LOOP
          v_cols := '';
          v_placeholders := '';
          v_idx := 1;
          FOR v_col IN SELECT jsonb_object_keys(v_row) LOOP
            IF v_cols <> '' THEN
              v_cols := v_cols || ', ';
              v_placeholders := v_placeholders || ', ';
            END IF;
            v_cols := v_cols || quote_ident(v_col);
            v_placeholders := v_placeholders || '$' || v_idx;
            v_idx := v_idx + 1;
          END LOOP;

          EXECUTE format(
            'INSERT INTO %I (%s) SELECT %s FROM jsonb_to_record($1) AS x(%s)',
            v_table, v_cols, v_placeholders, v_cols
          ) USING v_row;

          v_count := v_count + 1;
        END LOOP;
      END IF;
    END IF;
  END LOOP;

  SET session_replication_role = 'origin';

  RETURN jsonb_build_object('success', true, 'rows_restored', v_count);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.import_backup(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.import_backup(jsonb) TO authenticated;
