-- Fix: the trigger was checking if ANY profiles exist to decide admin role.
-- But seed data created profiles before any real signup, so every new user
-- got plant_operator. Now we check if an ADMIN already exists instead.

-- Drop the unique index temporarily so we can fix roles
DROP INDEX IF EXISTS profiles_only_one_admin;

-- Demote any existing admins (there are none currently, but safety)
UPDATE profiles SET role = 'plant_operator' WHERE role = 'admin';

-- Promote admin@sjis.com to admin (the user's intended admin account)
UPDATE profiles SET role = 'admin' WHERE email = 'admin@sjis.com';

-- Update the trigger to check for existing admin, not existing profiles
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_admin_count int;
  v_assigned_role text;
BEGIN
  -- If no admin exists yet, this user becomes the admin
  SELECT COUNT(*) INTO v_admin_count FROM public.profiles WHERE role = 'admin';

  IF v_admin_count = 0 THEN
    v_assigned_role := 'admin';
  ELSE
    v_assigned_role := 'plant_operator';
  END IF;

  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    v_assigned_role
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;

-- Recreate the unique admin index
CREATE UNIQUE INDEX profiles_only_one_admin
ON public.profiles ((1))
WHERE role = 'admin';
