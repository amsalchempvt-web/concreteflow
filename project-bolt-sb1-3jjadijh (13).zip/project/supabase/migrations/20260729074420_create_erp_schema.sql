/*
# Concrete Mixing Plant ERP - Core Schema

## Overview
Creates the complete database schema for a Concrete Mixing Plant ERP & Inventory Management System.
This is a multi-user authenticated application where all authenticated users share the same company data
(role-based access control is enforced in the frontend via user roles).

## New Tables
1. `profiles` - Extends auth.users with full name and role (admin, manager, accountant, plant_operator, sales_executive)
2. `raw_materials` - Raw material inventory (cement, sand, aggregate, etc.) with stock levels and units
3. `raw_material_movements` - Stock movement history for raw materials (purchases, consumption, adjustments)
4. `finished_products` - Concrete grades (M10-M40) with selling price, production cost, and stock
5. `finished_product_bom` - Bill of Materials: recipe linking finished products to raw materials with per-unit quantities
6. `finished_product_movements` - Stock movement history for finished products
7. `productions` - Production batch records with batch numbers, operator, cost, and status
8. `customers` - Customer records with GST, contact info, and outstanding balance
9. `suppliers` - Supplier records with GST, contact info, and outstanding payments
10. `sales_invoices` - Sales invoices with line items, GST, payment status
11. `quotations` - Quotations with validity, terms, and conversion-to-invoice status
12. `expenses` - Expense tracking by category with optional receipt URL
13. `activity_logs` - Audit trail of user actions across the system

## Security
- RLS enabled on ALL tables
- All tables use `TO authenticated` with `USING (true)` / `WITH CHECK (true)` because this is a shared
  company ERP — every authenticated user can access all company data. Role-based restrictions are
  enforced in the application layer.
- The `produce_batch` function uses SECURITY DEFINER to perform atomic multi-table updates.

## Important Functions
1. `produce_batch(...)` - The core BOM deduction function. Atomically checks stock, deducts raw materials,
   increases finished product stock, and records all movements + production history. Returns success/failure JSON.
2. `handle_new_user()` - Trigger to auto-create a profile row when a new auth user signs up.

## Important Notes
1. The `produce_batch` function blocks production if any raw material is insufficient and returns the
   list of deficient materials so the UI can display them.
2. Batch numbers auto-generate as `BATCH-YYYYMMDD-NNN`.
3. Invoice and quotation numbers auto-generate with sequential prefixes.
*/

-- ============================================================
-- PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text DEFAULT '',
  role text NOT NULL DEFAULT 'plant_operator' CHECK (role IN ('admin','manager','accountant','plant_operator','sales_executive')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_profiles" ON profiles;
CREATE POLICY "auth_select_profiles" ON profiles FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_profiles" ON profiles;
CREATE POLICY "auth_insert_profiles" ON profiles FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_profiles" ON profiles;
CREATE POLICY "auth_update_profiles" ON profiles FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), COALESCE(NEW.raw_user_meta_data->>'role', 'plant_operator'))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- SUPPLIERS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company text DEFAULT '',
  contact text DEFAULT '',
  email text DEFAULT '',
  gst_number text DEFAULT '',
  material_supplied text DEFAULT '',
  outstanding_payment numeric(14,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_suppliers" ON suppliers;
CREATE POLICY "auth_select_suppliers" ON suppliers FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_suppliers" ON suppliers;
CREATE POLICY "auth_insert_suppliers" ON suppliers FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_suppliers" ON suppliers;
CREATE POLICY "auth_update_suppliers" ON suppliers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_suppliers" ON suppliers;
CREATE POLICY "auth_delete_suppliers" ON suppliers FOR DELETE TO authenticated USING (true);

-- ============================================================
-- RAW MATERIALS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS raw_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE NOT NULL,
  unit text NOT NULL DEFAULT 'Kg' CHECK (unit IN ('Kg','Ton','Cubic Meter','Liter','Piece')),
  current_stock numeric(14,3) NOT NULL DEFAULT 0,
  minimum_stock numeric(14,3) NOT NULL DEFAULT 0,
  unit_cost numeric(14,2) NOT NULL DEFAULT 0,
  supplier_id uuid REFERENCES suppliers(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE raw_materials ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_raw_materials" ON raw_materials;
CREATE POLICY "auth_select_raw_materials" ON raw_materials FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_raw_materials" ON raw_materials;
CREATE POLICY "auth_insert_raw_materials" ON raw_materials FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_raw_materials" ON raw_materials;
CREATE POLICY "auth_update_raw_materials" ON raw_materials FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_raw_materials" ON raw_materials;
CREATE POLICY "auth_delete_raw_materials" ON raw_materials FOR DELETE TO authenticated USING (true);

-- ============================================================
-- RAW MATERIAL MOVEMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS raw_material_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_id uuid NOT NULL REFERENCES raw_materials(id) ON DELETE CASCADE,
  movement_type text NOT NULL CHECK (movement_type IN ('purchase','stock_in','stock_out','production_consumption','adjustment')),
  quantity_change numeric(14,3) NOT NULL,
  balance_after numeric(14,3) NOT NULL,
  reference text DEFAULT '',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_rm_movements_material ON raw_material_movements(material_id);
CREATE INDEX IF NOT EXISTS idx_rm_movements_created ON raw_material_movements(created_at DESC);

ALTER TABLE raw_material_movements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_select_rm_movements" ON raw_material_movements FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_insert_rm_movements" ON raw_material_movements FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_update_rm_movements" ON raw_material_movements FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_rm_movements" ON raw_material_movements;
CREATE POLICY "auth_delete_rm_movements" ON raw_material_movements FOR DELETE TO authenticated USING (true);

-- ============================================================
-- FINISHED PRODUCTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS finished_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  unit text NOT NULL DEFAULT 'Cubic Meter' CHECK (unit IN ('Cubic Meter','Kg','Ton','Piece')),
  current_stock numeric(14,3) NOT NULL DEFAULT 0,
  minimum_stock numeric(14,3) NOT NULL DEFAULT 0,
  selling_price numeric(14,2) NOT NULL DEFAULT 0,
  production_cost numeric(14,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE finished_products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_finished_products" ON finished_products;
CREATE POLICY "auth_select_finished_products" ON finished_products FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_finished_products" ON finished_products;
CREATE POLICY "auth_insert_finished_products" ON finished_products FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_finished_products" ON finished_products;
CREATE POLICY "auth_update_finished_products" ON finished_products FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_finished_products" ON finished_products;
CREATE POLICY "auth_delete_finished_products" ON finished_products FOR DELETE TO authenticated USING (true);

-- ============================================================
-- FINISHED PRODUCT BOM (Bill of Materials / Recipe)
-- ============================================================
CREATE TABLE IF NOT EXISTS finished_product_bom (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES finished_products(id) ON DELETE CASCADE,
  material_id uuid NOT NULL REFERENCES raw_materials(id) ON DELETE CASCADE,
  quantity_per_unit numeric(14,3) NOT NULL,
  UNIQUE(product_id, material_id)
);

ALTER TABLE finished_product_bom ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_bom" ON finished_product_bom;
CREATE POLICY "auth_select_bom" ON finished_product_bom FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_bom" ON finished_product_bom;
CREATE POLICY "auth_insert_bom" ON finished_product_bom FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_bom" ON finished_product_bom;
CREATE POLICY "auth_update_bom" ON finished_product_bom FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_bom" ON finished_product_bom;
CREATE POLICY "auth_delete_bom" ON finished_product_bom FOR DELETE TO authenticated USING (true);

-- ============================================================
-- FINISHED PRODUCT MOVEMENTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS finished_product_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES finished_products(id) ON DELETE CASCADE,
  movement_type text NOT NULL CHECK (movement_type IN ('production','sales','adjustment')),
  quantity_change numeric(14,3) NOT NULL,
  balance_after numeric(14,3) NOT NULL,
  reference text DEFAULT '',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_fp_movements_product ON finished_product_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_fp_movements_created ON finished_product_movements(created_at DESC);

ALTER TABLE finished_product_movements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_select_fp_movements" ON finished_product_movements FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_insert_fp_movements" ON finished_product_movements FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_update_fp_movements" ON finished_product_movements FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_fp_movements" ON finished_product_movements;
CREATE POLICY "auth_delete_fp_movements" ON finished_product_movements FOR DELETE TO authenticated USING (true);

-- ============================================================
-- PRODUCTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS productions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_number text UNIQUE NOT NULL,
  product_id uuid NOT NULL REFERENCES finished_products(id) ON DELETE RESTRICT,
  quantity numeric(14,3) NOT NULL,
  production_date date NOT NULL DEFAULT CURRENT_DATE,
  operator_name text NOT NULL DEFAULT '',
  total_cost numeric(14,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed','failed')),
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_productions_date ON productions(production_date DESC);
CREATE INDEX IF NOT EXISTS idx_productions_product ON productions(product_id);

ALTER TABLE productions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_productions" ON productions;
CREATE POLICY "auth_select_productions" ON productions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_productions" ON productions;
CREATE POLICY "auth_insert_productions" ON productions FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_productions" ON productions;
CREATE POLICY "auth_update_productions" ON productions FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_productions" ON productions;
CREATE POLICY "auth_delete_productions" ON productions FOR DELETE TO authenticated USING (true);

-- ============================================================
-- CUSTOMERS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company text DEFAULT '',
  mobile text DEFAULT '',
  email text DEFAULT '',
  address text DEFAULT '',
  gst_number text DEFAULT '',
  outstanding_balance numeric(14,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_customers" ON customers;
CREATE POLICY "auth_select_customers" ON customers FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_customers" ON customers;
CREATE POLICY "auth_insert_customers" ON customers FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_customers" ON customers;
CREATE POLICY "auth_update_customers" ON customers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_customers" ON customers;
CREATE POLICY "auth_delete_customers" ON customers FOR DELETE TO authenticated USING (true);

-- ============================================================
-- SALES INVOICES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS sales_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text UNIQUE NOT NULL,
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  invoice_date date NOT NULL DEFAULT CURRENT_DATE,
  product_id uuid NOT NULL REFERENCES finished_products(id) ON DELETE RESTRICT,
  quantity numeric(14,3) NOT NULL,
  rate numeric(14,2) NOT NULL,
  tax_rate numeric(5,2) NOT NULL DEFAULT 18,
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  tax_amount numeric(14,2) NOT NULL DEFAULT 0,
  total_amount numeric(14,2) NOT NULL DEFAULT 0,
  amount_paid numeric(14,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('paid','unpaid','partial')),
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invoices_date ON sales_invoices(invoice_date DESC);
CREATE INDEX IF NOT EXISTS idx_invoices_customer ON sales_invoices(customer_id);

ALTER TABLE sales_invoices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_invoices" ON sales_invoices;
CREATE POLICY "auth_select_invoices" ON sales_invoices FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_invoices" ON sales_invoices;
CREATE POLICY "auth_insert_invoices" ON sales_invoices FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_invoices" ON sales_invoices;
CREATE POLICY "auth_update_invoices" ON sales_invoices FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_invoices" ON sales_invoices;
CREATE POLICY "auth_delete_invoices" ON sales_invoices FOR DELETE TO authenticated USING (true);

-- ============================================================
-- QUOTATIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS quotations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quotation_number text UNIQUE NOT NULL,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  customer_name text NOT NULL DEFAULT '',
  quotation_date date NOT NULL DEFAULT CURRENT_DATE,
  valid_until date NOT NULL DEFAULT (CURRENT_DATE + 30),
  product_id uuid NOT NULL REFERENCES finished_products(id) ON DELETE RESTRICT,
  quantity numeric(14,3) NOT NULL,
  unit_price numeric(14,2) NOT NULL,
  tax_rate numeric(5,2) NOT NULL DEFAULT 18,
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  tax_amount numeric(14,2) NOT NULL DEFAULT 0,
  total_amount numeric(14,2) NOT NULL DEFAULT 0,
  terms text DEFAULT '1. Payment Terms: 50% advance, 50% on delivery.\n2. Validity: 30 days from quotation date.\n3. Prices are inclusive of applicable taxes unless stated otherwise.\n4. Delivery charges extra as applicable.',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','sent','converted')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_quotations_date ON quotations(quotation_date DESC);

ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_quotations" ON quotations;
CREATE POLICY "auth_select_quotations" ON quotations FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_quotations" ON quotations;
CREATE POLICY "auth_insert_quotations" ON quotations FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_quotations" ON quotations;
CREATE POLICY "auth_update_quotations" ON quotations FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_quotations" ON quotations;
CREATE POLICY "auth_delete_quotations" ON quotations FOR DELETE TO authenticated USING (true);

-- ============================================================
-- EXPENSES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  expense_date date NOT NULL DEFAULT CURRENT_DATE,
  category text NOT NULL DEFAULT 'Other' CHECK (category IN ('Fuel','Electricity','Labour','Vehicle','Maintenance','Office Expense','Machinery Repair','Other')),
  vendor text DEFAULT '',
  amount numeric(14,2) NOT NULL DEFAULT 0,
  notes text DEFAULT '',
  receipt_url text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date DESC);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_expenses" ON expenses;
CREATE POLICY "auth_select_expenses" ON expenses FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_expenses" ON expenses;
CREATE POLICY "auth_insert_expenses" ON expenses FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_expenses" ON expenses;
CREATE POLICY "auth_update_expenses" ON expenses FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_expenses" ON expenses;
CREATE POLICY "auth_delete_expenses" ON expenses FOR DELETE TO authenticated USING (true);

-- ============================================================
-- ACTIVITY LOGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_email text DEFAULT '',
  action text NOT NULL,
  entity text DEFAULT '',
  entity_id uuid,
  details text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_activity_logs_created ON activity_logs(created_at DESC);

ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_activity_logs" ON activity_logs;
CREATE POLICY "auth_select_activity_logs" ON activity_logs FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_activity_logs" ON activity_logs;
CREATE POLICY "auth_insert_activity_logs" ON activity_logs FOR INSERT TO authenticated WITH CHECK (true);

-- ============================================================
-- PRODUCE_BATCH FUNCTION (Core BOM deduction logic)
-- ============================================================
CREATE OR REPLACE FUNCTION produce_batch(
  p_product_id uuid,
  p_quantity numeric,
  p_production_date date DEFAULT CURRENT_DATE,
  p_operator_name text DEFAULT '',
  p_notes text DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_product RECORD;
  v_bom RECORD;
  v_batch_number text;
  v_total_cost numeric(14,2) := 0;
  v_material_cost numeric(14,2);
  v_insufficient jsonb[] := '{}'::jsonb[];
  v_new_rm_stock numeric(14,3);
  v_new_fp_stock numeric(14,3);
  v_prod_id uuid;
  v_seq int;
BEGIN
  -- Validate product
  SELECT * INTO v_product FROM finished_products WHERE id = p_product_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Product not found');
  END IF;

  IF p_quantity <= 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Quantity must be greater than zero');
  END IF;

  -- Check stock availability for all BOM items
  FOR v_bom IN
    SELECT b.material_id, b.quantity_per_unit, m.name, m.current_stock, m.unit, m.unit_cost
    FROM finished_product_bom b
    JOIN raw_materials m ON m.id = b.material_id
    WHERE b.product_id = p_product_id
  LOOP
    v_material_cost := v_bom.quantity_per_unit * p_quantity * v_bom.unit_cost;
    v_total_cost := v_total_cost + v_material_cost;

    IF v_bom.current_stock < (v_bom.quantity_per_unit * p_quantity) THEN
      v_insufficient := array_append(v_insufficient, jsonb_build_object(
        'material_id', v_bom.material_id,
        'name', v_bom.name,
        'required', v_bom.quantity_per_unit * p_quantity,
        'available', v_bom.current_stock,
        'unit', v_bom.unit
      ));
    END IF;
  END LOOP;

  -- Block if any material is insufficient
  IF array_length(v_insufficient, 1) > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Insufficient raw material stock',
      'insufficient_materials', to_jsonb(v_insufficient)
    );
  END IF;

  -- Generate batch number
  v_seq := COALESCE((SELECT COUNT(*) + 1 FROM productions WHERE production_date = p_production_date), 1);
  v_batch_number := 'BATCH-' || to_char(p_production_date, 'YYYYMMDD') || '-' || lpad(v_seq::text, 3, '0');

  -- Deduct raw materials and record movements
  FOR v_bom IN
    SELECT b.material_id, b.quantity_per_unit, m.current_stock, m.unit_cost
    FROM finished_product_bom b
    JOIN raw_materials m ON m.id = b.material_id
    WHERE b.product_id = p_product_id
  LOOP
    v_new_rm_stock := v_bom.current_stock - (v_bom.quantity_per_unit * p_quantity);
    UPDATE raw_materials SET current_stock = v_new_rm_stock, updated_at = now() WHERE id = v_bom.material_id;

    INSERT INTO raw_material_movements (material_id, movement_type, quantity_change, balance_after, reference, notes)
    VALUES (v_bom.material_id, 'production_consumption', -(v_bom.quantity_per_unit * p_quantity), v_new_rm_stock, v_batch_number, 'Consumed for production batch');
  END LOOP;

  -- Increase finished product stock
  v_new_fp_stock := v_product.current_stock + p_quantity;
  UPDATE finished_products SET current_stock = v_new_fp_stock, production_cost = v_total_cost / p_quantity, updated_at = now() WHERE id = p_product_id;

  INSERT INTO finished_product_movements (product_id, movement_type, quantity_change, balance_after, reference, notes)
  VALUES (p_product_id, 'production', p_quantity, v_new_fp_stock, v_batch_number, 'Production batch');

  -- Insert production record
  INSERT INTO productions (batch_number, product_id, quantity, production_date, operator_name, total_cost, status, notes)
  VALUES (v_batch_number, p_product_id, p_quantity, p_production_date, p_operator_name, v_total_cost, 'completed', p_notes)
  RETURNING id INTO v_prod_id;

  RETURN jsonb_build_object(
    'success', true,
    'production_id', v_prod_id,
    'batch_number', v_batch_number,
    'total_cost', v_total_cost,
    'cost_per_unit', v_total_cost / p_quantity,
    'new_finished_stock', v_new_fp_stock
  );
END;
$$;

-- ============================================================
-- HELPER: generate invoice number
-- ============================================================
CREATE OR REPLACE FUNCTION next_invoice_number()
RETURNS text
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT 'INV-' || to_char(now(), 'YYYYMM') || '-' || lpad((COUNT(*) + 1)::text, 4, '0')
  FROM sales_invoices
  WHERE to_char(invoice_date, 'YYYYMM') = to_char(now(), 'YYYYMM');
$$;

-- ============================================================
-- HELPER: generate quotation number
-- ============================================================
CREATE OR REPLACE FUNCTION next_quotation_number()
RETURNS text
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT 'QUO-' || to_char(now(), 'YYYYMM') || '-' || lpad((COUNT(*) + 1)::text, 4, '0')
  FROM quotations
  WHERE to_char(quotation_date, 'YYYYMM') = to_char(now(), 'YYYYMM');
$$;
