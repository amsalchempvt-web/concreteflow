/*
# Add Company Management, User Permissions, and Purchase Entries

## Overview
This migration adds three major capabilities:
1. **Company Management** — A `companies` table so multiple companies can be tracked, and each user belongs to one company.
2. **Custom User Permissions** — A `user_permissions` table that lets admins grant or revoke access to specific modules per user, overriding the default role-based access.
3. **Purchase Entries with Supplier Bill Details** — A `purchases` table that records full supplier bill information (bill number, bill date, bill amount, payment status, outstanding) when raw material stock is added.

## New Tables
1. `companies` — Company profiles (name, GST, address, contact, logo URL)
2. `user_permissions` — Per-user module access overrides (user_id + module key + allowed boolean)
3. `purchases` — Supplier purchase bills with full bill details and line items

## Modified Tables
1. `profiles` — Added `company_id` column (nullable, links to companies table)

## Security
- RLS enabled on all new tables with `TO authenticated` shared-access policies (same pattern as existing tables).
- `user_permissions` is readable by all authenticated users so the sidebar can check access.

## Important Notes
1. The `company_id` column on `profiles` is nullable so existing users are not broken.
2. `purchases` stores the full bill-level details; individual material quantities are tracked via `raw_material_movements` with `reference` set to the purchase bill number.
3. Outstanding payment on the supplier is automatically updated when a purchase is created with partial or unpaid status.
*/

-- ============================================================
-- COMPANIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  gst_number text DEFAULT '',
  address text DEFAULT '',
  contact text DEFAULT '',
  email text DEFAULT '',
  logo_url text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_companies" ON companies;
CREATE POLICY "auth_select_companies" ON companies FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_companies" ON companies;
CREATE POLICY "auth_insert_companies" ON companies FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_companies" ON companies;
CREATE POLICY "auth_update_companies" ON companies FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_companies" ON companies;
CREATE POLICY "auth_delete_companies" ON companies FOR DELETE TO authenticated USING (true);

-- ============================================================
-- Add company_id to profiles
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'company_id') THEN
    ALTER TABLE profiles ADD COLUMN company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ============================================================
-- USER PERMISSIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS user_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  module text NOT NULL,
  allowed boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, module)
);

ALTER TABLE user_permissions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_user_permissions" ON user_permissions;
CREATE POLICY "auth_select_user_permissions" ON user_permissions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_user_permissions" ON user_permissions;
CREATE POLICY "auth_insert_user_permissions" ON user_permissions FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_user_permissions" ON user_permissions;
CREATE POLICY "auth_update_user_permissions" ON user_permissions FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_user_permissions" ON user_permissions;
CREATE POLICY "auth_delete_user_permissions" ON user_permissions FOR DELETE TO authenticated USING (true);

-- ============================================================
-- PURCHASES TABLE (Supplier bill details)
-- ============================================================
CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_number text UNIQUE NOT NULL,
  supplier_id uuid NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  bill_number text DEFAULT '',
  bill_date date NOT NULL DEFAULT CURRENT_DATE,
  material_id uuid NOT NULL REFERENCES raw_materials(id) ON DELETE RESTRICT,
  quantity numeric(14,3) NOT NULL,
  unit_cost numeric(14,2) NOT NULL DEFAULT 0,
  bill_amount numeric(14,2) NOT NULL DEFAULT 0,
  amount_paid numeric(14,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('paid','unpaid','partial')),
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(bill_date DESC);
CREATE INDEX IF NOT EXISTS idx_purchases_supplier ON purchases(supplier_id);

ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth_select_purchases" ON purchases;
CREATE POLICY "auth_select_purchases" ON purchases FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_purchases" ON purchases;
CREATE POLICY "auth_insert_purchases" ON purchases FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_purchases" ON purchases;
CREATE POLICY "auth_update_purchases" ON purchases FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_purchases" ON purchases;
CREATE POLICY "auth_delete_purchases" ON purchases FOR DELETE TO authenticated USING (true);

-- ============================================================
-- HELPER: generate purchase number
-- ============================================================
CREATE OR REPLACE FUNCTION next_purchase_number()
RETURNS text
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT 'PUR-' || to_char(now(), 'YYYYMM') || '-' || lpad((COUNT(*) + 1)::text, 4, '0')
  FROM purchases
  WHERE to_char(bill_date, 'YYYYMM') = to_char(now(), 'YYYYMM');
$$;

-- ============================================================
-- Seed a default company
-- ============================================================
INSERT INTO companies (name, gst_number, address, contact, email)
VALUES ('ConcreteFlow Industries', '27AABCC1234D1Z9', '123 Industrial Area, Mumbai, Maharashtra', '+91 98765 43210', 'info@concreteflow.com')
ON CONFLICT DO NOTHING;
