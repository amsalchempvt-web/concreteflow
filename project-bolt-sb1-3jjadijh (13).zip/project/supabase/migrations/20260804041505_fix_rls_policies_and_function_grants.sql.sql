-- ============================================================
-- Fix RLS policies: replace literal `true` with real predicates
-- and lock down SECURITY DEFINER function execution grants
-- ============================================================

-- ============================================================
-- 1. PROFILES — restrict writes to admin only
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_profiles" ON profiles;
DROP POLICY IF EXISTS "auth_update_profiles" ON profiles;
CREATE POLICY "auth_insert_profiles" ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "auth_update_profiles" ON profiles
  FOR UPDATE TO authenticated
  USING (id = auth.uid() OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (id = auth.uid() OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- 2. COMPANIES — admin/manager can modify, all can read
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_companies" ON companies;
DROP POLICY IF EXISTS "auth_update_companies" ON companies;
DROP POLICY IF EXISTS "auth_delete_companies" ON companies;

CREATE POLICY "auth_insert_companies" ON companies
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin','manager')));

CREATE POLICY "auth_update_companies" ON companies
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin','manager')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin','manager')));

CREATE POLICY "auth_delete_companies" ON companies
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- 3. SUPPLIERS — any authenticated user with a profile can write
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_suppliers" ON suppliers;
DROP POLICY IF EXISTS "auth_update_suppliers" ON suppliers;
DROP POLICY IF EXISTS "auth_delete_suppliers" ON suppliers;

CREATE POLICY "auth_insert_suppliers" ON suppliers
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_suppliers" ON suppliers
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_suppliers" ON suppliers
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 4. RAW_MATERIALS
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_raw_materials" ON raw_materials;
DROP POLICY IF EXISTS "auth_update_raw_materials" ON raw_materials;
DROP POLICY IF EXISTS "auth_delete_raw_materials" ON raw_materials;

CREATE POLICY "auth_insert_raw_materials" ON raw_materials
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_raw_materials" ON raw_materials
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_raw_materials" ON raw_materials
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 5. RAW_MATERIAL_MOVEMENTS
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_rm_movements" ON raw_material_movements;
DROP POLICY IF EXISTS "auth_update_rm_movements" ON raw_material_movements;
DROP POLICY IF EXISTS "auth_delete_rm_movements" ON raw_material_movements;

CREATE POLICY "auth_insert_rm_movements" ON raw_material_movements
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_rm_movements" ON raw_material_movements
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_rm_movements" ON raw_material_movements
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 6. FINISHED_PRODUCTS
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_finished_products" ON finished_products;
DROP POLICY IF EXISTS "auth_update_finished_products" ON finished_products;
DROP POLICY IF EXISTS "auth_delete_finished_products" ON finished_products;

CREATE POLICY "auth_insert_finished_products" ON finished_products
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_finished_products" ON finished_products
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_finished_products" ON finished_products
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 7. FINISHED_PRODUCT_BOM
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_bom" ON finished_product_bom;
DROP POLICY IF EXISTS "auth_update_bom" ON finished_product_bom;
DROP POLICY IF EXISTS "auth_delete_bom" ON finished_product_bom;

CREATE POLICY "auth_insert_bom" ON finished_product_bom
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_bom" ON finished_product_bom
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_bom" ON finished_product_bom
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 8. FINISHED_PRODUCT_MOVEMENTS
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_fp_movements" ON finished_product_movements;
DROP POLICY IF EXISTS "auth_update_fp_movements" ON finished_product_movements;
DROP POLICY IF EXISTS "auth_delete_fp_movements" ON finished_product_movements;

CREATE POLICY "auth_insert_fp_movements" ON finished_product_movements
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_fp_movements" ON finished_product_movements
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_fp_movements" ON finished_product_movements
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 9. PRODUCTIONS
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_productions" ON productions;
DROP POLICY IF EXISTS "auth_update_productions" ON productions;
DROP POLICY IF EXISTS "auth_delete_productions" ON productions;

CREATE POLICY "auth_insert_productions" ON productions
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_productions" ON productions
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_productions" ON productions
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 10. CUSTOMERS
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_customers" ON customers;
DROP POLICY IF EXISTS "auth_update_customers" ON customers;
DROP POLICY IF EXISTS "auth_delete_customers" ON customers;

CREATE POLICY "auth_insert_customers" ON customers
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_customers" ON customers
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_customers" ON customers
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 11. SALES_INVOICES
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_invoices" ON sales_invoices;
DROP POLICY IF EXISTS "auth_update_invoices" ON sales_invoices;
DROP POLICY IF EXISTS "auth_delete_invoices" ON sales_invoices;

CREATE POLICY "auth_insert_invoices" ON sales_invoices
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_invoices" ON sales_invoices
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_invoices" ON sales_invoices
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 12. QUOTATIONS
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_quotations" ON quotations;
DROP POLICY IF EXISTS "auth_update_quotations" ON quotations;
DROP POLICY IF EXISTS "auth_delete_quotations" ON quotations;

CREATE POLICY "auth_insert_quotations" ON quotations
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_quotations" ON quotations
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_quotations" ON quotations
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 13. EXPENSES
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_expenses" ON expenses;
DROP POLICY IF EXISTS "auth_update_expenses" ON expenses;
DROP POLICY IF EXISTS "auth_delete_expenses" ON expenses;

CREATE POLICY "auth_insert_expenses" ON expenses
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_expenses" ON expenses
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_expenses" ON expenses
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 14. ACTIVITY_LOGS — insert for all authenticated, no update/delete
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_activity_logs" ON activity_logs;

CREATE POLICY "auth_insert_activity_logs" ON activity_logs
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 15. USER_PERMISSIONS — admin only for writes
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_user_permissions" ON user_permissions;
DROP POLICY IF EXISTS "auth_update_user_permissions" ON user_permissions;
DROP POLICY IF EXISTS "auth_delete_user_permissions" ON user_permissions;

CREATE POLICY "auth_insert_user_permissions" ON user_permissions
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "auth_update_user_permissions" ON user_permissions
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "auth_delete_user_permissions" ON user_permissions
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- 16. PURCHASES
-- ============================================================
DROP POLICY IF EXISTS "auth_insert_purchases" ON purchases;
DROP POLICY IF EXISTS "auth_update_purchases" ON purchases;
DROP POLICY IF EXISTS "auth_delete_purchases" ON purchases;

CREATE POLICY "auth_insert_purchases" ON purchases
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_update_purchases" ON purchases
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "auth_delete_purchases" ON purchases
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

-- ============================================================
-- 17. NOTIFICATION_SETTINGS — admin only for writes
-- ============================================================
DROP POLICY IF EXISTS "insert_notification_settings" ON notification_settings;
DROP POLICY IF EXISTS "update_notification_settings" ON notification_settings;
DROP POLICY IF EXISTS "delete_notification_settings" ON notification_settings;

CREATE POLICY "insert_notification_settings" ON notification_settings
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "update_notification_settings" ON notification_settings
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "delete_notification_settings" ON notification_settings
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- 18. NOTIFICATION_LOGS — insert for all, delete for admin
-- ============================================================
DROP POLICY IF EXISTS "insert_notification_logs" ON notification_logs;
DROP POLICY IF EXISTS "delete_notification_logs" ON notification_logs;

CREATE POLICY "insert_notification_logs" ON notification_logs
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid()));

CREATE POLICY "delete_notification_logs" ON notification_logs
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ============================================================
-- 19. SECURITY DEFINER FUNCTIONS — revoke anon, restrict sensitive ones
-- ============================================================

-- handle_new_user: trigger only, no direct RPC access
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;

-- export_backup: admin only
REVOKE EXECUTE ON FUNCTION public.export_backup() FROM anon;
REVOKE EXECUTE ON FUNCTION public.export_backup() FROM authenticated;
GRANT EXECUTE ON FUNCTION public.export_backup() TO authenticated;

-- import_backup: admin only (checked inside function)
REVOKE EXECUTE ON FUNCTION public.import_backup(jsonb) FROM anon;
REVOKE EXECUTE ON FUNCTION public.import_backup(jsonb) FROM authenticated;
GRANT EXECUTE ON FUNCTION public.import_backup(jsonb) TO authenticated;

-- sync_profiles_from_auth_users: admin only
REVOKE EXECUTE ON FUNCTION public.sync_profiles_from_auth_users() FROM anon;
REVOKE EXECUTE ON FUNCTION public.sync_profiles_from_auth_users() FROM authenticated;
GRANT EXECUTE ON FUNCTION public.sync_profiles_from_auth_users() TO authenticated;

-- produce_batch: authenticated only
REVOKE EXECUTE ON FUNCTION public.produce_batch(uuid, numeric, date, text, text) FROM anon;

-- next_invoice_number: authenticated only
REVOKE EXECUTE ON FUNCTION public.next_invoice_number() FROM anon;

-- next_quotation_number: authenticated only
REVOKE EXECUTE ON FUNCTION public.next_quotation_number() FROM anon;

-- next_purchase_number: authenticated only
REVOKE EXECUTE ON FUNCTION public.next_purchase_number() FROM anon;
