-- Add fields used on the delivery challan header so each company can print its own details.
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS pan_number text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS state_code text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS tagline text NOT NULL DEFAULT '';

COMMENT ON COLUMN public.companies.pan_number IS 'Company PAN, shown on the delivery challan header.';
COMMENT ON COLUMN public.companies.state_code IS 'GST state code (e.g. 24 for Gujarat), shown on the delivery challan header.';
COMMENT ON COLUMN public.companies.tagline IS 'Short tagline under the company name on printed delivery challans.';
