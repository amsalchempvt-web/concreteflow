import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Create a client with the caller's JWT to verify they are an admin
    const authHeader = req.headers.get("Authorization") || "";
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Use service-role client for profile lookups to avoid RLS recursion issues
    const serviceClient = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // Check caller is admin (bypass RLS with service role)
    const { data: callerProfile, error: profileError } = await serviceClient
      .from("profiles")
      .select("role, company_id")
      .eq("id", userData.user.id)
      .single();

    if (profileError || !callerProfile || !["admin", "super_admin"].includes(callerProfile.role)) {
      return new Response(JSON.stringify({ error: "Only authorized administrators can create users" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Parse request body
    const body = await req.json();
    const { email, password, full_name, role, company_id } = body;
    const assignedCompanyId = callerProfile.role === "super_admin" ? (company_id || null) : (callerProfile.company_id || null);

    if (!email || !password || !full_name) {
      return new Response(JSON.stringify({ error: "Email, password, and name are required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (password.length < 6) {
      return new Response(JSON.stringify({ error: "Password must be at least 6 characters" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const validRoles = ["super_admin", "admin", "manager", "accountant", "plant_operator", "sales_executive"];
    const assignedRole = validRoles.includes(role) ? role : "plant_operator";

    // Block creating a second admin in the SAME company (per-company uniqueness)
    if (assignedRole === "admin" && assignedCompanyId && callerProfile.role !== "super_admin") {
      const { count } = await serviceClient
        .from("profiles")
        .select("id", { count: "exact", head: true })
        .eq("role", "admin")
        .eq("company_id", assignedCompanyId);

      if ((count ?? 0) > 0) {
        return new Response(JSON.stringify({ error: "An admin already exists for this company. Only one admin per company is allowed." }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // Use service role key to create the user (admin API)
    const { data: newUserData, error: createError } = await serviceClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name, role: assignedRole },
    });

    if (createError) {
      return new Response(JSON.stringify({ error: createError.message }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!newUserData.user) {
      return new Response(JSON.stringify({ error: "Failed to create user" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Update the profile with the correct role and company
    const { error: updateError } = await serviceClient
      .from("profiles")
      .update({
        role: assignedRole,
        company_id: assignedCompanyId,
        full_name,
      })
      .eq("id", newUserData.user.id);

    if (updateError) {
      console.error("Profile update error:", updateError.message);
    }

    // Log activity
    await serviceClient.from("activity_logs").insert({
      user_email: userData.user.email || "",
      action: "user_created",
      entity: "user",
      details: `Created user ${email} with role ${assignedRole}`,
    });

    return new Response(JSON.stringify({ success: true, user_id: newUserData.user.id }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return new Response(JSON.stringify({ error: message || "An unexpected error occurred" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
