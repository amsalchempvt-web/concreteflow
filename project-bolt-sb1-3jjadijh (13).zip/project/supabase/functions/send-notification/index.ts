import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface NotificationRequest {
  alert_type: string;
  subject: string;
  message: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { alert_type, subject, message } = await req.json() as NotificationRequest;

    if (!alert_type || !message) {
      return new Response(
        JSON.stringify({ error: "alert_type and message are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const { data: settings } = await supabase
      .from("notification_settings")
      .select("*")
      .limit(1)
      .maybeSingle();

    if (!settings) {
      return new Response(
        JSON.stringify({ error: "No notification settings configured" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const alertKey = `alert_${alert_type}` as keyof typeof settings;
    if (settings[alertKey] === false) {
      return new Response(
        JSON.stringify({ sent: false, reason: "Alert type disabled" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const results: { channel: string; status: string; error?: string }[] = [];

    // Send email if enabled
    if (settings.email_enabled && settings.smtp_host && settings.smtp_from) {
      try {
        const emailResult = await sendEmail(settings, subject || "ConcreteFlow ERP Alert", message);
        results.push({ channel: "email", status: emailResult.ok ? "sent" : "failed", error: emailResult.error });
        await logNotification(supabase, "email", alert_type, settings.smtp_from, subject, message, emailResult.ok ? "sent" : "failed", emailResult.error);
      } catch (err) {
        const errorMsg = String(err);
        results.push({ channel: "email", status: "failed", error: errorMsg });
        await logNotification(supabase, "email", alert_type, settings.smtp_from, subject, message, "failed", errorMsg);
      }
    }

    // Send WhatsApp if enabled
    if (settings.whatsapp_enabled && settings.whatsapp_phone_number_id && settings.whatsapp_access_token && settings.whatsapp_recipient_phone) {
      try {
        const waResult = await sendWhatsApp(settings, message);
        results.push({ channel: "whatsapp", status: waResult.ok ? "sent" : "failed", error: waResult.error });
        await logNotification(supabase, "whatsapp", alert_type, settings.whatsapp_recipient_phone, null, message, waResult.ok ? "sent" : "failed", waResult.error);
      } catch (err) {
        const errorMsg = String(err);
        results.push({ channel: "whatsapp", status: "failed", error: errorMsg });
        await logNotification(supabase, "whatsapp", alert_type, settings.whatsapp_recipient_phone, null, message, "failed", errorMsg);
      }
    }

    return new Response(
      JSON.stringify({ sent: true, results }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});

async function sendEmail(
  settings: any,
  subject: string,
  body: string,
): Promise<{ ok: boolean; error?: string }> {
  const nodemailer = await import("npm:nodemailer@6.9.15");
  const transporter = nodemailer.createTransport({
    host: settings.smtp_host,
    port: settings.smtp_port,
    secure: settings.smtp_port === 465,
    auth: { user: settings.smtp_username, pass: settings.smtp_password },
  });

  try {
    await transporter.sendMail({
      from: settings.smtp_from,
      to: settings.smtp_from,
      subject,
      text: body,
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

async function sendWhatsApp(
  settings: any,
  body: string,
): Promise<{ ok: boolean; error?: string }> {
  const url = `https://graph.facebook.com/v18.0/${settings.whatsapp_phone_number_id}/messages`;
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${settings.whatsapp_access_token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: settings.whatsapp_recipient_phone,
      type: "text",
      text: { body: body.substring(0, 4096) },
    }),
  });

  if (!resp.ok) {
    const errText = await resp.text();
    return { ok: false, error: errText };
  }
  return { ok: true };
}

async function logNotification(
  supabase: any,
  channel: string,
  alertType: string,
  recipient: string,
  subject: string | null,
  message: string,
  status: string,
  error: string | undefined,
) {
  await supabase.from("notification_logs").insert({
    channel,
    alert_type: alertType,
    recipient,
    subject,
    message,
    status,
    error: error || null,
  });
}
